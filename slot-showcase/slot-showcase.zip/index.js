var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// slot-showcase/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);

// slot-showcase/src/lib/surfaces.js
var React = __toESM(require("react"), 1);
var import_ui = require("@plugin-host/ui");
var h = React.createElement;
var { useState } = React;
function describeProps(props) {
  return Object.keys(props || {}).sort().filter((key) => key !== "setDialogButtons" && key !== "dialogButtonClick").map((key) => {
    const value = props[key];
    if (Array.isArray(value)) return `${key}[${value.length}]`;
    if (typeof value === "function") return `${key}()`;
    return key;
  });
}
var propsLine = (props) => {
  const keys = describeProps(props);
  return keys.length ? `props: ${keys.join(", ")}` : "no props";
};
var ICON = "flask-2";
function Bar({ name, props, compact = true, tone = "primary" }) {
  return h(
    import_ui.InfoBar,
    { compact, tone, icon: ICON, eyebrow: `slot: ${name}`, title: propsLine(props) },
    compact ? null : h(
      import_ui.Row,
      { gap: 2 },
      h(import_ui.BarButton, { icon: "check" }, "Bar button"),
      h(import_ui.BarButton, { icon: "x", active: true }, "Active")
    )
  );
}
function Inline({ name, props, variant = "ghost" }) {
  return h(import_ui.Button, { variant, size: "sm", icon: ICON, title: propsLine(props) }, `slot: ${name}`);
}
function DetailSection({ name, props }) {
  return h(
    import_ui.Stack,
    { gap: 2 },
    h(import_ui.Row, { gap: 2 }, h(import_ui.Heading, { level: 4 }, `slot: ${name}`), h(import_ui.Badge, { tone: "primary" }, "Showcase")),
    h(import_ui.Text, { size: "xs", tone: "muted" }, propsLine(props)),
    h(import_ui.Row, { gap: 2 }, h(import_ui.Chip, { icon: "file-text", label: "chip.pdf", detail: "12 KB" }), h(import_ui.Chip, { icon: "link", label: "Chip" }))
  );
}
function Panel({ name, props }) {
  const [text, setText] = useState("");
  return h(import_ui.Page, null, h(
    import_ui.Stack,
    { gap: 4 },
    h(import_ui.Stack, { gap: 1 }, h(import_ui.Heading, { level: 3 }, `slot: ${name}`), h(import_ui.Text, { size: "xs", tone: "muted" }, propsLine(props))),
    h(
      import_ui.Field,
      { label: "Field", hint: "A hint under the field" },
      h(import_ui.Textarea, { rows: 3, value: text, placeholder: "Textarea", onChange: (e) => setText(e.target.value) })
    ),
    h(import_ui.Alert, { tone: "info", icon: "info-circle" }, "An info alert"),
    h(import_ui.Row, { gap: 2 }, h(import_ui.Button, { size: "sm" }, "Primary"), h(import_ui.Button, { size: "sm", variant: "secondary" }, "Secondary"))
  ));
}
function Dialog({ props }) {
  const [name, setName] = useState("");
  const [agree, setAgree] = useState(true);
  const [choice, setChoice] = useState("one");
  const close = (value) => props.onResult?.(value);
  return h(
    import_ui.Stack,
    { gap: 4 },
    h(import_ui.Text, { tone: "muted" }, `slot: plugin-dialog · ${propsLine(props)}`),
    h(
      import_ui.Field,
      { label: "Name", hint: "A text field in a dialog" },
      h(import_ui.Input, { value: name, placeholder: "Type something", onChange: (e) => setName(e.target.value) })
    ),
    h(
      import_ui.Field,
      { label: "Choice" },
      h(import_ui.Select, { block: true, value: choice, onChange: setChoice, options: [{ value: "one", label: "Option one" }, { value: "two", label: "Option two" }] })
    ),
    h(import_ui.Checkbox, { checked: agree, onChange: setAgree, label: "A checkbox", hint: "With a hint below" }),
    h(import_ui.Alert, { tone: "warning", icon: "alert-triangle" }, "A warning alert"),
    h(import_ui.DialogButtons, {
      buttons: [
        { id: "cancel", label: "Cancel", variant: "secondary" },
        { id: "ok", label: "Close with onResult", variant: "primary", disabled: !agree }
      ],
      onClick: (id) => close(id === "ok" ? "closed by the showcase" : null)
    })
  );
}
function SidebarSection({ props }) {
  return h(
    React.Fragment,
    null,
    h(import_ui.SidebarRow, { icon: ICON, label: "slot: sidebar-section", detail: "3", title: propsLine(props) }),
    h(import_ui.SidebarRow, { icon: "bookmark", label: propsLine(props) }),
    h(import_ui.SidebarEmpty, null, "SidebarEmpty line"),
    h(import_ui.SidebarRow, { icon: "plus", label: h(import_ui.Text, { tone: "muted", truncate: true }, "Add row"), onClick: () => {
    } })
  );
}
function SidebarWidget({ props }) {
  return h(import_ui.SidebarRow, { icon: ICON, label: "slot: sidebar-widget", detail: "1", title: propsLine(props) });
}
function Rail() {
  return h(import_ui.Row, { justify: "center" }, h(import_ui.Badge, { tone: "primary" }, "rail"));
}
function AppPage({ props }) {
  const [query, setQuery] = useState("");
  const [on, setOn] = useState(true);
  return h(
    import_ui.Page,
    { flush: true },
    h(
      import_ui.Toolbar,
      null,
      h(import_ui.Breadcrumbs, { items: [{ id: "root", label: "Showcase" }, { id: "page", label: "slot: app-page" }], onSelect: () => {
      } }),
      h(import_ui.ToolbarSpacer),
      h(import_ui.SearchInput, { value: query, onChange: setQuery, placeholder: "Search" }),
      h(import_ui.ToolbarButton, { icon: "plus", label: "New" }),
      h(import_ui.ToolbarButton, { icon: "refresh", label: "Refresh", compact: true })
    ),
    h(
      import_ui.List,
      { label: "Showcase list", columns: [{ label: "Name" }, { label: "Size", align: "end" }, { label: "Modified", align: "end", hideNarrow: true }] },
      h(import_ui.ListRow, { folder: true, title: "A folder", meta: ["—", "Today"] }),
      h(import_ui.ListRow, { icon: "report.pdf", title: "report.pdf", meta: ["1.2 MB", "Yesterday"], selected: true, actions: h(import_ui.RowAction, { icon: "download", label: "Download" }) }),
      h(import_ui.ListRow, { icon: "notes.txt", title: "notes.txt", subtitle: propsLine(props), meta: ["4 KB", "Oct 1"] })
    ),
    h(
      import_ui.Page,
      null,
      h(import_ui.PageHeader, { icon: ICON, title: "slot: app-page", description: "Page + PageHeader for a document-like page", actions: h(import_ui.Button, { icon: "plus" }, "Action") }),
      h(
        import_ui.Card,
        { title: "Card", actions: h(import_ui.Badge, { tone: "success" }, "Badge") },
        h(import_ui.SettingRow, { label: "A setting", description: "Setting rows in a card" }, h(import_ui.Switch, { label: "A setting", checked: on, onChange: setOn }))
      ),
      h(import_ui.EmptyState, { compact: true, icon: ICON, title: "EmptyState", description: "For empty and not-connected states", actions: h(import_ui.Button, null, "Connect") })
    )
  );
}
function SettingsSection({ name, props }) {
  const [on, setOn] = useState(true);
  const [choice, setChoice] = useState("a");
  return h(
    import_ui.Section,
    { title: `slot: ${name}`, description: propsLine(props) },
    h(import_ui.SettingRow, { label: "A switch", description: "Switch for on and off" }, h(import_ui.Switch, { label: "A switch", checked: on, onChange: setOn })),
    h(
      import_ui.SettingRow,
      { label: "A choice", description: "Select for choices" },
      h(import_ui.Select, { value: choice, onChange: setChoice, options: [{ value: "a", label: "Choice A" }, { value: "b", label: "Choice B" }] })
    )
  );
}
function AdminPage({ props }) {
  return h(
    import_ui.Stack,
    { gap: 4 },
    h(
      import_ui.Card,
      { title: "slot: admin-plugin-page", actions: h(import_ui.Button, { size: "sm", variant: "secondary" }, "Action") },
      h(import_ui.SettingRow, { label: "Organisation setting", description: propsLine(props) }, h(import_ui.Input, { placeholder: "Value", defaultValue: "" }))
    )
  );
}
function MessageListEmpty({ props }) {
  return h(import_ui.EmptyState, { compact: true, icon: ICON, title: "slot: message-list-empty", description: propsLine(props) });
}
function ContextMenu({ props }) {
  return h(import_ui.Row, { gap: 2, wrap: false }, h(import_ui.Icon, { name: ICON, size: "sm" }), h(import_ui.Text, { size: "xs", tone: "muted", truncate: true }, `slot: context-menu-email · ${propsLine(props)}`));
}
function ComposerArea({ name, props }) {
  return h(import_ui.Alert, { tone: "info", icon: ICON }, `slot: ${name} · ${propsLine(props)}`);
}
function AttachmentAction({ props }) {
  return h(import_ui.Chip, { icon: ICON, label: "slot: attachment-actions", title: propsLine(props), onClick: () => {
  } });
}
function EventForm({ props }) {
  return h(import_ui.Field, { label: "slot: calendar-event-form", hint: propsLine(props) }, h(import_ui.Input, { placeholder: "A field in the event form" }));
}
var SURFACES = {
  "app-top-banner": (p) => h(Bar, { name: "app-top-banner", props: p }),
  "plugin-dialog": (p) => h(Dialog, { props: p }),
  "navigation-rail-bottom": (p) => h(Rail, { props: p }),
  "sidebar-widget": (p) => h(SidebarWidget, { props: p }),
  "sidebar-section": (p) => h(SidebarSection, { props: p }),
  "app-page": (p) => h(AppPage, { props: p }),
  "message-list-header": (p) => h(Bar, { name: "message-list-header", props: p }),
  "message-list-empty": (p) => h(MessageListEmpty, { props: p }),
  "context-menu-email": (p) => h(ContextMenu, { props: p }),
  "toolbar-actions": (p) => h(import_ui.ToolbarButton, { icon: ICON, label: `slot: toolbar-actions (${describeProps(p).length} props)` }),
  "reader-header": (p) => h(Bar, { name: "reader-header", props: p }),
  "reader-below-subject": (p) => h(Bar, { name: "reader-below-subject", props: p }),
  "email-banner": (p) => h(Bar, { name: "email-banner", props: p, compact: false, tone: "info" }),
  "reader-above-quote": (p) => h(Bar, { name: "reader-above-quote", props: p }),
  "email-footer": (p) => h(Bar, { name: "email-footer", props: p, tone: "neutral" }),
  "thread-summary": (p) => h(Bar, { name: "thread-summary", props: p, compact: false, tone: "primary" }),
  "email-detail-sidebar": (p) => h(Panel, { name: "email-detail-sidebar", props: p }),
  "email-details-section": (p) => h(DetailSection, { name: "email-details-section", props: p }),
  "attachment-actions": (p) => h(AttachmentAction, { props: p }),
  "composer-toolbar": (p) => h(Inline, { name: "composer-toolbar", props: p }),
  "composer-above-body": (p) => h(ComposerArea, { name: "composer-above-body", props: p }),
  "composer-below-body": (p) => h(ComposerArea, { name: "composer-below-body", props: p }),
  "composer-sidebar": (p) => h(Panel, { name: "composer-sidebar", props: p }),
  "composer-sidebar-right": (p) => h(Panel, { name: "composer-sidebar-right", props: p }),
  "composer-attachment-source": (p) => h(Inline, { name: "composer-attachment-source", props: p }),
  "calendar-event-actions": (p) => h(Inline, { name: "calendar-event-actions", props: p, variant: "secondary" }),
  "calendar-event-detail": (p) => h(DetailSection, { name: "calendar-event-detail", props: p }),
  "calendar-event-form": (p) => h(EventForm, { props: p }),
  "contact-cryptokeys": (p) => h(DetailSection, { name: "contact-cryptokeys", props: p }),
  "contact-detail-section": (p) => h(DetailSection, { name: "contact-detail-section", props: p }),
  "task-detail-section": (p) => h(DetailSection, { name: "task-detail-section", props: p }),
  "file-preview-section": (p) => h(DetailSection, { name: "file-preview-section", props: p }),
  "settings-section": (p) => h(SettingsSection, { name: "settings-section", props: p }),
  "settings-page": (p) => h(SettingsSection, { name: "settings-page", props: p }),
  "admin-plugin-page": (p) => h(AdminPage, { props: p })
};

// slot-showcase/src/index.js
var api = require("@plugin-host");
function optionEntries(checked) {
  return [{ id: "option", label: "Showcase option", icon: "flask-2", checked, description: "A check item with a description" }];
}
var optionChecked = true;
var ACTIONS = {
  "command-palette": [
    { id: "open-dialog", label: "Slot showcase: open the dialog", icon: "layout-grid" },
    { id: "notify", label: "Slot showcase: send a notification", icon: "bell" }
  ],
  "top-bar-actions": [{ id: "top", label: "Showcase", icon: "flask-2" }],
  "message-row-actions": [{ id: "row", label: "Showcase row action", icon: "flask-2" }],
  "message-bulk-actions": [
    { id: "bulk", label: "Showcase", icon: "flask-2" },
    { id: "bulk-danger", label: "Showcase (danger)", icon: "bug", danger: true }
  ],
  "reader-actions": [{ id: "reader", label: "Showcase", icon: "flask-2" }],
  "attachment-menu": [{ id: "attachment", label: "Showcase attachment action", icon: "flask-2" }],
  "composer-send-menu": [{ id: "send", label: "Showcase send option", icon: "flask-2" }],
  "composer-attach-menu": [{ id: "attach", label: "Showcase attach source", icon: "flask-2" }],
  "composer-toolbar-actions": [{ id: "composer", label: "Showcase", icon: "flask-2", shortcut: "Alt+Shift+S" }],
  "composer-options-menu": optionEntries(true),
  "contact-list-actions": [{ id: "contacts", label: "Showcase", icon: "flask-2" }],
  "task-list-actions": [{ id: "tasks", label: "Showcase", icon: "flask-2" }],
  "file-actions": [{ id: "files", label: "Showcase file action", icon: "flask-2" }]
};
var slots = {};
for (const [name, component] of Object.entries(SURFACES)) {
  slots[name] = { component };
}
slots["email-details-section"].shouldShow = (ctx) => ctx?.category == null;
function isoDay(offset) {
  const d = /* @__PURE__ */ new Date();
  d.setDate(d.getDate() + offset);
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
async function activate() {
  for (const [surface, actions] of Object.entries(ACTIONS)) {
    try {
      await api.ui.setActions(surface, actions);
    } catch (err) {
      api.log.warn(`setActions(${surface}) failed: ${err.message}`);
    }
  }
  await api.ui.setDayLabels([
    { date: isoDay(0), text: "Showcase today", title: "Day label from the slot showcase", dot: true },
    { date: isoDay(1), text: "Label + dot", dot: true },
    { date: isoDay(3), text: "Label only" },
    { date: isoDay(5), dot: true, title: "Dot only" }
  ]);
  await api.ui.setPages([{ id: "showcase", title: "Showcase", icon: "layout-grid" }]);
  try {
    await api.ui.setSectionTitle("Showcase section");
  } catch (err) {
    api.log.warn(`setSectionTitle failed: ${err.message}`);
  }
}
var hooks = {
  async onAction({ surface, actionId, context }) {
    if (actionId === "open-dialog") {
      const result = await api.ui.openDialog({ title: "Slot showcase", slot: "plugin-dialog", extraProps: { opened: "from the command palette" } });
      api.toast.info(`plugin-dialog resolved: ${JSON.stringify(result)}`);
      return;
    }
    if (actionId === "notify") {
      await api.notifications.show({ title: "Slot showcase", body: "A notification from api.notifications.show", tag: "showcase" });
      return;
    }
    if (actionId === "option") {
      optionChecked = !optionChecked;
      await api.ui.setActions("composer-options-menu", optionEntries(optionChecked));
    }
    const keys = describeProps(context);
    api.toast.info(`${surface} (${actionId}): ${keys.length ? keys.join(", ") : "no context"}`);
  },
  onNotificationClick({ tag }) {
    api.toast.info(`Notification clicked: ${tag}`);
  }
};
