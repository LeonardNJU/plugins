var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// slot-showcase/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);
var import_react = require("react");
var api = require("@plugin-host");
var FRAME_SLOTS = {
  "app-top-banner": {},
  "plugin-dialog": {},
  "navigation-rail-bottom": { compact: true },
  "sidebar-widget": {},
  "sidebar-section": {},
  "app-page": { page: true },
  "message-list-header": {},
  "message-list-empty": {},
  "context-menu-email": {},
  "toolbar-actions": { inline: true },
  "reader-header": {},
  "reader-below-subject": {},
  "email-banner": {},
  "reader-above-quote": {},
  "email-footer": {},
  "thread-summary": {},
  "email-detail-sidebar": {},
  "email-details-section": {},
  "attachment-actions": { inline: true },
  "composer-toolbar": { inline: true },
  "composer-above-body": {},
  "composer-below-body": {},
  "composer-sidebar": {},
  "composer-sidebar-right": {},
  "composer-attachment-source": { inline: true },
  "calendar-event-actions": { inline: true },
  "calendar-event-detail": {},
  "calendar-event-form": {},
  "contact-cryptokeys": {},
  "contact-detail-section": {},
  "task-detail-section": {},
  "file-preview-section": {},
  "settings-section": {},
  "settings-page": {},
  "admin-plugin-page": {}
};
var ACTIONS = {
  "command-palette": [
    { id: "open-dialog", label: "Slot showcase: open the dialog", icon: "layout-grid" },
    { id: "notify", label: "Slot showcase: send a notification", icon: "bell" }
  ],
  "top-bar-actions": [{ id: "top", label: "Showcase", icon: "flask-2" }],
  "message-row-actions": [{ id: "row", label: "Showcase row action", icon: "flask-2" }],
  "message-bulk-actions": [
    { id: "bulk", label: "Showcase", icon: "flask-2" },
    { id: "bulk-danger", label: "Showcase (danger)", icon: "bug", danger: true }
  ],
  "reader-actions": [{ id: "reader", label: "Showcase", icon: "flask-2" }],
  "attachment-menu": [{ id: "attachment", label: "Showcase attachment action", icon: "flask-2" }],
  "composer-send-menu": [{ id: "send", label: "Showcase send option", icon: "flask-2" }],
  "composer-attach-menu": [{ id: "attach", label: "Showcase attach source", icon: "flask-2" }],
  "contact-list-actions": [{ id: "contacts", label: "Showcase", icon: "flask-2" }],
  "task-list-actions": [{ id: "tasks", label: "Showcase", icon: "flask-2" }],
  "file-actions": [{ id: "files", label: "Showcase file action", icon: "flask-2" }]
};
function describeProps(props) {
  return Object.keys(props || {}).sort().map((key) => {
    const value = props[key];
    if (Array.isArray(value)) return `${key}[${value.length}]`;
    if (typeof value === "function") return `${key}()`;
    return key;
  });
}
var BOX = {
  boxSizing: "border-box",
  border: "1px dashed var(--color-primary)",
  borderRadius: 6,
  background: "color-mix(in srgb, var(--color-primary) 8%, var(--color-background))",
  color: "var(--color-foreground)",
  padding: "6px 10px",
  fontSize: 12,
  lineHeight: 1.4,
  overflowWrap: "anywhere"
};
function SlotBox({ name, spec, props }) {
  const keys = describeProps(props);
  if (spec.inline) {
    return (0, import_react.createElement)(
      "span",
      {
        style: { ...BOX, display: "inline-flex", alignItems: "center", gap: 6, padding: "2px 8px", whiteSpace: "nowrap" },
        title: keys.length ? `props: ${keys.join(", ")}` : "no props"
      },
      (0, import_react.createElement)("strong", null, `slot: ${name}`),
      keys.length ? (0, import_react.createElement)("span", { style: { color: "var(--color-muted-foreground)" } }, keys.join(", ")) : null
    );
  }
  if (spec.compact) {
    return (0, import_react.createElement)("div", { style: { ...BOX, padding: 4, fontSize: 10, textAlign: "center" }, title: `slot: ${name}` }, "slot: rail");
  }
  const box = (0, import_react.createElement)(
    "div",
    { style: { ...BOX, ...spec.page ? { padding: 16, fontSize: 14 } : {} } },
    (0, import_react.createElement)("div", { style: { fontWeight: 600 } }, `slot: ${name}`),
    (0, import_react.createElement)(
      "div",
      { style: { color: "var(--color-muted-foreground)" } },
      keys.length ? `props: ${keys.join(", ")}` : "no props"
    ),
    name === "plugin-dialog" && typeof props.onResult === "function" ? (0, import_react.createElement)("button", {
      type: "button",
      onClick: () => props.onResult("closed by the showcase"),
      style: {
        marginTop: 8,
        font: "inherit",
        padding: "4px 10px",
        borderRadius: 6,
        cursor: "pointer",
        border: "1px solid var(--color-border)",
        background: "var(--color-background)",
        color: "var(--color-foreground)"
      }
    }, "Close with onResult") : null
  );
  return spec.page ? (0, import_react.createElement)("div", { style: { padding: 16 } }, box) : box;
}
var slots = {};
for (const [name, spec] of Object.entries(FRAME_SLOTS)) {
  slots[name] = { component: (props) => (0, import_react.createElement)(SlotBox, { name, spec, props }) };
}
slots["email-details-section"].shouldShow = (ctx) => ctx?.category == null;
function isoDay(offset) {
  const d = /* @__PURE__ */ new Date();
  d.setDate(d.getDate() + offset);
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
async function activate() {
  for (const [surface, actions] of Object.entries(ACTIONS)) {
    try {
      await api.ui.setActions(surface, actions);
    } catch (err) {
      api.log.warn(`setActions(${surface}) failed: ${err.message}`);
    }
  }
  await api.ui.setDayLabels([
    { date: isoDay(0), text: "Showcase today", title: "Day label from the slot showcase", dot: true },
    { date: isoDay(1), text: "Label + dot", dot: true },
    { date: isoDay(3), text: "Label only" },
    { date: isoDay(5), dot: true, title: "Dot only" }
  ]);
  await api.ui.setPages([{ id: "showcase", title: "Showcase", icon: "layout-grid" }]);
}
var hooks = {
  async onAction({ surface, actionId, context }) {
    if (actionId === "open-dialog") {
      const result = await api.ui.openDialog({ title: "Slot showcase", slot: "plugin-dialog", extraProps: { opened: "from the command palette" } });
      api.toast.info(`plugin-dialog resolved: ${JSON.stringify(result)}`);
      return;
    }
    if (actionId === "notify") {
      await api.notifications.show({ title: "Slot showcase", body: "A notification from api.notifications.show", tag: "showcase" });
      return;
    }
    const keys = describeProps(context);
    api.toast.info(`${surface} (${actionId}): ${keys.length ? keys.join(", ") : "no context"}`);
  },
  onNotificationClick({ tag }) {
    api.toast.info(`Notification clicked: ${tag}`);
  }
};
