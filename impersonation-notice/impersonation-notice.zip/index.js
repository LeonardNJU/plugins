var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// impersonation-notice/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);

// impersonation-notice/src/lib/banner.js
var React = __toESM(require("react"), 1);
var import_ui = require("@plugin-host/ui");
var h = React.createElement;
function ImpersonationBar({ mailbox, actorRoleLabel, returnLabel, showReturn, busy, onReturn }) {
  return h(
    "div",
    { role: "status", "aria-live": "polite" },
    h(
      import_ui.InfoBar,
      {
        compact: true,
        tone: "warning",
        icon: "spy",
        title: h(React.Fragment, null, "You are viewing ", h("strong", null, mailbox), ` ${actorRoleLabel}`)
      },
      showReturn ? h(import_ui.BarButton, { icon: "arrow-left", busy, onClick: onReturn }, returnLabel) : null
    )
  );
}

// impersonation-notice/src/index.js
var { createElement: h2, useEffect, useState } = require("react");
var slotApi = require("@plugin-host");
var DEFAULT_RETURN_LABEL = "Back to platform";
var DEFAULT_ACTOR_ROLE_LABEL = "as Platform Admin";
function looksLikeImpersonation(username) {
  return typeof username === "string" && username.includes("%");
}
function parseImpersonatedMailbox(username) {
  if (!looksLikeImpersonation(username)) return null;
  return username.split("%")[0] || null;
}
function pickString(value, fallback) {
  if (typeof value !== "string") return fallback;
  const trimmed = value.trim();
  return trimmed.length ? trimmed : fallback;
}
function ImpersonationBanner(props) {
  const username = props?.username;
  const mailbox = parseImpersonatedMailbox(username);
  const [busy, setBusy] = useState(false);
  const [cfg, setCfg] = useState({
    returnUrl: pickString(props?.returnUrl, ""),
    returnLabel: DEFAULT_RETURN_LABEL,
    actorRoleLabel: DEFAULT_ACTOR_ROLE_LABEL
  });
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const all = await slotApi.admin.getAllConfig().catch(() => null);
        if (cancelled) return;
        if (all && typeof all === "object") {
          setCfg((prev) => ({
            returnUrl: pickString(all.returnUrl, prev.returnUrl),
            returnLabel: pickString(all.returnLabel, DEFAULT_RETURN_LABEL),
            actorRoleLabel: pickString(all.actorRoleLabel, DEFAULT_ACTOR_ROLE_LABEL)
          }));
        }
      } catch (err) {
        slotApi.log.warn("impersonation-notice: could not read admin config", err);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);
  if (!mailbox) return null;
  async function handleReturn() {
    if (busy) return;
    setBusy(true);
    if (cfg.returnUrl) {
      try {
        await slotApi.ui.openExternalUrl(cfg.returnUrl, "_blank");
      } catch (err) {
        slotApi.log.warn("impersonation-notice: openExternalUrl failed", err);
      }
    }
    try {
      await slotApi.user.logout();
    } catch (err) {
      slotApi.log.warn("impersonation-notice: logout failed", err);
      setBusy(false);
    }
  }
  return h2(ImpersonationBar, {
    mailbox,
    actorRoleLabel: cfg.actorRoleLabel,
    returnLabel: cfg.returnLabel,
    showReturn: !!cfg.returnUrl,
    busy,
    onReturn: handleReturn
  });
}
function shouldShow(extraProps) {
  return looksLikeImpersonation(extraProps?.username);
}
var slots = {
  "app-top-banner": {
    component: ImpersonationBanner,
    shouldShow,
    order: 50
  }
};
async function activate(api) {
  api.log.info("Impersonation Notice plugin activated");
}
