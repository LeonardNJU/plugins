var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// jitsi-meet/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);

// jitsi-meet/src/lib/button.js
var import_ui = require("@plugin-host/ui");
function makeJitsiButton(React2, api) {
  const { createElement: h, useState } = React2;
  return function JitsiAddButton(props) {
    const [busy, setBusy] = useState(false);
    const eventTitle = props?.eventData?.title || "meeting";
    const setVirtualLocation = props?.setVirtualLocation;
    async function handleClick() {
      if (busy) return;
      setBusy(true);
      try {
        const response = await api.http.post("/api/jitsi", { eventTitle });
        if (!response || !response.ok) {
          throw new Error(response?.data?.error || `HTTP ${response?.status ?? "error"}`);
        }
        const url = response.data?.url;
        if (!url) throw new Error("No url in response");
        if (typeof setVirtualLocation === "function") {
          await setVirtualLocation(url);
          api.toast.success("Jitsi meeting added to event");
        } else {
          await api.ui.alert({ title: "Jitsi meeting created", message: url });
        }
      } catch (err) {
        const message = err && err.message ? err.message : String(err);
        api.toast.error(`Could not create Jitsi meeting: ${message}`);
      } finally {
        setBusy(false);
      }
    }
    return h(import_ui.Button, { variant: "secondary", size: "sm", icon: "video", busy, onClick: handleClick }, "Add Jitsi meeting");
  };
}

// jitsi-meet/src/index.js
var React = require("react");
var slotApi = require("@plugin-host");
var slots = {
  "calendar-event-actions": {
    component: makeJitsiButton(React, slotApi),
    order: 10
  }
};
async function activate(api) {
  api.log.info("Jitsi Meet plugin activated");
}
