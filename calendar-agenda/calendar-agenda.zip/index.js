var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// calendar-agenda/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);

// calendar-agenda/src/lib/agenda.js
var import_ui = require("@plugin-host/ui");
var DIRTY_KEY = "agendaDirty";
var AGENDA_PATH = "/api/calendar-agenda";
var BANNER_EVENTS = 4;
var POSITION_TO_SLOT = {
  "Left sidebar": "sidebar-section",
  "Email reading pane": "email-detail-sidebar",
  "Top banner": "app-top-banner"
};
var DEFAULT_SLOT = "sidebar-section";
function slotForPosition(position) {
  return POSITION_TO_SLOT[position] || DEFAULT_SLOT;
}
function startOfDay(d) {
  const n = new Date(d);
  n.setHours(0, 0, 0, 0);
  return n;
}
function makeFormat(api, now = () => /* @__PURE__ */ new Date()) {
  const t = (key, vars) => api.i18n.t(key, vars);
  const locale = () => api.i18n.locale || api.i18n.getLocale && api.i18n.getLocale() || void 0;
  function dayLabel(date) {
    const diffDays = Math.round((startOfDay(date).getTime() - startOfDay(now()).getTime()) / 864e5);
    if (diffDays === 0) return t("day.today");
    if (diffDays === 1) return t("day.tomorrow");
    return date.toLocaleDateString(locale(), { weekday: "short", month: "short", day: "numeric" });
  }
  function timeLabel(ev) {
    if (ev.allDay) return t("event.all_day");
    return new Date(ev.start).toLocaleTimeString(locale(), { hour: "2-digit", minute: "2-digit" });
  }
  function when(ev) {
    const start = new Date(ev.start);
    const today = Math.round((startOfDay(start).getTime() - startOfDay(now()).getTime()) / 864e5) === 0;
    if (today) return timeLabel(ev);
    return ev.allDay ? dayLabel(start) : `${dayLabel(start)} ${timeLabel(ev)}`;
  }
  return { t, dayLabel, timeLabel, when };
}
function makeAgenda(React2, api, { slot = DEFAULT_SLOT, now } = {}) {
  const { createElement: h, useCallback, useEffect, useRef, useState } = React2;
  const fmt = makeFormat(api, now);
  const { t } = fmt;
  const titleOf = (ev) => ev.status === "cancelled" ? h("del", null, ev.title) : ev.title;
  const tooltip = (ev) => [ev.title, fmt.when(ev), ev.location].filter(Boolean).join(" · ");
  function useAgenda() {
    const [events, setEvents] = useState([]);
    const [state, setState] = useState("loading");
    const [error, setError] = useState("");
    const lastDirtyRef = useRef(null);
    const inFlightRef = useRef(false);
    const settings = api.plugin?.settings || {};
    const days = Number(settings.daysAhead) || 7;
    const limit = Number(settings.maxEvents) || 50;
    const refreshMs = Math.max(1, Number(settings.refreshMinutes) || 10) * 6e4;
    const fetchAgenda = useCallback(async () => {
      if (inFlightRef.current) return;
      inFlightRef.current = true;
      try {
        const res = await api.http.post(AGENDA_PATH, { days, limit });
        if (res?.status === 401) {
          setState("unauth");
          return;
        }
        if (!res?.ok) {
          setError(res?.data && res.data.error || `HTTP ${res?.status || "??"}`);
          setState("error");
          return;
        }
        setEvents(Array.isArray(res.data?.events) ? res.data.events : []);
        setState("ready");
      } catch (err) {
        api.log.warn("calendar-agenda: fetch failed", err);
        setError(String(err && err.message || err));
        setState("error");
      } finally {
        inFlightRef.current = false;
      }
    }, [days, limit]);
    useEffect(() => {
      void fetchAgenda();
      const pollId = setInterval(() => {
        void fetchAgenda();
      }, refreshMs);
      const dirtyId = setInterval(async () => {
        try {
          const mark = await api.storage.get(DIRTY_KEY);
          if (mark && mark !== lastDirtyRef.current) {
            lastDirtyRef.current = mark;
            void fetchAgenda();
          }
        } catch {
        }
      }, 4e3);
      const onFocus = () => {
        void fetchAgenda();
      };
      window.addEventListener("focus", onFocus);
      return () => {
        clearInterval(pollId);
        clearInterval(dirtyId);
        window.removeEventListener("focus", onFocus);
      };
    }, [fetchAgenda, refreshMs]);
    let message = null;
    if (state === "loading") message = t("state.loading");
    else if (state === "unauth") message = t("state.unauth");
    else if (state === "error") message = t("state.error", { error });
    else if (events.length === 0) message = t("state.empty", { days });
    return { events, state, message };
  }
  function SidebarAgenda() {
    const { events, message } = useAgenda();
    if (message) return h(import_ui.SidebarEmpty, null, message);
    return h(React2.Fragment, null, ...events.map((ev) => h(import_ui.SidebarRow, {
      key: ev.id,
      icon: "calendar-event",
      label: titleOf(ev),
      detail: fmt.when(ev),
      title: tooltip(ev)
    })));
  }
  function PanelAgenda() {
    const { events, state, message } = useAgenda();
    let body;
    if (state === "loading") body = h(import_ui.Loading, { label: message });
    else if (state === "error") body = h(import_ui.Alert, { tone: "danger", icon: "alert-triangle" }, message);
    else if (message) body = h(import_ui.EmptyState, { compact: true, icon: "calendar", title: message });
    else {
      body = h(import_ui.List, { label: t("header.title") }, ...events.map((ev) => h(import_ui.ListRow, {
        key: ev.id,
        icon: h(import_ui.Icon, { name: "calendar-event" }),
        title: titleOf(ev),
        subtitle: [fmt.when(ev), ev.location].filter(Boolean).join(" · ")
      })));
    }
    return h(import_ui.Page, null, h(import_ui.Stack, { gap: 3 }, h(import_ui.Heading, { level: 3 }, t("header.title")), body));
  }
  function BannerAgenda() {
    const { events, message } = useAgenda();
    return h(
      import_ui.InfoBar,
      { compact: true, tone: "primary", icon: "calendar", eyebrow: t("header.title"), title: message || void 0 },
      ...message ? [] : events.slice(0, BANNER_EVENTS).map((ev) => h(import_ui.Chip, {
        key: ev.id,
        icon: "calendar-event",
        label: ev.title,
        detail: fmt.when(ev),
        title: tooltip(ev)
      })),
      !message && events.length > BANNER_EVENTS ? h(import_ui.Text, { key: "more", size: "xs", tone: "muted" }, `+${events.length - BANNER_EVENTS}`) : null
    );
  }
  if (slot === "email-detail-sidebar") return PanelAgenda;
  if (slot === "app-top-banner") return BannerAgenda;
  return SidebarAgenda;
}

// calendar-agenda/src/index.js
var React = require("react");
var slotApi = require("@plugin-host");
var activeSlot = slotForPosition(slotApi?.plugin?.settings?.position);
var slots = {
  [activeSlot]: {
    component: makeAgenda(React, slotApi, { slot: activeSlot }),
    order: 15
  }
};
var pluginApi = null;
function markDirty() {
  if (!pluginApi) return;
  void pluginApi.storage.set(DIRTY_KEY, Date.now());
}
var hooks = {
  onAfterEventCreate() {
    markDirty();
  },
  onAfterEventUpdate() {
    markDirty();
  },
  onAfterEventDelete() {
    markDirty();
  },
  onEventsImport() {
    markDirty();
  },
  onEventRsvp() {
    markDirty();
  },
  onCalendarChange() {
    markDirty();
  },
  onICalSubscriptionChange() {
    markDirty();
  }
};
function setTitle(api) {
  if (activeSlot !== "sidebar-section") return;
  Promise.resolve(api.ui.setSectionTitle(api.i18n.t("header.title"))).catch((err) => {
    api.log.warn("calendar-agenda: setSectionTitle failed", err);
  });
}
async function activate(api) {
  pluginApi = api;
  setTitle(api);
  api.i18n.onLocaleChange?.(() => setTitle(api));
  api.log.info("Calendar Agenda plugin activated");
}
