var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// paperless/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);
var import_react5 = require("react");

// paperless/src/lib/errors.js
var PaperlessError = class extends Error {
  /**
   * @param {string} key  i18n key, e.g. 'error.token'
   * @param {Record<string, string|number>} [vars]
   * @param {number} [status] HTTP status, when there was one
   */
  constructor(key, vars = {}, status = 0) {
    super(key);
    this.name = "PaperlessError";
    this.key = key;
    this.vars = vars;
    this.status = status;
  }
};
function detailOf(body) {
  if (body == null) return "";
  if (typeof body === "string") {
    const text = body.trim();
    if (/^[{[]/.test(text)) {
      try {
        return detailOf(JSON.parse(text));
      } catch {
      }
    }
    if (/^<(!doctype|html)/i.test(text)) return "";
    return oneLine(text);
  }
  if (typeof body === "object") {
    if (typeof body.detail === "string") return oneLine(body.detail);
    if (typeof body.error === "string") return oneLine(body.error);
    const parts = [];
    for (const [field, value] of Object.entries(body)) {
      const msg = Array.isArray(value) ? value.filter((v) => typeof v === "string").join(" ") : typeof value === "string" ? value : "";
      if (msg) parts.push(field === "non_field_errors" ? msg : `${field}: ${msg}`);
    }
    return oneLine(parts.join("; "));
  }
  return "";
}
function oneLine(text) {
  const flat = String(text).replace(/\s+/g, " ").trim();
  return flat.length > 200 ? `${flat.slice(0, 197)}...` : flat;
}
function retryAfter(headers) {
  const raw = headers?.["retry-after"];
  const seconds = Number(raw);
  return Number.isFinite(seconds) && seconds > 0 ? Math.ceil(seconds) : 0;
}
function errorFromResponse(res) {
  if (res.proxyError) {
    switch (res.proxyError) {
      case "no_credential":
        return new PaperlessError("error.not_connected", {}, res.status);
      case "rate_limited":
        return new PaperlessError("error.rate_limit", { seconds: retryAfter(res.headers) || 60 }, 429);
      case "timeout":
        return new PaperlessError("error.timeout", {}, 504);
      case "unreachable":
        return new PaperlessError("error.unreachable", {}, 502);
      case "blocked_address":
        return new PaperlessError("error.blocked", {}, 403);
      case "too_large":
        return new PaperlessError("error.too_large", {}, 413);
      case "wrong_origin":
        return new PaperlessError("error.wrong_server", {}, 403);
      default:
        return new PaperlessError("error.proxy", { detail: detailOf(res.body) }, res.status);
    }
  }
  const status = res.status;
  const detail = detailOf(res.body);
  if (status === 401) return new PaperlessError("error.token", {}, status);
  if (status === 403) return new PaperlessError("error.forbidden", {}, status);
  if (status === 404) return new PaperlessError("error.not_found", {}, status);
  if (status === 413) return new PaperlessError("error.too_large", {}, status);
  if (status === 429) return new PaperlessError("error.rate_limit", { seconds: retryAfter(res.headers) || 60 }, status);
  if (status === 507 || /no space left|disk (is )?full|quota/i.test(detail)) return new PaperlessError("error.full", {}, status);
  if (status === 502 || status === 503 || status === 504) return new PaperlessError("error.unavailable", {}, status);
  if (status >= 500) return new PaperlessError("error.server", {}, status);
  if (status >= 400) return new PaperlessError("error.rejected", { detail: detail || `HTTP ${status}` }, status);
  return new PaperlessError("error.unexpected", { detail: `HTTP ${status}` }, status);
}
function toPaperlessError(err) {
  if (err instanceof PaperlessError) return err;
  const message = err && typeof err.message === "string" ? err.message : String(err);
  if (/timed out|timeout/i.test(message)) return new PaperlessError("error.timeout");
  if (/cancel|abort/i.test(message)) return new PaperlessError("error.cancelled");
  if (/larger than/i.test(message)) return new PaperlessError("error.too_large");
  if (/permission|not allowed|not granted/i.test(message)) return new PaperlessError("error.permission");
  if (/network|failed to fetch/i.test(message)) return new PaperlessError("error.unreachable");
  return new PaperlessError("error.unexpected", { detail: oneLine(message.split(/\r?\n/)[0]) });
}
function errorText(t2, err) {
  const e = toPaperlessError(err);
  return t2(e.key, e.vars);
}

// paperless/src/lib/multipart.js
function quote(value) {
  return String(value).replace(/[\r\n]+/g, " ").replace(/(["\\])/g, "\\$1");
}
function randomBoundary() {
  let out = "----BulwarkPaperless";
  for (let i = 0; i < 24; i++) out += Math.floor(Math.random() * 36).toString(36);
  return out;
}
function toBytes(data) {
  if (data instanceof Uint8Array) return data;
  if (data instanceof ArrayBuffer) return new Uint8Array(data);
  if (ArrayBuffer.isView(data)) return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
  return new TextEncoder().encode(String(data));
}
function buildMultipart(fields, boundary = randomBoundary()) {
  const enc = new TextEncoder();
  const chunks = [];
  for (const [name, value] of fields) {
    if (value === void 0 || value === null) continue;
    let head = `--${boundary}\r
Content-Disposition: form-data; name="${quote(name)}"`;
    if (typeof value === "object" && "data" in value) {
      head += `; filename="${quote(value.filename || "document")}"\r
Content-Type: ${value.type || "application/octet-stream"}\r
\r
`;
      chunks.push(enc.encode(head), toBytes(value.data), enc.encode("\r\n"));
    } else {
      head += "\r\n\r\n";
      chunks.push(enc.encode(head), enc.encode(String(value)), enc.encode("\r\n"));
    }
  }
  chunks.push(enc.encode(`--${boundary}--\r
`));
  const size = chunks.reduce((n, c) => n + c.byteLength, 0);
  const body = new Uint8Array(size);
  let offset = 0;
  for (const c of chunks) {
    body.set(c, offset);
    offset += c.byteLength;
  }
  return { body, contentType: `multipart/form-data; boundary=${boundary}` };
}

// paperless/src/lib/client.js
var PAGE_SIZE = 25;
var ACCEPT = "application/json";
function normalizeBase(value) {
  if (typeof value !== "string" || !value.trim()) return "";
  let text = value.trim();
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(text)) text = `https://${text}`;
  try {
    const url = new URL(text);
    if (url.protocol !== "https:" && url.protocol !== "http:") return "";
    const path = url.pathname.replace(/\/+$/, "").replace(/\/api$/, "");
    return `${url.origin}${path}`;
  } catch {
    return "";
  }
}
function documentQuery(filters = {}, page = 1, pageSize = PAGE_SIZE) {
  const q = new URLSearchParams();
  const text = (filters.text || "").trim();
  if (text) q.set("title_content", text);
  const tags = (filters.tags || []).filter((id) => Number.isInteger(id));
  if (tags.length) q.set("tags__id__all", tags.join(","));
  if (Number.isInteger(filters.correspondent)) q.set("correspondent__id__in", String(filters.correspondent));
  if (Number.isInteger(filters.documentType)) q.set("document_type__id__in", String(filters.documentType));
  if (/^\d{4}-\d{2}-\d{2}$/.test(filters.from || "")) q.set("created__date__gte", filters.from);
  if (/^\d{4}-\d{2}-\d{2}$/.test(filters.to || "")) q.set("created__date__lte", filters.to);
  q.set("ordering", "-created");
  q.set("page", String(page));
  q.set("page_size", String(pageSize));
  q.set("fields", "id,title,correspondent,document_type,tags,created,original_file_name,mime_type,content,page_count");
  return q.toString();
}
function normalizeTask(json) {
  const list = Array.isArray(json) ? json : Array.isArray(json?.results) ? json.results : [];
  const task = list[0];
  if (!task) return { state: "unknown", documentId: null, error: "", duplicateOf: null };
  const status = String(task.status || "").toLowerCase();
  let documentId = null;
  const fromData = task.result_data?.document_id;
  if (Number.isInteger(fromData)) documentId = fromData;
  else if (Array.isArray(task.related_document_ids) && Number.isInteger(task.related_document_ids[0])) documentId = task.related_document_ids[0];
  else if (task.related_document != null && /^\d+$/.test(String(task.related_document))) documentId = Number(task.related_document);
  const resultText = typeof task.result === "string" ? task.result : task.result_data?.error_message || "";
  let duplicateOf = null;
  const dup = /duplicate of .*?\(#(\d+)\)/i.exec(resultText);
  if (dup) duplicateOf = Number(dup[1]);
  if (status === "success") {
    if (documentId == null) {
      const m = /document id (\d+)/i.exec(resultText);
      if (m) documentId = Number(m[1]);
    }
    return { state: "success", documentId, error: "", duplicateOf: null };
  }
  if (status === "failure" || status === "revoked") {
    return { state: "failure", documentId: null, error: cleanTaskError(resultText), duplicateOf };
  }
  if (["pending", "started", "received", "retry"].includes(status)) return { state: "pending", documentId: null, error: "", duplicateOf: null };
  return { state: "unknown", documentId: null, error: "", duplicateOf: null };
}
function cleanTaskError(text) {
  let msg = String(text || "").split("\n")[0].trim();
  msg = msg.replace(/^[^:]{1,255}: (?=(error|not consuming|unsupported|cannot|could not))/i, "");
  msg = msg.replace(/^Error occurred while consuming document [^:]+: /i, "");
  msg = msg.replace(/\[Errno \d+\]\s*/g, "");
  return msg.length > 200 ? `${msg.slice(0, 197)}...` : msg;
}
function createClient({ proxyFetch, credentialId, base }) {
  if (!base) throw new PaperlessError("error.not_connected");
  async function request(path, { method = "GET", headers = {}, body, responseType = "json", signal, onProgress } = {}) {
    const url = /^https?:\/\//.test(path) ? path : `${base}${path}`;
    const init = { method, headers: { Accept: ACCEPT, ...headers }, responseType };
    if (body !== void 0) init.body = body;
    if (signal) init.signal = signal;
    if (onProgress) init.onProgress = onProgress;
    const res = await proxyFetch(credentialId, url, init);
    if (!res || !res.ok) throw errorFromResponse(res || { status: 0, headers: {} });
    return res;
  }
  async function json(path, opts) {
    const res = await request(path, { ...opts, responseType: "text" });
    const text = typeof res.body === "string" ? res.body : "";
    if (!text) return null;
    try {
      return JSON.parse(text);
    } catch {
      throw new PaperlessError("error.not_paperless", {}, res.status);
    }
  }
  async function listAll(path, max = 2e3) {
    const out = [];
    for (let page = 1; out.length < max; page++) {
      const sep = path.includes("?") ? "&" : "?";
      const data = await json(`${path}${sep}page=${page}&page_size=250`);
      const results = Array.isArray(data) ? data : data?.results ?? [];
      out.push(...results);
      if (Array.isArray(data) || !data?.next || results.length === 0) break;
    }
    return out;
  }
  const pick = (rows) => rows.map((r) => ({
    id: r.id,
    name: String(r.name ?? ""),
    match: String(r.match ?? ""),
    matchingAlgorithm: r.matching_algorithm ?? 0
  })).sort((a, b) => a.name.localeCompare(b.name));
  return {
    base,
    credentialId,
    request,
    /** Who the token belongs to; also checks the connection. */
    async whoAmI() {
      const data = await json("/api/ui_settings/");
      return { username: data?.user?.username || "", version: data?.settings?.version || "" };
    },
    async taxonomies() {
      const [tags, correspondents, documentTypes, storagePaths] = await Promise.all([
        listAll("/api/tags/?fields=id,name,match,matching_algorithm,color"),
        listAll("/api/correspondents/?fields=id,name,match,matching_algorithm"),
        listAll("/api/document_types/?fields=id,name,match,matching_algorithm"),
        listAll("/api/storage_paths/?fields=id,name,match,matching_algorithm").catch(() => [])
      ]);
      return { tags: pick(tags), correspondents: pick(correspondents), documentTypes: pick(documentTypes), storagePaths: pick(storagePaths) };
    },
    async searchDocuments(filters, page = 1, pageSize = PAGE_SIZE) {
      const data = await json(`/api/documents/?${documentQuery(filters, page, pageSize)}`);
      const results = Array.isArray(data?.results) ? data.results : [];
      return { count: data?.count ?? results.length, results, hasMore: !!data?.next };
    },
    /** The first document with this content, by SHA-256 (Paperless 3) or MD5 (older). */
    async findByChecksum({ sha256, md5 }) {
      for (const sum of [sha256, md5]) {
        if (!sum) continue;
        const data = await json(`/api/documents/?checksum__iexact=${encodeURIComponent(sum)}&fields=id,title&page_size=1`);
        const hit = data?.results?.[0];
        if (hit) return { id: hit.id, title: String(hit.title ?? "") };
      }
      return null;
    },
    /**
     * Hand a file to Paperless. Resolves to the consume task's id.
     * @param {{ data: Uint8Array|ArrayBuffer, name: string, type?: string, title?: string, correspondent?: number|null,
     *   documentType?: number|null, storagePath?: number|null, tags?: number[], created?: string }} doc
     */
    async upload(doc, { signal, onProgress } = {}) {
      const fields = [["document", { filename: doc.name, type: doc.type, data: doc.data }]];
      if (doc.title) fields.push(["title", doc.title.slice(0, 128)]);
      if (doc.created) fields.push(["created", doc.created]);
      if (Number.isInteger(doc.correspondent)) fields.push(["correspondent", doc.correspondent]);
      if (Number.isInteger(doc.documentType)) fields.push(["document_type", doc.documentType]);
      if (Number.isInteger(doc.storagePath)) fields.push(["storage_path", doc.storagePath]);
      for (const tag of doc.tags || []) if (Number.isInteger(tag)) fields.push(["tags", tag]);
      const { body, contentType } = buildMultipart(fields);
      const res = await request("/api/documents/post_document/", {
        method: "POST",
        headers: { "Content-Type": contentType },
        body,
        responseType: "text",
        signal,
        onProgress
      });
      let taskId = String(res.body ?? "").trim();
      try {
        const parsed = JSON.parse(taskId);
        if (typeof parsed === "string") taskId = parsed;
        else if (parsed?.task_id) taskId = parsed.task_id;
      } catch {
      }
      if (!/^[0-9a-f-]{8,64}$/i.test(taskId)) throw new PaperlessError("error.unexpected", { detail: "no task id" });
      return taskId;
    },
    async task(taskId) {
      return normalizeTask(await json(`/api/tasks/?task_id=${encodeURIComponent(taskId)}`));
    },
    async document(id) {
      return json(`/api/documents/${id}/`);
    },
    async thumbnail(id, signal) {
      const res = await request(`/api/documents/${id}/thumb/`, { responseType: "arraybuffer", signal });
      return { data: res.body, type: res.headers?.["content-type"] || "image/webp" };
    },
    async preview(id, signal) {
      const res = await request(`/api/documents/${id}/preview/`, { responseType: "arraybuffer", signal });
      return { data: res.body, type: res.headers?.["content-type"] || "application/pdf" };
    },
    /** The original file with its name from Content-Disposition. */
    async download(id, fallbackName = "document") {
      const res = await request(`/api/documents/${id}/download/?original=true`, { responseType: "arraybuffer" });
      const type = (res.headers?.["content-type"] || "application/octet-stream").split(";")[0].trim();
      return { data: res.body, type, name: filenameFromDisposition(res.headers?.["content-disposition"]) || fallbackName };
    },
    documentUrl(id) {
      return `${base}/documents/${id}/details`;
    }
  };
}
function filenameFromDisposition(header) {
  if (typeof header !== "string") return "";
  const star = /filename\*\s*=\s*([^']*)'[^']*'([^;]+)/i.exec(header);
  if (star) {
    try {
      return decodeURIComponent(star[2].trim());
    } catch {
    }
  }
  const plain = /filename\s*=\s*"((?:[^"\\]|\\.)*)"|filename\s*=\s*([^;]+)/i.exec(header);
  if (plain) return (plain[1] ?? plain[2] ?? "").replace(/\\(.)/g, "$1").trim();
  return "";
}

// paperless/src/lib/connection.js
var SHARED = "shared";
var PERSONAL = "personal";
async function adminServer(api) {
  try {
    return normalizeBase(await api.admin.getConfig("serverUrl"));
  } catch {
    return "";
  }
}
async function resolveConnection(api) {
  const configured = await adminServer(api);
  if (configured) {
    let res;
    try {
      res = await api.proxy.fetch(SHARED, `${configured}/api/ui_settings/`, { headers: { Accept: "application/json" }, responseType: "text" });
    } catch (err) {
      return { state: "error", error: toPaperlessError(err), mode: SHARED, suggestedServer: configured };
    }
    if (res?.ok) return { state: "connected", mode: SHARED, base: configured, credentialId: SHARED };
    if (res?.proxyError !== "no_credential") {
      return { state: "error", error: errorFromResponse(res || { status: 0 }), mode: SHARED, suggestedServer: configured };
    }
  }
  let accounts = [];
  try {
    accounts = await api.proxy.accounts() || [];
  } catch {
    accounts = [];
  }
  const mine = accounts.find((a) => a.credentialId === PERSONAL && a.connected);
  if (mine) {
    const base = configured && new URL(configured).origin === mine.origin ? configured : normalizeBase(mine.origin);
    return { state: "connected", mode: PERSONAL, base, credentialId: PERSONAL };
  }
  return { state: "disconnected", suggestedServer: configured };
}
function clientFor(api, connection) {
  if (!connection || connection.state !== "connected") {
    throw connection?.state === "error" ? connection.error : new PaperlessError("error.not_connected");
  }
  return createClient({ proxyFetch: (...a) => api.proxy.fetch(...a), credentialId: connection.credentialId, base: connection.base });
}
async function connectPersonal(api, suggestedServer) {
  const result = await api.proxy.connect(PERSONAL, { mode: "password", ...suggestedServer ? { server: suggestedServer } : {} });
  if (!result?.connected) return { connected: false };
  const connection = await resolveConnection(api);
  if (connection.state !== "connected") return { connected: false };
  try {
    await clientFor(api, connection).whoAmI();
  } catch (err) {
    const e = toPaperlessError(err);
    if (e.key === "error.token") await api.proxy.disconnect(PERSONAL).catch(() => {
    });
    return { connected: false, error: e };
  }
  return { connected: true, connection };
}

// paperless/src/lib/hash.js
var K256 = new Uint32Array([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
function toBytes2(data) {
  if (data instanceof Uint8Array) return data;
  if (data instanceof ArrayBuffer) return new Uint8Array(data);
  if (ArrayBuffer.isView(data)) return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
  if (typeof data === "string") return new TextEncoder().encode(data);
  throw new TypeError("hash input must be bytes or a string");
}
function hex(words2, littleEndian) {
  let out = "";
  for (const w of words2) {
    for (let i = 0; i < 4; i++) {
      const shift = littleEndian ? i * 8 : 24 - i * 8;
      out += (w >>> shift & 255).toString(16).padStart(2, "0");
    }
  }
  return out;
}
function pad(bytes, littleEndian) {
  const len = bytes.length;
  const total = Math.ceil((len + 9) / 64) * 64;
  const out = new Uint8Array(total);
  out.set(bytes);
  out[len] = 128;
  const view = new DataView(out.buffer);
  const bitsLow = len * 8 >>> 0;
  const bitsHigh = Math.floor(len / 536870912) >>> 0;
  if (littleEndian) {
    view.setUint32(total - 8, bitsLow, true);
    view.setUint32(total - 4, bitsHigh, true);
  } else {
    view.setUint32(total - 8, bitsHigh, false);
    view.setUint32(total - 4, bitsLow, false);
  }
  return out;
}
function sha256Hex(data) {
  const msg = pad(toBytes2(data), false);
  const view = new DataView(msg.buffer);
  const h2 = new Uint32Array([1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225]);
  const w = new Uint32Array(64);
  for (let off = 0; off < msg.length; off += 64) {
    for (let i = 0; i < 16; i++) w[i] = view.getUint32(off + i * 4, false);
    for (let i = 16; i < 64; i++) {
      const a2 = w[i - 15];
      const b2 = w[i - 2];
      const s0 = (a2 >>> 7 | a2 << 25) ^ (a2 >>> 18 | a2 << 14) ^ a2 >>> 3;
      const s1 = (b2 >>> 17 | b2 << 15) ^ (b2 >>> 19 | b2 << 13) ^ b2 >>> 10;
      w[i] = w[i - 16] + s0 + w[i - 7] + s1 >>> 0;
    }
    let [a, b, c, d, e, f, g, hh] = h2;
    for (let i = 0; i < 64; i++) {
      const S1 = (e >>> 6 | e << 26) ^ (e >>> 11 | e << 21) ^ (e >>> 25 | e << 7);
      const ch = e & f ^ ~e & g;
      const t1 = hh + S1 + ch + K256[i] + w[i] >>> 0;
      const S0 = (a >>> 2 | a << 30) ^ (a >>> 13 | a << 19) ^ (a >>> 22 | a << 10);
      const maj = a & b ^ a & c ^ b & c;
      const t2 = S0 + maj >>> 0;
      hh = g;
      g = f;
      f = e;
      e = d + t1 >>> 0;
      d = c;
      c = b;
      b = a;
      a = t1 + t2 >>> 0;
    }
    h2[0] = h2[0] + a >>> 0;
    h2[1] = h2[1] + b >>> 0;
    h2[2] = h2[2] + c >>> 0;
    h2[3] = h2[3] + d >>> 0;
    h2[4] = h2[4] + e >>> 0;
    h2[5] = h2[5] + f >>> 0;
    h2[6] = h2[6] + g >>> 0;
    h2[7] = h2[7] + hh >>> 0;
  }
  return hex(h2, false);
}
var MD5_S = [
  7,
  12,
  17,
  22,
  7,
  12,
  17,
  22,
  7,
  12,
  17,
  22,
  7,
  12,
  17,
  22,
  5,
  9,
  14,
  20,
  5,
  9,
  14,
  20,
  5,
  9,
  14,
  20,
  5,
  9,
  14,
  20,
  4,
  11,
  16,
  23,
  4,
  11,
  16,
  23,
  4,
  11,
  16,
  23,
  4,
  11,
  16,
  23,
  6,
  10,
  15,
  21,
  6,
  10,
  15,
  21,
  6,
  10,
  15,
  21,
  6,
  10,
  15,
  21
];
var MD5_K = new Uint32Array(64);
for (let i = 0; i < 64; i++) MD5_K[i] = Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296) >>> 0;
function md5Hex(data) {
  const msg = pad(toBytes2(data), true);
  const view = new DataView(msg.buffer);
  const h2 = new Uint32Array([1732584193, 4023233417, 2562383102, 271733878]);
  const m = new Uint32Array(16);
  for (let off = 0; off < msg.length; off += 64) {
    for (let i = 0; i < 16; i++) m[i] = view.getUint32(off + i * 4, true);
    let [a, b, c, d] = h2;
    for (let i = 0; i < 64; i++) {
      let f;
      let g;
      if (i < 16) {
        f = b & c | ~b & d;
        g = i;
      } else if (i < 32) {
        f = d & b | ~d & c;
        g = (5 * i + 1) % 16;
      } else if (i < 48) {
        f = b ^ c ^ d;
        g = (3 * i + 5) % 16;
      } else {
        f = c ^ (b | ~d);
        g = 7 * i % 16;
      }
      const tmp = d;
      d = c;
      c = b;
      const x = a + f + MD5_K[i] + m[g] >>> 0;
      b = b + (x << MD5_S[i] | x >>> 32 - MD5_S[i]) >>> 0;
      a = tmp;
    }
    h2[0] = h2[0] + a >>> 0;
    h2[1] = h2[1] + b >>> 0;
    h2[2] = h2[2] + c >>> 0;
    h2[3] = h2[3] + d >>> 0;
  }
  return hex(h2, true);
}
function checksums(data) {
  const bytes = toBytes2(data);
  return { sha256: sha256Hex(bytes), md5: md5Hex(bytes) };
}

// paperless/src/lib/mime.js
var latin1 = (bytes, start = 0, end = bytes.length) => {
  let out = "";
  for (let i = start; i < end; i += 8192) out += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(end, i + 8192)));
  return out;
};
function decodeCharset(bytes, charset) {
  const label = (charset || "utf-8").trim().toLowerCase();
  try {
    return new TextDecoder(label).decode(bytes);
  } catch {
    return new TextDecoder("utf-8").decode(bytes);
  }
}
function base64ToBytes(text) {
  let clean = text.replace(/[^A-Za-z0-9+/]/g, "");
  if (clean.length % 4 === 1) clean = clean.slice(0, -1);
  while (clean.length % 4) clean += "=";
  const bin = atob(clean);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
function qpToBytes(text, header = false) {
  const src = header ? text.replace(/_/g, " ") : text.replace(/=\r?\n/g, "");
  const out = [];
  for (let i = 0; i < src.length; i++) {
    const c = src[i];
    if (c === "=" && /^[0-9A-Fa-f]{2}$/.test(src.slice(i + 1, i + 3))) {
      out.push(parseInt(src.slice(i + 1, i + 3), 16));
      i += 2;
    } else {
      out.push(src.charCodeAt(i) & 255);
    }
  }
  return new Uint8Array(out);
}
function decodeWords(value) {
  if (typeof value !== "string" || !value.includes("=?")) return value || "";
  return value.replace(/(=\?[^?]+\?[bq]\?[^?]*\?=)\s+(?==\?)/gi, "$1").replace(/=\?([^?*]+)(?:\*[^?]*)?\?([bq])\?([^?]*)\?=/gi, (_m, charset, enc, text) => {
    const bytes = enc.toLowerCase() === "b" ? base64ToBytes(text) : qpToBytes(text, true);
    return decodeCharset(bytes, charset);
  });
}
function parseHeaders(text) {
  const headers = {};
  const lines = text.replace(/\r?\n[ \t]+/g, " ").split(/\r?\n/);
  for (const line of lines) {
    const i = line.indexOf(":");
    if (i <= 0) continue;
    const name = line.slice(0, i).trim().toLowerCase();
    (headers[name] || (headers[name] = [])).push(line.slice(i + 1).trim());
  }
  return headers;
}
function parseParams(header) {
  const parts = [];
  let cur = "";
  let quoted = false;
  for (let i = 0; i < (header || "").length; i++) {
    const c = header[i];
    if (c === '"' && header[i - 1] !== "\\") quoted = !quoted;
    if (c === ";" && !quoted) {
      parts.push(cur);
      cur = "";
      continue;
    }
    cur += c;
  }
  parts.push(cur);
  const value = (parts.shift() || "").trim().toLowerCase();
  const raw = {};
  for (const p of parts) {
    const i = p.indexOf("=");
    if (i <= 0) continue;
    const key = p.slice(0, i).trim().toLowerCase();
    let v = p.slice(i + 1).trim();
    if (v.startsWith('"') && v.endsWith('"')) v = v.slice(1, -1).replace(/\\(.)/g, "$1");
    raw[key] = v;
  }
  const params = {};
  const continued = {};
  for (const [key, v] of Object.entries(raw)) {
    const m = /^([^*]+)\*(\d+)?(\*)?$/.exec(key);
    if (!m) {
      params[key] = v;
      continue;
    }
    const [, name, index, encoded] = m;
    (continued[name] || (continued[name] = [])).push({ index: Number(index ?? 0), v, encoded: !!encoded || index === void 0 });
  }
  for (const [name, pieces] of Object.entries(continued)) {
    pieces.sort((a, b) => a.index - b.index);
    let charset = "utf-8";
    const bytes = [];
    pieces.forEach((piece, n) => {
      let text = piece.v;
      if (piece.encoded && n === 0) {
        const m = /^([^']*)'[^']*'(.*)$/.exec(text);
        if (m) {
          charset = m[1] || "utf-8";
          text = m[2];
        }
      }
      if (piece.encoded) {
        for (let i = 0; i < text.length; i++) {
          if (text[i] === "%" && /^[0-9A-Fa-f]{2}$/.test(text.slice(i + 1, i + 3))) {
            bytes.push(parseInt(text.slice(i + 1, i + 3), 16));
            i += 2;
          } else bytes.push(text.charCodeAt(i) & 255);
        }
      } else {
        for (const b of new TextEncoder().encode(text)) bytes.push(b);
      }
    });
    params[name] = decodeCharset(new Uint8Array(bytes), charset);
  }
  return { value, params };
}
function indexOfBytes(hay, needle, from) {
  outer: for (let i = from; i <= hay.length - needle.length; i++) {
    for (let j = 0; j < needle.length; j++) if (hay[i + j] !== needle[j]) continue outer;
    return i;
  }
  return -1;
}
function splitEntity(bytes) {
  let i = indexOfBytes(bytes, [13, 10, 13, 10], 0);
  let skip = 4;
  const lf = indexOfBytes(bytes, [10, 10], 0);
  if (lf !== -1 && (i === -1 || lf < i)) {
    i = lf;
    skip = 2;
  }
  if (i === -1) return { headerText: latin1(bytes), body: new Uint8Array(0) };
  return { headerText: latin1(bytes, 0, i), body: bytes.subarray(i + skip) };
}
function splitMultipart(body, boundary) {
  const marker = new TextEncoder().encode(`--${boundary}`);
  const parts = [];
  let pos = indexOfBytes(body, marker, 0);
  while (pos !== -1) {
    let start = pos + marker.length;
    if (body[start] === 45 && body[start + 1] === 45) break;
    while (start < body.length && body[start] !== 10) start++;
    start++;
    const next = indexOfBytes(body, marker, start);
    if (next === -1) {
      parts.push(body.subarray(start));
      break;
    }
    let end = next;
    if (body[end - 1] === 10) end--;
    if (body[end - 1] === 13) end--;
    parts.push(body.subarray(start, end));
    pos = next;
  }
  return parts;
}
function decodeBody(body, encoding) {
  const enc = (encoding || "").trim().toLowerCase();
  if (enc === "base64") return base64ToBytes(latin1(body));
  if (enc === "quoted-printable") return qpToBytes(latin1(body));
  return body;
}
var EXT_BY_TYPE = {
  "application/pdf": "pdf",
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/tiff": "tiff",
  "image/webp": "webp",
  "image/gif": "gif",
  "text/plain": "txt",
  "text/csv": "csv",
  "message/rfc822": "eml"
};
function walk(bytes, out, depth) {
  if (depth > 8) return;
  const { headerText, body } = splitEntity(bytes);
  const headers = parseHeaders(headerText);
  const ct = parseParams(headers["content-type"]?.[0] || "text/plain");
  const cd = parseParams(headers["content-disposition"]?.[0] || "");
  if (ct.value.startsWith("multipart/") && ct.params.boundary) {
    for (const part of splitMultipart(body, ct.params.boundary)) walk(part, out, depth + 1);
    return;
  }
  const rawName = cd.params.filename || ct.params.name || "";
  const name = decodeWords(rawName).replace(/[\\/]/g, "_").trim();
  let isAttachment;
  if (cd.value === "attachment") isAttachment = true;
  else if (cd.value === "inline") isAttachment = ct.value === "application/pdf";
  else isAttachment = !!name;
  if (!isAttachment || depth === 0) return;
  const data = decodeBody(body, headers["content-transfer-encoding"]?.[0]);
  const type = ct.value || "application/octet-stream";
  out.push({
    name: name || `attachment-${out.length + 1}.${EXT_BY_TYPE[type] || "bin"}`,
    type,
    size: data.byteLength,
    data
  });
}
function parseMessage(raw) {
  const bytes = raw instanceof Uint8Array ? raw : new Uint8Array(raw);
  const { headerText } = splitEntity(bytes);
  const headers = parseHeaders(headerText);
  const attachments = [];
  walk(bytes, attachments, 0);
  return {
    subject: decodeWords(headers.subject?.[0] || ""),
    from: decodeWords(headers.from?.[0] || ""),
    date: headers.date?.[0] || "",
    attachments
  };
}

// paperless/src/lib/send.js
var MAX_BULK_MESSAGES = 25;
var CONSUMABLE = [/^application\/pdf$/, /^image\/(png|jpe?g|tiff|webp|gif|bmp)$/, /^text\/(plain|csv)$/];
var WITH_TIKA = [
  /^message\/rfc822$/,
  /^text\/html$/,
  /^application\/(msword|rtf|vnd\.oasis\.opendocument\.(text|spreadsheet|presentation)|vnd\.ms-(excel|powerpoint))$/,
  /^application\/vnd\.openxmlformats-officedocument\./
];
var BY_EXTENSION = { pdf: "application/pdf", png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", tif: "image/tiff", tiff: "image/tiff", webp: "image/webp", gif: "image/gif", txt: "text/plain", csv: "text/csv", eml: "message/rfc822" };
function effectiveType(name, type) {
  const t2 = String(type || "").toLowerCase().split(";")[0].trim();
  if (t2 && t2 !== "application/octet-stream") return t2;
  const ext = String(name || "").toLowerCase().split(".").pop();
  return BY_EXTENSION[ext] || t2 || "application/octet-stream";
}
function consumability(type) {
  const t2 = String(type || "").toLowerCase();
  if (CONSUMABLE.some((re) => re.test(t2))) return "yes";
  if (WITH_TIKA.some((re) => re.test(t2))) return "tika";
  return "no";
}
function emlName(subject) {
  const base = String(subject || "").replace(/[\\/:*?"<>|\u0000-\u001f]+/g, " ").replace(/\s+/g, " ").trim().slice(0, 80);
  return `${base || "message"}.eml`;
}
function titleFromName(name) {
  const n = String(name || "").trim();
  const i = n.lastIndexOf(".");
  return (i > 0 ? n.slice(0, i) : n).slice(0, 128);
}
function itemFor({ key, kind, name, type, data, emailId, subject, hasFiles }) {
  const bytes = data instanceof Uint8Array ? data : new Uint8Array(data);
  const realType = kind === "eml" ? "message/rfc822" : effectiveType(name, type);
  const support = consumability(realType);
  return {
    key,
    kind,
    emailId,
    name,
    type: realType,
    size: bytes.byteLength,
    data: bytes,
    ...checksums(bytes),
    support,
    title: kind === "eml" ? String(subject || "").slice(0, 128) || titleFromName(name) : titleFromName(name),
    // Attachments are what people file; the message itself when it has none.
    selected: kind === "eml" ? !hasFiles : support === "yes"
  };
}
var senderOf = (view) => ({ name: view?.from?.[0]?.name || "", email: view?.from?.[0]?.email || "" });
async function collectAttachment(api, { emailId, blobId, name, type }) {
  const [view, file] = await Promise.all([
    api.email.get(emailId).catch(() => null),
    api.email.getAttachment(emailId, blobId)
  ]);
  const item = itemFor({ key: `a:${blobId}`, kind: "file", name: file.name || name, type: file.type || type, data: file.data, emailId, subject: view?.subject, hasFiles: true });
  item.selected = true;
  return [{ emailId, subject: view?.subject || "", sender: senderOf(view), receivedAt: view?.receivedAt || "", items: [item] }];
}
async function collectMessage(api, emailId) {
  const [view, raw] = await Promise.all([api.email.get(emailId).catch(() => null), api.email.getRaw(emailId)]);
  const parsed = parseMessage(raw);
  const subject = view?.subject || parsed.subject || "";
  const files = parsed.attachments.map((a, i) => itemFor({ key: `${emailId}:${i}`, kind: "file", name: a.name, type: a.type, data: a.data, emailId, subject, hasFiles: true }));
  const hasFiles = files.some((f) => f.support === "yes");
  const eml = itemFor({ key: `${emailId}:eml`, kind: "eml", name: emlName(subject), type: "message/rfc822", data: new Uint8Array(raw), emailId, subject, hasFiles });
  return { emailId, subject, sender: senderOf(view), receivedAt: view?.receivedAt || "", items: [...files, eml] };
}
async function collectMessages(api, emailIds, onProgress) {
  const ids = emailIds.slice(0, MAX_BULK_MESSAGES);
  const out = [];
  for (let i = 0; i < ids.length; i++) {
    onProgress?.(i, ids.length);
    out.push(await collectMessage(api, ids[i]));
  }
  return out;
}
function forDialog(groups) {
  return groups.map((g) => ({
    emailId: g.emailId,
    subject: g.subject,
    sender: g.sender,
    items: g.items.map(({ data: _data, ...rest }) => rest)
  }));
}
function plannedUploads(groups, choice) {
  const selected = new Set(choice.selected || []);
  const items = groups.flatMap((g) => g.items).filter((item) => selected.has(item.key));
  const single = items.length === 1;
  return items.map((item) => ({
    item,
    doc: {
      data: item.data,
      name: item.name,
      type: item.type,
      title: single && choice.title?.trim() ? choice.title.trim() : item.title,
      correspondent: Number.isInteger(choice.correspondent) ? choice.correspondent : null,
      documentType: Number.isInteger(choice.documentType) ? choice.documentType : null,
      storagePath: Number.isInteger(choice.storagePath) ? choice.storagePath : null,
      tags: (choice.tags || []).filter(Number.isInteger)
    }
  }));
}

// paperless/src/lib/suggest.js
var SYNONYMS = {
  invoice: ["invoice", "rechnung", "facture", "factura", "fattura", "faktura", "factuur", "fatura", "bill"],
  receipt: ["receipt", "quittung", "beleg", "kassenbon", "reçu", "recibo", "ricevuta", "kvittering", "bon"],
  contract: ["contract", "vertrag", "contrat", "contrato", "contratto", "kontrakt", "overeenkomst", "umowa"],
  letter: ["letter", "brief", "schreiben", "lettre", "carta", "lettera"],
  tax: ["tax", "steuer", "steuerbescheid", "impôt", "impuesto", "tasse"]
};
function normalize(text) {
  return String(text || "").toLowerCase().normalize("NFKD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9@.]+/g, " ").trim();
}
function words(text) {
  return normalize(text).split(/[\s.@]+/).filter((w) => w.length >= 3);
}
var GENERIC = /* @__PURE__ */ new Set([
  "www",
  "mail",
  "email",
  "noreply",
  "reply",
  "info",
  "service",
  "billing",
  "invoice",
  "support",
  "com",
  "org",
  "net",
  "gmbh",
  "inc",
  "ltd",
  "llc",
  "the",
  "and",
  "news",
  "newsletter",
  "team",
  "online",
  "kunden",
  "rechnung"
]);
function domainOf(email) {
  const m = /@([^@\s>]+)$/.exec(String(email || "").trim().toLowerCase());
  return m ? m[1] : "";
}
function senderKeys(email) {
  const address = String(email || "").trim().toLowerCase();
  const domain = domainOf(address);
  return [address, domain ? `@${domain}` : ""].filter(Boolean);
}
function matchFits(entry, sender) {
  const pattern = (entry.match || "").trim();
  if (!pattern) return false;
  const hay = `${sender.name || ""} ${sender.email || ""}`.toLowerCase();
  switch (entry.matchingAlgorithm) {
    case 1:
      return pattern.toLowerCase().split(/\s+/).some((w) => w.length >= 3 && hay.includes(w));
    case 2:
      return pattern.toLowerCase().split(/\s+/).every((w) => hay.includes(w));
    case 3:
    // literal
    case 5:
      return hay.includes(pattern.toLowerCase());
    case 4:
      try {
        return new RegExp(pattern, "i").test(hay);
      } catch {
        return false;
      }
    default:
      return false;
  }
}
function correspondentScore(entry, sender) {
  const cName = normalize(entry.name);
  if (!cName) return 0;
  const sName = normalize(sender.name);
  const email = String(sender.email || "").toLowerCase();
  if (sName && sName === cName) return 100;
  if (email && cName === email) return 100;
  if (matchFits(entry, sender)) return 90;
  if (sName.length >= 3 && cName.length >= 3 && (sName.includes(cName) || cName.includes(sName))) return 80;
  const domain = domainOf(email);
  if (domain) {
    const host = domain.split(".").slice(0, -1).join(" ");
    const domainWords = words(host).filter((w) => !GENERIC.has(w));
    const nameWords = words(entry.name).filter((w) => !GENERIC.has(w));
    if (domainWords.length && nameWords.length) {
      const joinedHost = normalize(host).replace(/[\s.]+/g, "");
      const joinedName = nameWords.join("");
      if (joinedHost === joinedName || joinedHost.includes(joinedName)) return 75;
      if (nameWords.some((w) => domainWords.includes(w))) return 60;
    }
  }
  return 0;
}
function bestCorrespondent(correspondents, sender) {
  let best = null;
  let bestScore = 0;
  for (const c of correspondents || []) {
    const score = correspondentScore(c, sender);
    if (score > bestScore) {
      best = c;
      bestScore = score;
    }
  }
  return bestScore >= 60 ? best : null;
}
function mentions(text, name) {
  const needle = normalize(name);
  if (needle.length < 3) return false;
  const hay = normalize(text);
  if (` ${hay} `.includes(` ${needle} `)) return true;
  const hayWords = hay.split(/[^a-z0-9]+/).filter(Boolean);
  const group = Object.values(SYNONYMS).find((list) => list.map(normalize).includes(needle)) || [needle];
  return group.map(normalize).some((w) => hayWords.some((h2) => h2 === w || w.length >= 5 && h2.endsWith(w)));
}
function bestDocumentType(types, text) {
  return (types || []).find((t2) => mentions(text, t2.name)) || null;
}
function matchingTags(tags, text) {
  return (tags || []).filter((t2) => mentions(text, t2.name)).map((t2) => t2.id);
}
function suggestMetadata({ sender = {}, text = "" }, tax, remembered = {}) {
  const ids = (list) => new Set((list || []).map((x) => x.id));
  const known = { c: ids(tax.correspondents), d: ids(tax.documentTypes), t: ids(tax.tags), s: ids(tax.storagePaths) };
  for (const key of senderKeys(sender.email)) {
    const r = remembered?.[key];
    if (!r) continue;
    return {
      correspondent: known.c.has(r.correspondent) ? r.correspondent : null,
      documentType: known.d.has(r.documentType) ? r.documentType : null,
      tags: (r.tags || []).filter((id) => known.t.has(id)),
      storagePath: known.s.has(r.storagePath) ? r.storagePath : null,
      source: "remembered"
    };
  }
  const correspondent = bestCorrespondent(tax.correspondents, sender);
  const documentType = bestDocumentType(tax.documentTypes, text);
  return {
    correspondent: correspondent ? correspondent.id : null,
    documentType: documentType ? documentType.id : null,
    tags: matchingTags(tax.tags, text),
    storagePath: null,
    source: correspondent || documentType ? "matched" : "none"
  };
}
function rememberChoice(remembered, email, choice, max = 200) {
  const [key] = senderKeys(email);
  if (!key) return remembered || {};
  const next = { ...remembered || {} };
  delete next[key];
  next[key] = {
    correspondent: Number.isInteger(choice.correspondent) ? choice.correspondent : null,
    documentType: Number.isInteger(choice.documentType) ? choice.documentType : null,
    tags: (choice.tags || []).filter(Number.isInteger),
    storagePath: Number.isInteger(choice.storagePath) ? choice.storagePath : null
  };
  const keys = Object.keys(next);
  for (const k of keys.slice(0, Math.max(0, keys.length - max))) delete next[k];
  return next;
}

// paperless/src/lib/tasks.js
var TASKS_KEY = "tasks";
var TASK_TIMEOUT_MS = 15 * 60 * 1e3;
var MAX_TASKS = 100;
function createTaskTracker({ storage, clientFor: clientFor2, onDone, now = () => Date.now(), timeoutMs = TASK_TIMEOUT_MS }) {
  let queue = Promise.resolve();
  const withList = (fn) => {
    const run = queue.then(async () => {
      const list = await storage.get(TASKS_KEY) || [];
      const result = await fn(Array.isArray(list) ? list : []);
      return result;
    });
    queue = run.catch(() => {
    });
    return run;
  };
  return {
    /** Remember a task to follow. */
    add(entry) {
      return withList(async (list) => {
        const next = [...list.filter((e) => e.taskId !== entry.taskId), { ...entry, startedAt: entry.startedAt ?? now() }].slice(-MAX_TASKS);
        await storage.set(TASKS_KEY, next);
        return next.length;
      });
    },
    pending() {
      return withList(async (list) => list);
    },
    /** Check every open task once. Resolves to how many are still open. */
    pollOnce() {
      return withList(async (list) => {
        const keep = [];
        for (const entry of list) {
          let outcome = null;
          try {
            const client = await clientFor2(entry);
            const task = await client.task(entry.taskId);
            if (task.state === "success") outcome = { state: "success", documentId: task.documentId };
            else if (task.state === "failure") outcome = { state: "failure", error: task.error, duplicateOf: task.duplicateOf };
          } catch (err) {
            const e = toPaperlessError(err);
            if (e.key === "error.token" || e.key === "error.not_connected") outcome = { state: "error", errorKey: e.key };
          }
          if (!outcome && now() - (entry.startedAt || 0) > timeoutMs) outcome = { state: "timeout" };
          if (outcome) {
            try {
              onDone(entry, outcome);
            } catch {
            }
          } else {
            keep.push(entry);
          }
        }
        if (keep.length !== list.length) await storage.set(TASKS_KEY, keep);
        return keep.length;
      });
    }
  };
}
function createPoller(tracker, { setTimer = setTimeout, fastMs = 2e3, slowMs = 1e4, fastFor = 15 } = {}) {
  let running = false;
  let rounds = 0;
  const tick = async () => {
    let open = 0;
    try {
      open = await tracker.pollOnce();
    } catch {
      open = 1;
    }
    rounds++;
    if (open > 0) setTimer(tick, rounds < fastFor ? fastMs : slowMs);
    else running = false;
  };
  return {
    start() {
      rounds = 0;
      if (running) return;
      running = true;
      setTimer(tick, fastMs);
    },
    get running() {
      return running;
    }
  };
}

// paperless/src/lib/background.js
var REMEMBERED_KEY = "remembered";
var LINKS_KEY = "links";
var ACTION_ATTACHMENT = "send-attachment";
var ACTION_MESSAGE = "send-message";
var ACTION_BULK = "send-bulk";
function createBackground(api, { setTimer = setTimeout } = {}) {
  const t2 = (key, vars) => api.i18n.t(key, vars);
  const toastError = (err) => api.toast.error(errorText(t2, err));
  const tracker = createTaskTracker({
    storage: api.storage,
    clientFor: async (entry) => createClient({ proxyFetch: (...a) => api.proxy.fetch(...a), credentialId: entry.credentialId, base: entry.base }),
    onDone: (entry, outcome) => {
      void reportDone(entry, outcome);
    }
  });
  const poller = createPoller(tracker, { setTimer });
  async function tell({ title, body, tag, error }) {
    if (api.plugin.settings?.notify !== false) {
      try {
        await api.notifications.show({ title: title.slice(0, 120), body: (body || "").slice(0, 300), ...tag ? { tag } : {} });
        return;
      } catch {
      }
    }
    const text = body ? `${title}: ${body}` : title;
    if (error) api.toast.error(text);
    else api.toast.success(text);
  }
  async function reportDone(entry, outcome) {
    const name = entry.name || entry.fileName || "";
    if (outcome.state === "success") {
      const tag = outcome.documentId != null ? `doc-${outcome.documentId}` : void 0;
      if (tag) {
        const links = await api.storage.get(LINKS_KEY).catch(() => null) || {};
        const keys = Object.keys(links);
        for (const k of keys.slice(0, Math.max(0, keys.length - 50))) delete links[k];
        links[tag] = `${entry.base}/documents/${outcome.documentId}/details`;
        await api.storage.set(LINKS_KEY, links).catch(() => {
        });
      }
      await tell({ title: t2("done.title"), body: t2("done.body", { name }), tag });
    } else if (outcome.state === "failure") {
      const body = outcome.duplicateOf != null || /duplicate/i.test(outcome.error || "") ? t2("failed.duplicate", { name }) : t2("failed.body", { name, error: outcome.error || t2("failed.unknown") });
      await tell({ title: t2("failed.title"), body, error: true });
    } else if (outcome.state === "timeout") {
      await tell({ title: t2("failed.title"), body: t2("failed.timeout", { name }), error: true });
    } else {
      await tell({ title: t2("failed.title"), body: `${name}: ${t2(outcome.errorKey || "error.unexpected", {})}`, error: true });
    }
  }
  async function ensureConnection() {
    const connection = await resolveConnection(api);
    if (connection.state === "connected") return connection;
    if (connection.state === "error") throw connection.error;
    const go = await api.ui.confirm({ title: t2("connect.title"), message: t2("connect.needed"), confirmLabel: t2("connect.button"), cancelLabel: t2("common.cancel") });
    if (!go) return null;
    const result = await connectPersonal(api, connection.suggestedServer);
    if (!result.connected) {
      if (result.error) throw result.error;
      return null;
    }
    return result.connection;
  }
  async function upload(connection, groups, choice) {
    const client = clientFor(api, connection);
    const plan = plannedUploads(groups, choice);
    let sent = 0;
    let firstError = null;
    for (const { item, doc } of plan) {
      try {
        const taskId = await client.upload(doc);
        await tracker.add({ taskId, name: doc.title || item.name, base: connection.base, credentialId: connection.credentialId });
        sent++;
      } catch (err) {
        firstError || (firstError = err);
        const key = toPaperlessError(err).key;
        if (["error.token", "error.full", "error.forbidden", "error.not_connected", "error.rate_limit"].includes(key)) break;
      }
    }
    if (sent) {
      poller.start();
      api.toast.info(t2("send.queued", { count: sent }));
    }
    if (firstError) toastError(firstError);
    return { sent, failed: plan.length - sent };
  }
  async function sendFlow(collect) {
    let connection;
    try {
      connection = await ensureConnection();
      if (!connection) return null;
    } catch (err) {
      toastError(err);
      return null;
    }
    let groups;
    try {
      groups = await collect();
    } catch (err) {
      toastError(err);
      return null;
    }
    if (!groups.length || !groups.some((g) => g.items.length)) {
      api.toast.info(t2("send.nothing"));
      return null;
    }
    const choice = await api.ui.openDialog({
      title: t2("dialog.title"),
      slot: "plugin-dialog",
      extraProps: { view: "send", groups: forDialog(groups), connection },
      width: 640
    });
    if (!choice || !Array.isArray(choice.selected) || choice.selected.length === 0) return null;
    if (choice.remember && choice.senderEmail) {
      const remembered = await api.storage.get(REMEMBERED_KEY).catch(() => null) || {};
      await api.storage.set(REMEMBERED_KEY, rememberChoice(remembered, choice.senderEmail, choice)).catch(() => {
      });
    }
    return upload(connection, groups, choice);
  }
  function onAction({ surface, actionId, context } = {}) {
    const ctx = context || {};
    if (actionId === ACTION_ATTACHMENT && ctx.emailId && ctx.blobId) {
      return sendFlow(() => collectAttachment(api, ctx));
    }
    if (actionId === ACTION_MESSAGE && ctx.emailId) {
      return sendFlow(async () => [await collectMessage(api, ctx.emailId)]);
    }
    if (actionId === ACTION_BULK && Array.isArray(ctx.emailIds) && ctx.emailIds.length) {
      if (ctx.emailIds.length > 25) api.toast.warning(t2("send.bulk_limit", { count: 25 }));
      return sendFlow(() => collectMessages(api, ctx.emailIds));
    }
    void surface;
    return null;
  }
  async function onNotificationClick({ tag } = {}) {
    if (typeof tag !== "string" || !tag.startsWith("doc-")) return;
    const links = await api.storage.get(LINKS_KEY).catch(() => null) || {};
    if (links[tag]) await api.ui.openExternalUrl(links[tag]);
  }
  async function registerUi() {
    const label = t2("action.send");
    const calls = [
      api.ui.setActions("attachment-menu", [{ id: ACTION_ATTACHMENT, label, icon: "archive" }]),
      api.ui.setActions("reader-actions", [{ id: ACTION_MESSAGE, label, icon: "archive" }]),
      api.ui.setActions("message-bulk-actions", [{ id: ACTION_BULK, label, icon: "archive" }]),
      api.ui.setPages([{ id: "documents", title: t2("page.title"), icon: "archive" }])
    ];
    await Promise.all(calls.map((p) => Promise.resolve(p).catch((err) => api.log?.warn?.("setup failed", err?.message))));
  }
  async function resume() {
    const open = await tracker.pending().catch(() => []);
    if (open.length) poller.start();
  }
  return { onAction, onNotificationClick, registerUi, resume, tracker, poller, sendFlow, upload, reportDone };
}

// paperless/src/ui/host.js
var current = null;
function setApi(api) {
  current = api;
}
function getApi() {
  if (current) return current;
  current = require("@plugin-host");
  return current;
}
function t(key, vars) {
  return getApi().i18n.t(key, vars);
}
function formatSize(bytes) {
  const n = Number(bytes) || 0;
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(n < 10 * 1024 ? 1 : 0)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}
function formatDate(iso) {
  if (!iso) return "";
  const d = new Date(/^\d{4}-\d{2}-\d{2}$/.test(iso) ? `${iso}T12:00:00` : iso);
  if (Number.isNaN(d.getTime())) return String(iso);
  try {
    return d.toLocaleDateString(getApi().i18n.getLocale(), { year: "numeric", month: "short", day: "numeric" });
  } catch {
    return d.toISOString().slice(0, 10);
  }
}
function hostOf(url) {
  try {
    return new URL(url).host;
  } catch {
    return String(url || "");
  }
}

// paperless/src/ui/SendDialog.jsx
var import_react2 = require("react");

// paperless/src/ui/common.jsx
var import_react = require("react");

// paperless/src/ui/styles.js
var CSS = `
.pl { color: var(--color-foreground); background: var(--color-background); font-size: 14px; line-height: 1.45; box-sizing: border-box; }
.pl *, .pl *::before, .pl *::after { box-sizing: border-box; }
.pl-page { padding: 16px; max-width: 1100px; margin: 0 auto; }
.pl h2 { font-size: 18px; font-weight: 600; margin: 0 0 4px; }
.pl h3 { font-size: 15px; font-weight: 600; margin: 16px 0 8px; }
.pl p { margin: 4px 0 8px; }
.pl-muted { color: var(--color-muted-foreground); font-size: 13px; }
.pl-row { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
.pl-grow { flex: 1 1 auto; min-width: 0; }
.pl-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 10px; }
.pl .pl-field { display: flex; flex-direction: column; gap: 4px; font-size: 12px; font-weight: 500; }
.pl input[type=text], .pl input[type=search], .pl input[type=date], .pl select {
  height: 34px; padding: 0 10px; border: 1px solid var(--color-input); border-radius: 6px;
  background: var(--color-background); color: var(--color-foreground); font: inherit; font-size: 14px; width: 100%; min-width: 0;
}
.pl input:focus-visible, .pl select:focus-visible, .pl button:focus-visible, .pl a:focus-visible, .pl [tabindex]:focus-visible {
  outline: 2px solid var(--color-ring); outline-offset: 1px;
}
.pl button { font: inherit; font-size: 14px; cursor: pointer; border-radius: 6px; height: 34px; padding: 0 12px;
  border: 1px solid var(--color-border); background: var(--color-background); color: var(--color-foreground); white-space: nowrap; }
.pl button:hover:not(:disabled) { background: var(--color-muted); }
.pl button:disabled { opacity: .55; cursor: default; }
.pl button.pl-primary { background: var(--color-primary); color: var(--color-primary-foreground); border-color: var(--color-primary); }
.pl button.pl-primary:hover:not(:disabled) { filter: brightness(1.08); background: var(--color-primary); }
.pl button.pl-danger { color: var(--color-destructive); }
.pl button.pl-link { border: none; background: none; padding: 0 4px; height: auto; color: var(--color-primary); text-decoration: underline; }
.pl-card { border: 1px solid var(--color-border); border-radius: 8px; padding: 12px; background: var(--color-card); color: var(--color-card-foreground); }
.pl-list { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 6px; }
.pl-item { display: flex; gap: 10px; align-items: flex-start; padding: 8px; border: 1px solid var(--color-border); border-radius: 8px; background: var(--color-card); }
.pl-item.pl-active { border-color: var(--color-primary); }
.pl-item input[type=checkbox] { margin-top: 3px; width: 16px; height: 16px; flex: none; accent-color: var(--color-primary); }
.pl-name { font-weight: 500; overflow-wrap: anywhere; }
.pl-badge { display: inline-flex; align-items: center; gap: 4px; font-size: 12px; padding: 1px 8px; border-radius: 999px;
  background: var(--color-muted); color: var(--color-muted-foreground); }
.pl-badge.pl-type { background: transparent; border: 1px solid var(--color-border); }
.pl-badge.pl-warn { background: color-mix(in srgb, var(--color-warning) 18%, transparent); color: var(--color-foreground); }
.pl-badge.pl-ok { background: color-mix(in srgb, var(--color-success) 18%, transparent); color: var(--color-foreground); }
.pl-chips { display: flex; flex-wrap: wrap; gap: 6px; max-height: 132px; overflow: auto; padding: 2px; }
.pl-chip { display: inline-flex; align-items: center; gap: 6px; padding: 4px 10px; border-radius: 999px; border: 1px solid var(--color-border);
  font-size: 13px; cursor: pointer; user-select: none; }
.pl-chip input { margin: 0; accent-color: var(--color-primary); }
.pl-chip.pl-on { background: var(--color-accent); color: var(--color-accent-foreground); border-color: transparent; }
.pl-error { border: 1px solid var(--color-destructive); color: var(--color-foreground); background: color-mix(in srgb, var(--color-destructive) 10%, transparent);
  border-radius: 8px; padding: 8px 12px; }
.pl-actions { display: flex; justify-content: flex-end; gap: 8px; flex-wrap: wrap; margin-top: 16px; }
.pl-thumb { width: 64px; height: 84px; flex: none; border-radius: 4px; border: 1px solid var(--color-border); background: var(--color-muted);
  object-fit: cover; object-position: top; }
.pl-docs { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: 16px; align-items: start; }
.pl-detail img.pl-big { width: 100%; max-height: 300px; object-fit: contain; background: var(--color-muted); border-radius: 6px; border: 1px solid var(--color-border); }
.pl-content { white-space: pre-wrap; font-size: 13px; max-height: 220px; overflow: auto; background: var(--color-muted); padding: 8px; border-radius: 6px; }
.pl-dl { display: grid; grid-template-columns: max-content 1fr; gap: 2px 12px; font-size: 13px; margin: 8px 0; }
.pl-dl dt { color: var(--color-muted-foreground); }
.pl-dl dd { margin: 0; overflow-wrap: anywhere; }
.pl-sr { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; }
.pl-bar { position: sticky; bottom: 0; background: var(--color-background); border-top: 1px solid var(--color-border); padding: 8px 0; margin-top: 8px; }
@media (max-width: 520px) {
  .pl-docs { grid-template-columns: minmax(0, 1fr); }
  .pl-page { padding: 12px; }
  .pl-actions button { flex: 1 1 auto; }
}
`;

// paperless/src/ui/common.jsx
var import_jsx_runtime = require("react/jsx-runtime");
function Styles() {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: CSS });
}
function useConnection(initial) {
  const [connection, setConnection] = (0, import_react.useState)(initial || null);
  const [loading, setLoading] = (0, import_react.useState)(!initial);
  const refresh = (0, import_react.useCallback)(async () => {
    setLoading(true);
    try {
      setConnection(await resolveConnection(getApi()));
    } finally {
      setLoading(false);
    }
  }, []);
  (0, import_react.useEffect)(() => {
    if (!initial) void refresh();
  }, [initial, refresh]);
  const client = (0, import_react.useMemo)(() => connection?.state === "connected" ? clientFor(getApi(), connection) : null, [connection]);
  return { connection, client, loading, refresh };
}
function ErrorBox({ error, onRetry }) {
  if (!error) return null;
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "pl-error", role: "alert", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: errorText(t, error) }),
    onRetry && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
      " ",
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "pl-link", onClick: onRetry, children: t("common.retry") })
    ] })
  ] });
}
function ConnectPanel({ connection, onConnected }) {
  const [busy, setBusy] = (0, import_react.useState)(false);
  const [error, setError] = (0, import_react.useState)(null);
  const connect = async () => {
    setBusy(true);
    setError(null);
    try {
      const result = await connectPersonal(getApi(), connection?.suggestedServer || "");
      if (result.connected) onConnected?.(result.connection);
      else if (result.error) setError(result.error);
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  };
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "pl-card", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: connection?.suggestedServer ? t("connect.intro_server", { host: hostOf(connection.suggestedServer) }) : t("connect.intro") }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "pl-muted", children: t("connect.token_hint") }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pl-actions", style: { justifyContent: "flex-start" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "pl-primary", onClick: connect, disabled: busy, children: busy ? t("common.working") : t("connect.button") }) })
  ] });
}
function Field({ id, label, note, children, style }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "pl-field", style, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { className: "pl-row", style: { gap: 6 }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { htmlFor: id, children: label }),
      note
    ] }),
    children
  ] });
}
function PickOne({ id, label, items, value, onChange, noneLabel, suggested }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, { id, label, note: suggested ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pl-badge pl-ok", children: t("send.suggested") }) : null, children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", { id, value: value == null ? "" : String(value), onChange: (e) => onChange(e.target.value === "" ? null : Number(e.target.value)), children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "", children: noneLabel || t("common.none") }),
    (items || []).map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: String(it.id), children: it.name }, it.id))
  ] }) });
}
function TagPicker({ tags, value, onChange, label }) {
  const on = new Set(value || []);
  if (!tags?.length) return null;
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { style: { border: "none", padding: 0, margin: 0 }, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", { style: { fontSize: 12, fontWeight: 500, marginBottom: 4 }, children: label || t("field.tags") }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pl-chips", children: tags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { className: `pl-chip${on.has(tag.id) ? " pl-on" : ""}`, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        "input",
        {
          type: "checkbox",
          checked: on.has(tag.id),
          onChange: () => {
            const next = new Set(on);
            if (next.has(tag.id)) next.delete(tag.id);
            else next.add(tag.id);
            onChange([...next]);
          }
        }
      ),
      tag.name
    ] }, tag.id)) })
  ] });
}
function useTaxonomies(client) {
  const [tax, setTax] = (0, import_react.useState)(null);
  const [error, setError] = (0, import_react.useState)(null);
  const load = (0, import_react.useCallback)(async () => {
    if (!client) return;
    setError(null);
    try {
      setTax(await client.taxonomies());
    } catch (err) {
      setError(err);
    }
  }, [client?.base, client?.credentialId]);
  (0, import_react.useEffect)(() => {
    void load();
  }, [load]);
  return { tax, error, reload: load };
}

// paperless/src/ui/SendDialog.jsx
var import_jsx_runtime2 = require("react/jsx-runtime");
var REMEMBERED_KEY2 = "remembered";
function sameSender(groups) {
  const emails = new Set(groups.map((g) => (g.sender?.email || "").toLowerCase()));
  return emails.size === 1 ? groups[0].sender : null;
}
function SendDialog({ groups = [], connection: initialConnection, onResult }) {
  const { client, connection } = useConnection(initialConnection);
  const { tax, error: taxError, reload } = useTaxonomies(client);
  const items = (0, import_react2.useMemo)(() => groups.flatMap((g) => g.items), [groups]);
  const sender = sameSender(groups);
  const [selected, setSelected] = (0, import_react2.useState)(() => new Set(items.filter((i) => i.selected).map((i) => i.key)));
  const [title, setTitle] = (0, import_react2.useState)("");
  const [correspondent, setCorrespondent] = (0, import_react2.useState)(null);
  const [documentType, setDocumentType] = (0, import_react2.useState)(null);
  const [storagePath, setStoragePath] = (0, import_react2.useState)(null);
  const [tags, setTags] = (0, import_react2.useState)([]);
  const [suggestion, setSuggestion] = (0, import_react2.useState)(null);
  const [remember, setRemember] = (0, import_react2.useState)(true);
  const [duplicates, setDuplicates] = (0, import_react2.useState)({});
  const [checking, setChecking] = (0, import_react2.useState)(true);
  (0, import_react2.useEffect)(() => {
    if (!tax) return;
    let cancelled = false;
    (async () => {
      const api = getApi();
      const remembered = await api.storage.get(REMEMBERED_KEY2).catch(() => null) || {};
      const text = [...groups.map((g) => g.subject), ...items.map((i) => i.name)].join(" ");
      const s = suggestMetadata({ sender: sender || {}, text }, tax, sender ? remembered : {});
      if (cancelled) return;
      setSuggestion(s);
      setCorrespondent(sender ? s.correspondent : null);
      setDocumentType(s.documentType);
      setStoragePath(s.storagePath);
      setTags(s.tags);
    })();
    return () => {
      cancelled = true;
    };
  }, [tax]);
  (0, import_react2.useEffect)(() => {
    if (!client) return;
    let cancelled = false;
    (async () => {
      const found = {};
      for (const item of items) {
        try {
          const hit = await client.findByChecksum({ sha256: item.sha256, md5: item.md5 });
          if (hit) found[item.key] = hit;
        } catch {
        }
      }
      if (cancelled) return;
      setDuplicates(found);
      setChecking(false);
      if (Object.keys(found).length) {
        setSelected((prev) => new Set([...prev].filter((k) => !found[k])));
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [client]);
  const toggle = (key) => setSelected((prev) => {
    const next = new Set(prev);
    if (next.has(key)) next.delete(key);
    else next.add(key);
    return next;
  });
  const single = selected.size === 1 ? items.find((i) => selected.has(i.key)) : null;
  (0, import_react2.useEffect)(() => {
    setTitle(single ? single.title : "");
  }, [single?.key]);
  const submit = (e) => {
    e?.preventDefault?.();
    if (!selected.size) return;
    onResult?.({
      selected: [...selected],
      title: single ? title : "",
      correspondent,
      documentType,
      storagePath,
      tags,
      remember: !!(remember && sender?.email),
      senderEmail: sender?.email || ""
    });
  };
  const openDoc = (id) => {
    if (client) void getApi().ui.openExternalUrl(client.documentUrl(id));
  };
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "pl", style: { padding: 4 }, children: [
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(Styles, {}),
    connection?.state === "error" && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(ErrorBox, { error: connection.error }),
    groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("section", { style: { marginBottom: 12 }, "aria-label": group.subject || t("send.no_subject"), children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { className: "pl-muted", style: { marginBottom: 6 }, children: t("send.from_line", { sender: group.sender?.name || group.sender?.email || "?", subject: group.subject || t("send.no_subject") }) }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("ul", { className: "pl-list", children: group.items.map((item) => {
        const dup = duplicates[item.key];
        const id = `pl-item-${item.key.replace(/[^a-z0-9]/gi, "-")}`;
        return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("li", { className: `pl-item${selected.has(item.key) ? " pl-active" : ""}`, children: [
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("input", { id, type: "checkbox", checked: selected.has(item.key), onChange: () => toggle(item.key) }),
          /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "pl-grow", children: [
            /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("label", { htmlFor: id, className: "pl-name", children: item.kind === "eml" ? t("send.whole_message", { name: item.name }) : item.name }),
            /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "pl-row", style: { marginTop: 2 }, children: [
              /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: "pl-muted", children: formatSize(item.size) }),
              item.support === "tika" && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: "pl-badge pl-warn", children: t("send.needs_tika") }),
              item.support === "no" && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: "pl-badge pl-warn", children: t("send.unsupported") }),
              dup && /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("span", { className: "pl-badge pl-ok", children: [
                t("send.already", { title: dup.title }),
                /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("button", { type: "button", className: "pl-link", onClick: () => openDoc(dup.id), children: t("common.open") })
              ] })
            ] })
          ] })
        ] }, item.key);
      }) })
    ] }, group.emailId)),
    checking && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { className: "pl-muted", "aria-live": "polite", children: t("send.checking") }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(ErrorBox, { error: taxError, onRetry: reload }),
    single && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(Field, { id: "pl-title", label: t("field.title"), style: { marginBottom: 10 }, children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
      "input",
      {
        id: "pl-title",
        type: "text",
        value: title,
        maxLength: 128,
        onChange: (e) => setTitle(e.target.value),
        onKeyDown: (e) => {
          if (e.key === "Enter") submit(e);
        }
      }
    ) }),
    selected.size > 1 && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { className: "pl-muted", children: t("send.titles_from_names") }),
    !tax && !taxError && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { className: "pl-muted", "aria-live": "polite", children: t("common.loading") }),
    tax && /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_jsx_runtime2.Fragment, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "pl-grid", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
          PickOne,
          {
            id: "pl-corr",
            label: t("field.correspondent"),
            items: tax.correspondents,
            value: correspondent,
            onChange: setCorrespondent,
            suggested: suggestion?.correspondent != null && suggestion.correspondent === correspondent
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
          PickOne,
          {
            id: "pl-type",
            label: t("field.document_type"),
            items: tax.documentTypes,
            value: documentType,
            onChange: setDocumentType,
            suggested: suggestion?.documentType != null && suggestion.documentType === documentType
          }
        ),
        tax.storagePaths.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(PickOne, { id: "pl-path", label: t("field.storage_path"), items: tax.storagePaths, value: storagePath, onChange: setStoragePath })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { style: { marginTop: 10 }, children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(TagPicker, { tags: tax.tags, value: tags, onChange: setTags }) }),
      suggestion?.source === "remembered" && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { className: "pl-muted", children: t("send.remembered_note") }),
      sender?.email && /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("label", { className: "pl-row", style: { marginTop: 10, fontSize: 13 }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("input", { type: "checkbox", checked: remember, onChange: (e) => setRemember(e.target.checked) }),
        t("send.remember", { sender: sender.email })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "pl-actions", children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("button", { type: "button", onClick: () => onResult?.(null), children: t("common.cancel") }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("button", { type: "button", className: "pl-primary", disabled: !selected.size || !client, onClick: submit, children: selected.size > 1 ? t("send.button_count", { count: selected.size }) : t("send.button") })
    ] })
  ] });
}

// paperless/src/ui/DocumentBrowser.jsx
var import_react3 = require("react");

// paperless/src/lib/documents.js
var MAX_ATTACH_BYTES = 25 * 1024 * 1024;
async function attachDocuments(api, client, docs, onProgress) {
  if (!docs.length) return null;
  const attachments = [];
  for (let i = 0; i < docs.length; i++) {
    onProgress?.(i, docs.length);
    const doc = docs[i];
    const file = await client.download(doc.id, doc.original_file_name || `${doc.title || "document"}.pdf`);
    const size = file.data?.byteLength ?? 0;
    if (size > MAX_ATTACH_BYTES) throw new PaperlessError("error.attach_too_large", { name: file.name });
    const blob = await api.jmap.uploadBlob(new Uint8Array(file.data), file.name, file.type);
    attachments.push({ blobId: blob.blobId, name: file.name, type: blob.type || file.type, size: blob.size ?? size });
  }
  const message = { attachments };
  if (docs.length === 1 && docs[0].title) message.subject = String(docs[0].title).slice(0, 200);
  return api.compose.open(message);
}
async function downloadDocument(api, client, doc) {
  const file = await client.download(doc.id, doc.original_file_name || `${doc.title || "document"}.pdf`);
  await api.ui.downloadFile({ content: new Uint8Array(file.data), filename: file.name, contentType: file.type });
  return file.name;
}

// paperless/src/ui/DocumentBrowser.jsx
var import_jsx_runtime3 = require("react/jsx-runtime");
var nameOf = (list, id) => list?.find((x) => x.id === id)?.name || "";
function useThumbs(client) {
  const [urls, setUrls] = (0, import_react3.useState)({});
  const asked = (0, import_react3.useRef)(/* @__PURE__ */ new Set());
  const made = (0, import_react3.useRef)([]);
  (0, import_react3.useEffect)(() => () => {
    for (const u of made.current) URL.revokeObjectURL(u);
  }, []);
  const want = (0, import_react3.useCallback)((id) => {
    if (!client || asked.current.has(id)) return;
    asked.current.add(id);
    client.thumbnail(id).then((thumb) => {
      const url = URL.createObjectURL(new Blob([thumb.data], { type: thumb.type }));
      made.current.push(url);
      setUrls((prev) => ({ ...prev, [id]: url }));
    }).catch(() => {
    });
  }, [client]);
  return { urls, want };
}
function Thumb({ id, thumbs, alt }) {
  (0, import_react3.useEffect)(() => {
    thumbs.want(id);
  }, [id, thumbs]);
  const url = thumbs.urls[id];
  return url ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("img", { className: "pl-thumb", src: url, alt }) : /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "pl-thumb", "aria-hidden": "true" });
}
function Preview({ client, doc, thumbs }) {
  const [url, setUrl] = (0, import_react3.useState)(null);
  (0, import_react3.useEffect)(() => {
    let made = null;
    let cancelled = false;
    if (client && /^image\//.test(doc.mime_type || "")) {
      client.preview(doc.id).then((p) => {
        if (cancelled) return;
        made = URL.createObjectURL(new Blob([p.data], { type: p.type }));
        setUrl(made);
      }).catch(() => {
      });
    } else {
      thumbs.want(doc.id);
    }
    return () => {
      cancelled = true;
      if (made) URL.revokeObjectURL(made);
    };
  }, [client, doc.id, doc.mime_type, thumbs]);
  const src = url || thumbs.urls[doc.id];
  return src ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("img", { className: "pl-big", src, alt: t("browse.preview_of", { title: doc.title }) }) : null;
}
function DocumentBrowser({ onClose, inDialog = false }) {
  const { connection, client, loading, refresh } = useConnection();
  const { tax } = useTaxonomies(client);
  const [filters, setFilters] = (0, import_react3.useState)({ text: "", tags: [], correspondent: null, documentType: null, from: "", to: "" });
  const [showFilters, setShowFilters] = (0, import_react3.useState)(false);
  const [results, setResults] = (0, import_react3.useState)([]);
  const [count, setCount] = (0, import_react3.useState)(0);
  const [page, setPage] = (0, import_react3.useState)(1);
  const [hasMore, setHasMore] = (0, import_react3.useState)(false);
  const [searching, setSearching] = (0, import_react3.useState)(false);
  const [error, setError] = (0, import_react3.useState)(null);
  const [open, setOpen] = (0, import_react3.useState)(null);
  const [picked, setPicked] = (0, import_react3.useState)(() => /* @__PURE__ */ new Set());
  const [busy, setBusy] = (0, import_react3.useState)("");
  const thumbs = useThumbs(client);
  const api = getApi();
  const seq = (0, import_react3.useRef)(0);
  const run = (0, import_react3.useCallback)(async (nextPage = 1, f = filters) => {
    if (!client) return;
    const mine = ++seq.current;
    setSearching(true);
    setError(null);
    try {
      const res = await client.searchDocuments(f, nextPage);
      if (mine !== seq.current) return;
      setResults((prev) => nextPage === 1 ? res.results : [...prev, ...res.results]);
      setCount(res.count);
      setHasMore(res.hasMore);
      setPage(nextPage);
    } catch (err) {
      if (mine === seq.current) setError(err);
    } finally {
      if (mine === seq.current) setSearching(false);
    }
  }, [client, filters]);
  (0, import_react3.useEffect)(() => {
    if (client) void run(1);
  }, [client]);
  const set = (patch) => setFilters((prev) => ({ ...prev, ...patch }));
  const pickedDocs = results.filter((d) => picked.has(d.id));
  const attach = async (docs) => {
    setBusy("attach");
    setError(null);
    try {
      await attachDocuments(api, client, docs, (i, n) => setBusy(t("browse.attaching", { current: i + 1, total: n })));
      if (inDialog) onClose?.();
    } catch (err) {
      setError(err);
    } finally {
      setBusy("");
    }
  };
  const download = async (doc) => {
    setBusy("download");
    setError(null);
    try {
      await downloadDocument(api, client, doc);
    } catch (err) {
      setError(err);
    } finally {
      setBusy("");
    }
  };
  if (loading) return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "pl pl-page", children: [
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(Styles, {}),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("p", { className: "pl-muted", children: t("common.loading") })
  ] });
  if (connection?.state === "disconnected") {
    return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "pl pl-page", children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(Styles, {}),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("h2", { children: t("page.title") }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(ConnectPanel, { connection, onConnected: () => refresh() })
    ] });
  }
  if (connection?.state === "error") {
    return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "pl pl-page", children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(Styles, {}),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("h2", { children: t("page.title") }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(ErrorBox, { error: connection.error, onRetry: refresh })
    ] });
  }
  return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: `pl${inDialog ? "" : " pl-page"}`, children: [
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(Styles, {}),
    !inDialog && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("h2", { children: t("page.title") }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { role: "search", className: "pl-row", children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("label", { htmlFor: "pl-q", className: "pl-sr", children: t("browse.search_label") }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
        "input",
        {
          id: "pl-q",
          type: "search",
          className: "pl-grow",
          style: { flexBasis: 220 },
          placeholder: t("browse.search_placeholder"),
          value: filters.text,
          onChange: (e) => set({ text: e.target.value }),
          onKeyDown: (e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              setOpen(null);
              void run(1);
            }
          }
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { type: "button", className: "pl-primary", disabled: searching, onClick: () => {
        setOpen(null);
        void run(1);
      }, children: t("browse.search") }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { type: "button", "aria-expanded": showFilters, "aria-controls": "pl-filters", onClick: () => setShowFilters((v) => !v), children: t("browse.filters") })
    ] }),
    showFilters && tax && /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { id: "pl-filters", className: "pl-card", style: { marginTop: 8 }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "pl-grid", children: [
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
          PickOne,
          {
            id: "pl-f-corr",
            label: t("field.correspondent"),
            items: tax.correspondents,
            value: filters.correspondent,
            onChange: (v) => set({ correspondent: v }),
            noneLabel: t("common.any")
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
          PickOne,
          {
            id: "pl-f-type",
            label: t("field.document_type"),
            items: tax.documentTypes,
            value: filters.documentType,
            onChange: (v) => set({ documentType: v }),
            noneLabel: t("common.any")
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(Field, { id: "pl-f-from", label: t("browse.from"), children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("input", { id: "pl-f-from", type: "date", value: filters.from, onChange: (e) => set({ from: e.target.value }) }) }),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(Field, { id: "pl-f-to", label: t("browse.to"), children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("input", { id: "pl-f-to", type: "date", value: filters.to, onChange: (e) => set({ to: e.target.value }) }) })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { style: { marginTop: 8 }, children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(TagPicker, { tags: tax.tags, value: filters.tags, onChange: (v) => set({ tags: v }), label: t("browse.with_tags") }) }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "pl-actions", children: [
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { type: "button", onClick: () => {
          const empty = { text: filters.text, tags: [], correspondent: null, documentType: null, from: "", to: "" };
          setFilters(empty);
          void run(1, empty);
        }, children: t("browse.clear_filters") }),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { type: "button", className: "pl-primary", onClick: () => {
          setOpen(null);
          void run(1);
        }, children: t("browse.apply") })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(ErrorBox, { error }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("p", { className: "pl-muted", "aria-live": "polite", style: { marginTop: 8 }, children: searching ? t("browse.searching") : t("browse.count", { count }) }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "pl-docs", children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("ul", { className: "pl-list", "aria-label": t("browse.results"), children: [
        results.map((doc) => /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("li", { className: `pl-item${open?.id === doc.id ? " pl-active" : ""}`, children: [
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
            "input",
            {
              type: "checkbox",
              "aria-label": t("browse.select", { title: doc.title }),
              checked: picked.has(doc.id),
              onChange: () => setPicked((prev) => {
                const n = new Set(prev);
                if (n.has(doc.id)) n.delete(doc.id);
                else n.add(doc.id);
                return n;
              })
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(Thumb, { id: doc.id, thumbs, alt: "" }),
          /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "pl-grow", children: [
            /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { type: "button", className: "pl-link pl-name", style: { textAlign: "start", padding: 0 }, onClick: () => setOpen(doc), children: doc.title }),
            /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "pl-muted", children: [nameOf(tax?.correspondents, doc.correspondent), formatDate(doc.created)].filter(Boolean).join(" · ") }),
            /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "pl-row", style: { marginTop: 4 }, children: [
              nameOf(tax?.documentTypes, doc.document_type) && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "pl-badge pl-type", children: nameOf(tax?.documentTypes, doc.document_type) }),
              (doc.tags || []).map((id) => nameOf(tax?.tags, id)).filter(Boolean).map((n) => /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "pl-badge", children: n }, n))
            ] })
          ] })
        ] }, doc.id)),
        hasMore && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { type: "button", onClick: () => run(page + 1), disabled: searching, children: t("browse.more") }) })
      ] }),
      open && /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("section", { className: "pl-card pl-detail", "aria-label": open.title, children: [
        /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "pl-row", style: { justifyContent: "space-between" }, children: [
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("h3", { style: { margin: 0 }, children: open.title }),
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { type: "button", onClick: () => setOpen(null), "aria-label": t("common.close"), children: "×" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(Preview, { client, doc: open, thumbs }),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("dl", { className: "pl-dl", children: [
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("dt", { children: t("field.correspondent") }),
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("dd", { children: nameOf(tax?.correspondents, open.correspondent) || "-" }),
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("dt", { children: t("field.document_type") }),
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("dd", { children: nameOf(tax?.documentTypes, open.document_type) || "-" }),
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("dt", { children: t("field.created") }),
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("dd", { children: formatDate(open.created) }),
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("dt", { children: t("field.file") }),
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("dd", { children: open.original_file_name || "-" })
        ] }),
        open.content && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "pl-content", tabIndex: 0, "aria-label": t("browse.text"), children: String(open.content).slice(0, 2e3) }),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "pl-actions", children: [
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { type: "button", onClick: () => api.ui.openExternalUrl(client.documentUrl(open.id)), children: t("browse.open_in_paperless") }),
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { type: "button", onClick: () => download(open), disabled: !!busy, children: t("browse.download") }),
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { type: "button", className: "pl-primary", onClick: () => attach([open]), disabled: !!busy, children: t("browse.attach") })
        ] })
      ] })
    ] }),
    picked.size > 0 && /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "pl-bar pl-row", children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "pl-grow", children: t("browse.selected", { count: picked.size }) }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { type: "button", onClick: () => setPicked(/* @__PURE__ */ new Set()), children: t("browse.clear_selection") }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { type: "button", className: "pl-primary", disabled: !!busy || pickedDocs.length === 0, onClick: () => attach(pickedDocs), children: t("browse.attach_count", { count: picked.size }) })
    ] }),
    busy && busy !== "attach" && busy !== "download" && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("p", { className: "pl-muted", "aria-live": "polite", children: busy }),
    busy === "attach" && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("p", { className: "pl-muted", "aria-live": "polite", children: t("common.working") })
  ] });
}

// paperless/src/ui/Settings.jsx
var import_react4 = require("react");
var import_jsx_runtime4 = require("react/jsx-runtime");
function Settings() {
  const { connection, client, loading, refresh } = useConnection();
  const [who, setWho] = (0, import_react4.useState)("");
  const [error, setError] = (0, import_react4.useState)(null);
  const api = getApi();
  (0, import_react4.useEffect)(() => {
    if (!client) return;
    client.whoAmI().then((w) => setWho(w.username)).catch((err) => setError(err));
  }, [client]);
  const disconnect = async () => {
    await api.proxy.disconnect(PERSONAL).catch(() => {
    });
    setWho("");
    setError(null);
    await refresh();
  };
  const browse = () => api.ui.openDialog({ title: t("page.title"), slot: "plugin-dialog", extraProps: { view: "browse" }, width: 1e3 });
  return /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "pl", style: { padding: 4 }, children: [
    /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(Styles, {}),
    /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("h2", { children: t("settings.title") }),
    loading && /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("p", { className: "pl-muted", children: t("common.loading") }),
    connection?.state === "disconnected" && /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(ConnectPanel, { connection, onConnected: () => refresh() }),
    connection?.state === "error" && /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "pl-card", children: [
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(ErrorBox, { error: connection.error, onRetry: refresh }),
      connection.mode === "shared" && /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("p", { className: "pl-muted", children: t("settings.shared_error") })
    ] }),
    connection?.state === "connected" && /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "pl-card", children: [
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("p", { children: connection.mode === "shared" ? t("settings.connected_shared", { host: hostOf(connection.base) }) : who ? t("settings.connected_as", { host: hostOf(connection.base), user: who }) : t("settings.connected", { host: hostOf(connection.base) }) }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(ErrorBox, { error }),
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)("div", { className: "pl-actions", style: { justifyContent: "flex-start" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("button", { type: "button", className: "pl-primary", onClick: browse, children: t("settings.browse") }),
        connection.mode === "personal" && /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("button", { type: "button", onClick: disconnect, children: t("settings.disconnect") })
      ] })
    ] })
  ] });
}

// paperless/src/index.js
var background = null;
async function activate(api) {
  setApi(api);
  background = createBackground(api);
  await background.registerUi();
  api.i18n.onLocaleChange(() => {
    void background.registerUi();
  });
  await background.resume();
}
var hooks = {
  onAction(event) {
    if (background) void Promise.resolve(background.onAction(event)).catch(() => {
    });
  },
  onNotificationClick(event) {
    if (background) void background.onNotificationClick(event).catch(() => {
    });
  },
  onInterval() {
    if (background && !background.poller.running) void background.resume();
  }
};
function Dialog(props) {
  if (props.view === "send") return (0, import_react5.createElement)(SendDialog, props);
  return (0, import_react5.createElement)(DocumentBrowser, { inDialog: true, onClose: () => props.onResult?.(null) });
}
var slots = {
  "plugin-dialog": { component: Dialog },
  "app-page": { component: () => (0, import_react5.createElement)(DocumentBrowser, {}) },
  "settings-section": { component: Settings }
};
