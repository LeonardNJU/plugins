var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// paperless/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);

// paperless/src/ui/host.js
var current = null;
function setApi(api) {
  current = api;
}
function getApi() {
  if (current) return current;
  current = require("@plugin-host");
  return current;
}
function t(key, vars) {
  return getApi().i18n.t(key, vars);
}
function hostOf(url) {
  try {
    return new URL(url).host;
  } catch {
    return String(url || "");
  }
}

// paperless/src/ui/Settings.jsx
var import_react2 = require("react");

// paperless/src/ui/common.jsx
var import_react = require("react");

// paperless/src/ui/styles.js
var CSS = `
.pl { color: var(--color-foreground); background: var(--color-background); font-size: 14px; line-height: 1.45; box-sizing: border-box; }
.pl *, .pl *::before, .pl *::after { box-sizing: border-box; }
.pl-page { padding: 16px; max-width: 1100px; margin: 0 auto; }
.pl h2 { font-size: 18px; font-weight: 600; margin: 0 0 4px; }
.pl h3 { font-size: 15px; font-weight: 600; margin: 16px 0 8px; }
.pl p { margin: 4px 0 8px; }
.pl-muted { color: var(--color-muted-foreground); font-size: 13px; }
.pl-row { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
.pl-grow { flex: 1 1 auto; min-width: 0; }
.pl-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 10px; }
.pl .pl-field { display: flex; flex-direction: column; gap: 4px; font-size: 12px; font-weight: 500; }
.pl input[type=text], .pl input[type=search], .pl input[type=date], .pl select {
  height: 34px; padding: 0 10px; border: 1px solid var(--color-input); border-radius: 6px;
  background: var(--color-background); color: var(--color-foreground); font: inherit; font-size: 14px; width: 100%; min-width: 0;
}
.pl input:focus-visible, .pl select:focus-visible, .pl button:focus-visible, .pl a:focus-visible, .pl [tabindex]:focus-visible {
  outline: 2px solid var(--color-ring); outline-offset: 1px;
}
.pl button { font: inherit; font-size: 14px; cursor: pointer; border-radius: 6px; height: 34px; padding: 0 12px;
  border: 1px solid var(--color-border); background: var(--color-background); color: var(--color-foreground); white-space: nowrap; }
.pl button:hover:not(:disabled) { background: var(--color-muted); }
.pl button:disabled { opacity: .55; cursor: default; }
.pl button.pl-primary { background: var(--color-primary); color: var(--color-primary-foreground); border-color: var(--color-primary); }
.pl button.pl-primary:hover:not(:disabled) { filter: brightness(1.08); background: var(--color-primary); }
.pl button.pl-danger { color: var(--color-destructive); }
.pl button.pl-link { border: none; background: none; padding: 0 4px; height: auto; color: var(--color-primary); text-decoration: underline; }
.pl-card { border: 1px solid var(--color-border); border-radius: 8px; padding: 12px; background: var(--color-card); color: var(--color-card-foreground); }
.pl-list { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 6px; }
.pl-item { display: flex; gap: 10px; align-items: flex-start; padding: 8px; border: 1px solid var(--color-border); border-radius: 8px; background: var(--color-card); }
.pl-item.pl-active { border-color: var(--color-primary); }
.pl-item input[type=checkbox] { margin-top: 3px; width: 16px; height: 16px; flex: none; accent-color: var(--color-primary); }
.pl-name { font-weight: 500; overflow-wrap: anywhere; }
.pl-badge { display: inline-flex; align-items: center; gap: 4px; font-size: 12px; padding: 1px 8px; border-radius: 999px;
  background: var(--color-muted); color: var(--color-muted-foreground); }
.pl-badge.pl-type { background: transparent; border: 1px solid var(--color-border); }
.pl-badge.pl-warn { background: color-mix(in srgb, var(--color-warning) 18%, transparent); color: var(--color-foreground); }
.pl-badge.pl-ok { background: color-mix(in srgb, var(--color-success) 18%, transparent); color: var(--color-foreground); }
.pl-chips { display: flex; flex-wrap: wrap; gap: 6px; max-height: 132px; overflow: auto; padding: 2px; }
.pl-chip { display: inline-flex; align-items: center; gap: 6px; padding: 4px 10px; border-radius: 999px; border: 1px solid var(--color-border);
  font-size: 13px; cursor: pointer; user-select: none; }
.pl-chip input { margin: 0; accent-color: var(--color-primary); }
.pl-chip.pl-on { background: var(--color-accent); color: var(--color-accent-foreground); border-color: transparent; }
.pl-error { border: 1px solid var(--color-destructive); color: var(--color-foreground); background: color-mix(in srgb, var(--color-destructive) 10%, transparent);
  border-radius: 8px; padding: 8px 12px; }
.pl-actions { display: flex; justify-content: flex-end; gap: 8px; flex-wrap: wrap; margin-top: 16px; }
.pl-thumb { width: 64px; height: 84px; flex: none; border-radius: 4px; border: 1px solid var(--color-border); background: var(--color-muted);
  object-fit: cover; object-position: top; }
.pl-docs { display: grid; grid-template-columns: minmax(0, 1fr) minmax(0, 1fr); gap: 16px; align-items: start; }
.pl-detail img.pl-big { width: 100%; max-height: 300px; object-fit: contain; background: var(--color-muted); border-radius: 6px; border: 1px solid var(--color-border); }
.pl-content { white-space: pre-wrap; font-size: 13px; max-height: 220px; overflow: auto; background: var(--color-muted); padding: 8px; border-radius: 6px; }
.pl-dl { display: grid; grid-template-columns: max-content 1fr; gap: 2px 12px; font-size: 13px; margin: 8px 0; }
.pl-dl dt { color: var(--color-muted-foreground); }
.pl-dl dd { margin: 0; overflow-wrap: anywhere; }
.pl-sr { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; }
.pl-bar { position: sticky; bottom: 0; background: var(--color-background); border-top: 1px solid var(--color-border); padding: 8px 0; margin-top: 8px; }
@media (max-width: 520px) {
  .pl-docs { grid-template-columns: minmax(0, 1fr); }
  .pl-page { padding: 12px; }
  .pl-actions button { flex: 1 1 auto; }
}
`;

// paperless/src/lib/errors.js
var PaperlessError = class extends Error {
  /**
   * @param {string} key  i18n key, e.g. 'error.token'
   * @param {Record<string, string|number>} [vars]
   * @param {number} [status] HTTP status, when there was one
   */
  constructor(key, vars = {}, status = 0) {
    super(key);
    this.name = "PaperlessError";
    this.key = key;
    this.vars = vars;
    this.status = status;
  }
};
function detailOf(body) {
  if (body == null) return "";
  if (typeof body === "string") {
    const text = body.trim();
    if (/^[{[]/.test(text)) {
      try {
        return detailOf(JSON.parse(text));
      } catch {
      }
    }
    if (/^<(!doctype|html)/i.test(text)) return "";
    return oneLine(text);
  }
  if (typeof body === "object") {
    if (typeof body.detail === "string") return oneLine(body.detail);
    if (typeof body.error === "string") return oneLine(body.error);
    const parts = [];
    for (const [field, value] of Object.entries(body)) {
      const msg = Array.isArray(value) ? value.filter((v) => typeof v === "string").join(" ") : typeof value === "string" ? value : "";
      if (msg) parts.push(field === "non_field_errors" ? msg : `${field}: ${msg}`);
    }
    return oneLine(parts.join("; "));
  }
  return "";
}
function oneLine(text) {
  const flat = String(text).replace(/\s+/g, " ").trim();
  return flat.length > 200 ? `${flat.slice(0, 197)}...` : flat;
}
function retryAfter(headers) {
  const raw = headers?.["retry-after"];
  const seconds = Number(raw);
  return Number.isFinite(seconds) && seconds > 0 ? Math.ceil(seconds) : 0;
}
function errorFromResponse(res) {
  if (res.proxyError) {
    switch (res.proxyError) {
      case "no_credential":
        return new PaperlessError("error.not_connected", {}, res.status);
      case "rate_limited":
        return new PaperlessError("error.rate_limit", { seconds: retryAfter(res.headers) || 60 }, 429);
      case "timeout":
        return new PaperlessError("error.timeout", {}, 504);
      case "unreachable":
        return new PaperlessError("error.unreachable", {}, 502);
      case "blocked_address":
        return new PaperlessError("error.blocked", {}, 403);
      case "too_large":
        return new PaperlessError("error.too_large", {}, 413);
      case "wrong_origin":
        return new PaperlessError("error.wrong_server", {}, 403);
      default:
        return new PaperlessError("error.proxy", { detail: detailOf(res.body) }, res.status);
    }
  }
  const status = res.status;
  const detail = detailOf(res.body);
  if (status === 401) return new PaperlessError("error.token", {}, status);
  if (status === 403) return new PaperlessError("error.forbidden", {}, status);
  if (status === 404) return new PaperlessError("error.not_found", {}, status);
  if (status === 413) return new PaperlessError("error.too_large", {}, status);
  if (status === 429) return new PaperlessError("error.rate_limit", { seconds: retryAfter(res.headers) || 60 }, status);
  if (status === 507 || /no space left|disk (is )?full|quota/i.test(detail)) return new PaperlessError("error.full", {}, status);
  if (status === 502 || status === 503 || status === 504) return new PaperlessError("error.unavailable", {}, status);
  if (status >= 500) return new PaperlessError("error.server", {}, status);
  if (status >= 400) return new PaperlessError("error.rejected", { detail: detail || `HTTP ${status}` }, status);
  return new PaperlessError("error.unexpected", { detail: `HTTP ${status}` }, status);
}
function toPaperlessError(err) {
  if (err instanceof PaperlessError) return err;
  const message = err && typeof err.message === "string" ? err.message : String(err);
  if (/timed out|timeout/i.test(message)) return new PaperlessError("error.timeout");
  if (/cancel|abort/i.test(message)) return new PaperlessError("error.cancelled");
  if (/larger than/i.test(message)) return new PaperlessError("error.too_large");
  if (/permission|not allowed|not granted/i.test(message)) return new PaperlessError("error.permission");
  if (/network|failed to fetch/i.test(message)) return new PaperlessError("error.unreachable");
  return new PaperlessError("error.unexpected", { detail: oneLine(message.split(/\r?\n/)[0]) });
}
function errorText(t2, err) {
  const e = toPaperlessError(err);
  return t2(e.key, e.vars);
}

// paperless/src/lib/multipart.js
function quote(value) {
  return String(value).replace(/[\r\n]+/g, " ").replace(/(["\\])/g, "\\$1");
}
function randomBoundary() {
  let out = "----BulwarkPaperless";
  for (let i = 0; i < 24; i++) out += Math.floor(Math.random() * 36).toString(36);
  return out;
}
function toBytes(data) {
  if (data instanceof Uint8Array) return data;
  if (data instanceof ArrayBuffer) return new Uint8Array(data);
  if (ArrayBuffer.isView(data)) return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
  return new TextEncoder().encode(String(data));
}
function buildMultipart(fields, boundary = randomBoundary()) {
  const enc = new TextEncoder();
  const chunks = [];
  for (const [name, value] of fields) {
    if (value === void 0 || value === null) continue;
    let head = `--${boundary}\r
Content-Disposition: form-data; name="${quote(name)}"`;
    if (typeof value === "object" && "data" in value) {
      head += `; filename="${quote(value.filename || "document")}"\r
Content-Type: ${value.type || "application/octet-stream"}\r
\r
`;
      chunks.push(enc.encode(head), toBytes(value.data), enc.encode("\r\n"));
    } else {
      head += "\r\n\r\n";
      chunks.push(enc.encode(head), enc.encode(String(value)), enc.encode("\r\n"));
    }
  }
  chunks.push(enc.encode(`--${boundary}--\r
`));
  const size = chunks.reduce((n, c) => n + c.byteLength, 0);
  const body = new Uint8Array(size);
  let offset = 0;
  for (const c of chunks) {
    body.set(c, offset);
    offset += c.byteLength;
  }
  return { body, contentType: `multipart/form-data; boundary=${boundary}` };
}

// paperless/src/lib/client.js
var PAGE_SIZE = 25;
var ACCEPT = "application/json";
function normalizeBase(value) {
  if (typeof value !== "string" || !value.trim()) return "";
  let text = value.trim();
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(text)) text = `https://${text}`;
  try {
    const url = new URL(text);
    if (url.protocol !== "https:" && url.protocol !== "http:") return "";
    const path = url.pathname.replace(/\/+$/, "").replace(/\/api$/, "");
    return `${url.origin}${path}`;
  } catch {
    return "";
  }
}
function documentQuery(filters = {}, page = 1, pageSize = PAGE_SIZE) {
  const q = new URLSearchParams();
  const text = (filters.text || "").trim();
  if (text) q.set("title_content", text);
  const tags = (filters.tags || []).filter((id) => Number.isInteger(id));
  if (tags.length) q.set("tags__id__all", tags.join(","));
  if (Number.isInteger(filters.correspondent)) q.set("correspondent__id__in", String(filters.correspondent));
  if (Number.isInteger(filters.documentType)) q.set("document_type__id__in", String(filters.documentType));
  if (/^\d{4}-\d{2}-\d{2}$/.test(filters.from || "")) q.set("created__date__gte", filters.from);
  if (/^\d{4}-\d{2}-\d{2}$/.test(filters.to || "")) q.set("created__date__lte", filters.to);
  q.set("ordering", "-created");
  q.set("page", String(page));
  q.set("page_size", String(pageSize));
  q.set("fields", "id,title,correspondent,document_type,tags,created,original_file_name,mime_type,content,page_count");
  return q.toString();
}
function normalizeTask(json) {
  const list = Array.isArray(json) ? json : Array.isArray(json?.results) ? json.results : [];
  const task = list[0];
  if (!task) return { state: "unknown", documentId: null, error: "", duplicateOf: null };
  const status = String(task.status || "").toLowerCase();
  let documentId = null;
  const fromData = task.result_data?.document_id;
  if (Number.isInteger(fromData)) documentId = fromData;
  else if (Array.isArray(task.related_document_ids) && Number.isInteger(task.related_document_ids[0])) documentId = task.related_document_ids[0];
  else if (task.related_document != null && /^\d+$/.test(String(task.related_document))) documentId = Number(task.related_document);
  const resultText = typeof task.result === "string" ? task.result : task.result_data?.error_message || "";
  let duplicateOf = null;
  const dup = /duplicate of .*?\(#(\d+)\)/i.exec(resultText);
  if (dup) duplicateOf = Number(dup[1]);
  if (status === "success") {
    if (documentId == null) {
      const m = /document id (\d+)/i.exec(resultText);
      if (m) documentId = Number(m[1]);
    }
    return { state: "success", documentId, error: "", duplicateOf: null };
  }
  if (status === "failure" || status === "revoked") {
    return { state: "failure", documentId: null, error: cleanTaskError(resultText), duplicateOf };
  }
  if (["pending", "started", "received", "retry"].includes(status)) return { state: "pending", documentId: null, error: "", duplicateOf: null };
  return { state: "unknown", documentId: null, error: "", duplicateOf: null };
}
function cleanTaskError(text) {
  let msg = String(text || "").split("\n")[0].trim();
  msg = msg.replace(/^[^:]{1,255}: (?=(error|not consuming|unsupported|cannot|could not))/i, "");
  msg = msg.replace(/^Error occurred while consuming document [^:]+: /i, "");
  msg = msg.replace(/\[Errno \d+\]\s*/g, "");
  return msg.length > 200 ? `${msg.slice(0, 197)}...` : msg;
}
function createClient({ proxyFetch, credentialId, base }) {
  if (!base) throw new PaperlessError("error.not_connected");
  async function request(path, { method = "GET", headers = {}, body, responseType = "json", signal, onProgress } = {}) {
    const url = /^https?:\/\//.test(path) ? path : `${base}${path}`;
    const init = { method, headers: { Accept: ACCEPT, ...headers }, responseType };
    if (body !== void 0) init.body = body;
    if (signal) init.signal = signal;
    if (onProgress) init.onProgress = onProgress;
    const res = await proxyFetch(credentialId, url, init);
    if (!res || !res.ok) throw errorFromResponse(res || { status: 0, headers: {} });
    return res;
  }
  async function json(path, opts) {
    const res = await request(path, { ...opts, responseType: "text" });
    const text = typeof res.body === "string" ? res.body : "";
    if (!text) return null;
    try {
      return JSON.parse(text);
    } catch {
      throw new PaperlessError("error.not_paperless", {}, res.status);
    }
  }
  async function listAll(path, max = 2e3) {
    const out = [];
    for (let page = 1; out.length < max; page++) {
      const sep = path.includes("?") ? "&" : "?";
      const data = await json(`${path}${sep}page=${page}&page_size=250`);
      const results = Array.isArray(data) ? data : data?.results ?? [];
      out.push(...results);
      if (Array.isArray(data) || !data?.next || results.length === 0) break;
    }
    return out;
  }
  const pick = (rows) => rows.map((r) => ({
    id: r.id,
    name: String(r.name ?? ""),
    match: String(r.match ?? ""),
    matchingAlgorithm: r.matching_algorithm ?? 0
  })).sort((a, b) => a.name.localeCompare(b.name));
  return {
    base,
    credentialId,
    request,
    /** Who the token belongs to; also checks the connection. */
    async whoAmI() {
      const data = await json("/api/ui_settings/");
      return { username: data?.user?.username || "", version: data?.settings?.version || "" };
    },
    async taxonomies() {
      const [tags, correspondents, documentTypes, storagePaths] = await Promise.all([
        listAll("/api/tags/?fields=id,name,match,matching_algorithm,color"),
        listAll("/api/correspondents/?fields=id,name,match,matching_algorithm"),
        listAll("/api/document_types/?fields=id,name,match,matching_algorithm"),
        listAll("/api/storage_paths/?fields=id,name,match,matching_algorithm").catch(() => [])
      ]);
      return { tags: pick(tags), correspondents: pick(correspondents), documentTypes: pick(documentTypes), storagePaths: pick(storagePaths) };
    },
    async searchDocuments(filters, page = 1, pageSize = PAGE_SIZE) {
      const data = await json(`/api/documents/?${documentQuery(filters, page, pageSize)}`);
      const results = Array.isArray(data?.results) ? data.results : [];
      return { count: data?.count ?? results.length, results, hasMore: !!data?.next };
    },
    /** The first document with this content, by SHA-256 (Paperless 3) or MD5 (older). */
    async findByChecksum({ sha256, md5 }) {
      for (const sum of [sha256, md5]) {
        if (!sum) continue;
        const data = await json(`/api/documents/?checksum__iexact=${encodeURIComponent(sum)}&fields=id,title&page_size=1`);
        const hit = data?.results?.[0];
        if (hit) return { id: hit.id, title: String(hit.title ?? "") };
      }
      return null;
    },
    /**
     * Hand a file to Paperless. Resolves to the consume task's id.
     * @param {{ data: Uint8Array|ArrayBuffer, name: string, type?: string, title?: string, correspondent?: number|null,
     *   documentType?: number|null, storagePath?: number|null, tags?: number[], created?: string }} doc
     */
    async upload(doc, { signal, onProgress } = {}) {
      const fields = [["document", { filename: doc.name, type: doc.type, data: doc.data }]];
      if (doc.title) fields.push(["title", doc.title.slice(0, 128)]);
      if (doc.created) fields.push(["created", doc.created]);
      if (Number.isInteger(doc.correspondent)) fields.push(["correspondent", doc.correspondent]);
      if (Number.isInteger(doc.documentType)) fields.push(["document_type", doc.documentType]);
      if (Number.isInteger(doc.storagePath)) fields.push(["storage_path", doc.storagePath]);
      for (const tag of doc.tags || []) if (Number.isInteger(tag)) fields.push(["tags", tag]);
      const { body, contentType } = buildMultipart(fields);
      const res = await request("/api/documents/post_document/", {
        method: "POST",
        headers: { "Content-Type": contentType },
        body,
        responseType: "text",
        signal,
        onProgress
      });
      let taskId = String(res.body ?? "").trim();
      try {
        const parsed = JSON.parse(taskId);
        if (typeof parsed === "string") taskId = parsed;
        else if (parsed?.task_id) taskId = parsed.task_id;
      } catch {
      }
      if (!/^[0-9a-f-]{8,64}$/i.test(taskId)) throw new PaperlessError("error.unexpected", { detail: "no task id" });
      return taskId;
    },
    async task(taskId) {
      return normalizeTask(await json(`/api/tasks/?task_id=${encodeURIComponent(taskId)}`));
    },
    async document(id) {
      return json(`/api/documents/${id}/`);
    },
    async thumbnail(id, signal) {
      const res = await request(`/api/documents/${id}/thumb/`, { responseType: "arraybuffer", signal });
      return { data: res.body, type: res.headers?.["content-type"] || "image/webp" };
    },
    async preview(id, signal) {
      const res = await request(`/api/documents/${id}/preview/`, { responseType: "arraybuffer", signal });
      return { data: res.body, type: res.headers?.["content-type"] || "application/pdf" };
    },
    /** The original file with its name from Content-Disposition. */
    async download(id, fallbackName = "document") {
      const res = await request(`/api/documents/${id}/download/?original=true`, { responseType: "arraybuffer" });
      const type = (res.headers?.["content-type"] || "application/octet-stream").split(";")[0].trim();
      return { data: res.body, type, name: filenameFromDisposition(res.headers?.["content-disposition"]) || fallbackName };
    },
    documentUrl(id) {
      return `${base}/documents/${id}/details`;
    }
  };
}
function filenameFromDisposition(header) {
  if (typeof header !== "string") return "";
  const star = /filename\*\s*=\s*([^']*)'[^']*'([^;]+)/i.exec(header);
  if (star) {
    try {
      return decodeURIComponent(star[2].trim());
    } catch {
    }
  }
  const plain = /filename\s*=\s*"((?:[^"\\]|\\.)*)"|filename\s*=\s*([^;]+)/i.exec(header);
  if (plain) return (plain[1] ?? plain[2] ?? "").replace(/\\(.)/g, "$1").trim();
  return "";
}

// paperless/src/lib/connection.js
var SHARED = "shared";
var PERSONAL = "personal";
async function adminServer(api) {
  try {
    return normalizeBase(await api.admin.getConfig("serverUrl"));
  } catch {
    return "";
  }
}
async function resolveConnection(api) {
  const configured = await adminServer(api);
  if (configured) {
    let res;
    try {
      res = await api.proxy.fetch(SHARED, `${configured}/api/ui_settings/`, { headers: { Accept: "application/json" }, responseType: "text" });
    } catch (err) {
      return { state: "error", error: toPaperlessError(err), mode: SHARED, suggestedServer: configured };
    }
    if (res?.ok) return { state: "connected", mode: SHARED, base: configured, credentialId: SHARED };
    if (res?.proxyError !== "no_credential") {
      return { state: "error", error: errorFromResponse(res || { status: 0 }), mode: SHARED, suggestedServer: configured };
    }
  }
  let accounts = [];
  try {
    accounts = await api.proxy.accounts() || [];
  } catch {
    accounts = [];
  }
  const mine = accounts.find((a) => a.credentialId === PERSONAL && a.connected);
  if (mine) {
    const base = configured && new URL(configured).origin === mine.origin ? configured : normalizeBase(mine.origin);
    return { state: "connected", mode: PERSONAL, base, credentialId: PERSONAL };
  }
  return { state: "disconnected", suggestedServer: configured };
}
function clientFor(api, connection) {
  if (!connection || connection.state !== "connected") {
    throw connection?.state === "error" ? connection.error : new PaperlessError("error.not_connected");
  }
  return createClient({ proxyFetch: (...a) => api.proxy.fetch(...a), credentialId: connection.credentialId, base: connection.base });
}
async function connectPersonal(api, suggestedServer) {
  const result = await api.proxy.connect(PERSONAL, { mode: "password", ...suggestedServer ? { server: suggestedServer } : {} });
  if (!result?.connected) return { connected: false };
  const connection = await resolveConnection(api);
  if (connection.state !== "connected") return { connected: false };
  try {
    await clientFor(api, connection).whoAmI();
  } catch (err) {
    const e = toPaperlessError(err);
    if (e.key === "error.token") await api.proxy.disconnect(PERSONAL).catch(() => {
    });
    return { connected: false, error: e };
  }
  return { connected: true, connection };
}

// paperless/src/ui/common.jsx
var import_jsx_runtime = require("react/jsx-runtime");
function Styles() {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: CSS });
}
function useConnection(initial) {
  const [connection, setConnection] = (0, import_react.useState)(initial || null);
  const [loading, setLoading] = (0, import_react.useState)(!initial);
  const refresh = (0, import_react.useCallback)(async () => {
    setLoading(true);
    try {
      setConnection(await resolveConnection(getApi()));
    } finally {
      setLoading(false);
    }
  }, []);
  (0, import_react.useEffect)(() => {
    if (!initial) void refresh();
  }, [initial, refresh]);
  const client = (0, import_react.useMemo)(() => connection?.state === "connected" ? clientFor(getApi(), connection) : null, [connection]);
  return { connection, client, loading, refresh };
}
function ErrorBox({ error, onRetry }) {
  if (!error) return null;
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "pl-error", role: "alert", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: errorText(t, error) }),
    onRetry && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
      " ",
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "pl-link", onClick: onRetry, children: t("common.retry") })
    ] })
  ] });
}
function ConnectPanel({ connection, onConnected }) {
  const [busy, setBusy] = (0, import_react.useState)(false);
  const [error, setError] = (0, import_react.useState)(null);
  const connect = async () => {
    setBusy(true);
    setError(null);
    try {
      const result = await connectPersonal(getApi(), connection?.suggestedServer || "");
      if (result.connected) onConnected?.(result.connection);
      else if (result.error) setError(result.error);
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  };
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "pl-card", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: connection?.suggestedServer ? t("connect.intro_server", { host: hostOf(connection.suggestedServer) }) : t("connect.intro") }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "pl-muted", children: t("connect.token_hint") }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBox, { error }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pl-actions", style: { justifyContent: "flex-start" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "pl-primary", onClick: connect, disabled: busy, children: busy ? t("common.working") : t("connect.button") }) })
  ] });
}

// paperless/src/ui/Settings.jsx
var import_jsx_runtime2 = require("react/jsx-runtime");
function Settings() {
  const { connection, client, loading, refresh } = useConnection();
  const [who, setWho] = (0, import_react2.useState)("");
  const [error, setError] = (0, import_react2.useState)(null);
  const api = getApi();
  (0, import_react2.useEffect)(() => {
    if (!client) return;
    client.whoAmI().then((w) => setWho(w.username)).catch((err) => setError(err));
  }, [client]);
  const disconnect = async () => {
    await api.proxy.disconnect(PERSONAL).catch(() => {
    });
    setWho("");
    setError(null);
    await refresh();
  };
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "pl", style: { padding: 4 }, children: [
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(Styles, {}),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("h2", { children: t("settings.title") }),
    loading && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { className: "pl-muted", children: t("common.loading") }),
    connection?.state === "disconnected" && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(ConnectPanel, { connection, onConnected: () => refresh() }),
    connection?.state === "error" && /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "pl-card", children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(ErrorBox, { error: connection.error, onRetry: refresh }),
      connection.mode === "shared" && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { className: "pl-muted", children: t("settings.shared_error") })
    ] }),
    connection?.state === "connected" && /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "pl-card", children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { children: connection.mode === "shared" ? t("settings.connected_shared", { host: hostOf(connection.base) }) : who ? t("settings.connected_as", { host: hostOf(connection.base), user: who }) : t("settings.connected", { host: hostOf(connection.base) }) }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(ErrorBox, { error }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { className: "pl-actions", style: { justifyContent: "flex-start" }, children: connection.mode === "personal" && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("button", { type: "button", onClick: disconnect, children: t("settings.disconnect") }) })
    ] })
  ] });
}

// paperless/src/index.js
async function activate(api) {
  setApi(api);
}
var slots = {
  "settings-section": { component: Settings }
};
