var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// plugin-template/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);

// plugin-template/src/lib/ui.js
var import_ui = require("@plugin-host/ui");
var ITEMS_KEY = "items";
async function readItems(api2) {
  const stored = await api2.storage.get(ITEMS_KEY);
  return Array.isArray(stored) ? stored : [];
}
async function addItem(api2, name) {
  const items = await readItems(api2);
  const next = [...items, { id: `${Date.now()}-${items.length}`, name }];
  await api2.storage.set(ITEMS_KEY, next);
  return next;
}
async function askForItem(api2) {
  const t = (key) => api2.i18n.t(key);
  const name = await api2.ui.openDialog({ title: t("dialog.title"), slot: "plugin-dialog" });
  return typeof name === "string" && name.trim() ? name.trim() : null;
}
function makeSection(React2, api2) {
  const { createElement: h, useCallback, useEffect, useState } = React2;
  const t = (key, vars) => api2.i18n.t(key, vars);
  return function ItemsSection() {
    const [items, setItems] = useState(null);
    const refresh = useCallback(async () => setItems(await readItems(api2)), []);
    useEffect(() => {
      void refresh();
      window.addEventListener("focus", refresh);
      return () => window.removeEventListener("focus", refresh);
    }, [refresh]);
    const add = async () => {
      const name = await askForItem(api2);
      if (name) setItems(await addItem(api2, name));
    };
    if (items === null) return null;
    return h(
      React2.Fragment,
      null,
      items.length === 0 ? h(import_ui.SidebarEmpty, null, t("section.empty")) : null,
      ...items.map((item) => h(import_ui.SidebarRow, { key: item.id, icon: "bookmark", label: item.name })),
      h(import_ui.SidebarRow, { icon: "plus", label: h(import_ui.Text, { tone: "muted", truncate: true }, t("action.add")), onClick: add })
    );
  };
}
function makeDialog(React2, api2) {
  const { createElement: h, useState } = React2;
  const t = (key, vars) => api2.i18n.t(key, vars);
  return function AddDialog(props) {
    const [name, setName] = useState("");
    const ready = name.trim().length > 0;
    const close = (value) => props.onResult?.(value);
    return h(
      import_ui.Stack,
      { gap: 4 },
      h(
        import_ui.Field,
        { label: t("dialog.name"), hint: t("dialog.hint") },
        h(import_ui.Input, {
          value: name,
          autoFocus: true,
          onChange: (e) => setName(e.target.value),
          onKeyDown: (e) => {
            if (e.key === "Enter" && ready) close(name.trim());
          }
        })
      ),
      h(import_ui.DialogButtons, {
        buttons: [
          { id: "cancel", label: t("dialog.cancel"), variant: "secondary" },
          { id: "add", label: t("dialog.add"), variant: "primary", disabled: !ready }
        ],
        onClick: (id) => close(id === "add" ? name.trim() : null)
      })
    );
  };
}

// plugin-template/src/index.js
var React = require("react");
var api = require("@plugin-host");
var slots = {
  // A section in the mail sidebar, below the folders (ui:sidebar-widget).
  "sidebar-section": {
    component: makeSection(React, api),
    // shouldShow runs in the BACKGROUND iframe. Return false to skip
    // mounting the slot iframe entirely.
    shouldShow: () => api.plugin.settings.enabled !== false,
    order: 100
  },
  // The body of the dialog api.ui.openDialog opens (ui:observe).
  "plugin-dialog": {
    component: makeDialog(React, api)
  }
};
var hooks = {
  // Needs email:read, declared in manifest.json.
  onEmailOpen(email) {
    if (api.plugin.settings.enabled === false) return;
    api.log.info("Email opened:", email?.subject);
  },
  // A click on an entry declared with api.ui.setActions.
  async onAction({ actionId }) {
    if (actionId !== "add") return;
    const name = await askForItem(api);
    if (name) {
      await addItem(api, name);
      api.toast.success(api.i18n.t("toast.added", { name }));
    }
  }
  // Intercept hooks may return a Promise. Return `false` to cancel.
  // onBeforeEmailSend needs email:send.
  // async onBeforeEmailSend(draft) {
  //   const ok = await api.ui.confirm({ title: 'Send?', message: '...' });
  //   return ok ? undefined : false;
  // },
};
async function publish(pluginApi) {
  const t = (key) => pluginApi.i18n.t(key);
  const custom = String(pluginApi.plugin.settings.sectionTitle || "").trim();
  await pluginApi.ui.setSectionTitle((custom || t("section.title")).slice(0, 40));
  await pluginApi.ui.setActions("command-palette", [{ id: "add", label: t("action.add"), icon: "plus" }]);
}
async function activate(pluginApi) {
  if (pluginApi.plugin.settings.enabled === false) {
    pluginApi.log.info("Plugin disabled by user settings");
    return;
  }
  await publish(pluginApi);
  pluginApi.i18n.onLocaleChange(() => {
    void publish(pluginApi);
  });
  pluginApi.plugin.onSettingsChange(() => {
    void publish(pluginApi);
  });
}
