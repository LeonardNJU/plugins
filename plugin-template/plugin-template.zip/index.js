var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// plugin-template/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);
var { createElement: h, useState } = require("react");
var api = require("@plugin-host");
var t = (key, vars) => api.i18n.t(key, vars);
function MyWidget() {
  const [count, setCount] = useState(0);
  const title = String(api.plugin.settings.widgetTitle || "").trim() || t("widget.title");
  return h(
    "div",
    { style: { padding: "12px", fontSize: "13px" } },
    h("div", { style: { fontWeight: 600, marginBottom: "8px" } }, title),
    h(
      "button",
      {
        type: "button",
        onClick: () => setCount((c) => c + 1),
        style: {
          font: "inherit",
          padding: "6px 10px",
          borderRadius: "6px",
          border: "1px solid var(--color-input)",
          background: "var(--color-muted)",
          color: "var(--color-foreground)",
          cursor: "pointer"
        }
      },
      t("widget.clicked", { count })
    )
  );
}
var slots = {
  // Pick a slot name from SlotName in lib/plugin-types.ts and add the
  // permission it needs to manifest.json:
  //   toolbar-actions (ui:toolbar), app-top-banner (ui:app-top-banner),
  //   email-banner (ui:email-banner), email-footer (ui:email-footer),
  //   composer-toolbar (ui:composer-toolbar),
  //   composer-sidebar, composer-sidebar-right (ui:composer-sidebar),
  //   sidebar-widget (ui:sidebar-widget),
  //   email-detail-sidebar (ui:email-details),
  //   settings-section (ui:settings-section),
  //   context-menu-email (ui:context-menu),
  //   navigation-rail-bottom (ui:navigation-rail),
  //   calendar-event-actions (ui:calendar-action),
  //   admin-plugin-page (ui:admin-page)
  "sidebar-widget": {
    component: MyWidget,
    // shouldShow runs in the BACKGROUND iframe. Return false to skip
    // mounting the slot iframe entirely.
    shouldShow: () => api.plugin.settings.enabled !== false,
    order: 100
  }
};
var hooks = {
  onAppReady() {
    api.log.info("App is ready");
  },
  // Needs email:read, declared in manifest.json.
  onEmailOpen(email) {
    if (api.plugin.settings.enabled === false) return;
    api.log.info("Email opened:", email?.subject);
  }
  // Intercept hooks may return a Promise. Return `false` to cancel.
  // onBeforeEmailSend needs email:send.
  // async onBeforeEmailSend(draft) {
  //   const ok = await api.ui.confirm({ title: 'Send?', message: '...' });
  //   return ok ? undefined : false;
  // },
};
async function activate(api2) {
  api2.plugin.onSettingsChange((settings) => {
    api2.log.info(`Settings changed (enabled: ${settings.enabled !== false})`);
  });
  if (api2.plugin.settings.enabled === false) {
    api2.log.info("Plugin disabled by user settings");
    return;
  }
  const runCount = Number(await api2.storage.get("runCount") || 0) + 1;
  await api2.storage.set("runCount", runCount);
  api2.log.info(`Plugin activated (run ${runCount})`);
}
