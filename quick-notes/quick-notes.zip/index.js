var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// quick-notes/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);

// quick-notes/src/lib/notes.js
var import_ui = require("@plugin-host/ui");
var SAVE_DELAY_MS = 500;
function withNote(map, emailId, text, maxNotes, now = /* @__PURE__ */ new Date()) {
  const next = map && typeof map === "object" ? { ...map } : {};
  if (!text.trim()) {
    delete next[emailId];
    return next;
  }
  next[emailId] = { text, updatedAt: now.toISOString() };
  const ids = Object.keys(next);
  if (ids.length > maxNotes) {
    const oldest = ids.map((id) => ({ id, t: next[id]?.updatedAt || "" })).sort((a, b) => a.t < b.t ? -1 : a.t > b.t ? 1 : 0).slice(0, ids.length - maxNotes);
    for (const { id } of oldest) delete next[id];
  }
  return next;
}
function makeNoteBanner(React2) {
  return function NoteBanner2() {
    return React2.createElement(import_ui.InfoBar, { compact: true, tone: "primary", icon: "note", title: "This email has a note attached." });
  };
}
function makeNotesPanel(React2, api) {
  const { createElement: h, useCallback, useEffect, useRef, useState } = React2;
  return function NotesPanel(props) {
    const emailId = props?.email?.id || null;
    const [text, setText] = useState("");
    const [savedAt, setSavedAt] = useState(null);
    const [loaded, setLoaded] = useState(false);
    const debounceRef = useRef(null);
    useEffect(() => {
      setLoaded(false);
      if (!emailId) {
        setText("");
        setSavedAt(null);
        setLoaded(true);
        return void 0;
      }
      let cancelled = false;
      (async () => {
        try {
          const stored = await api.storage.get("notes") || {};
          if (cancelled) return;
          const entry = stored && typeof stored === "object" ? stored[emailId] : null;
          setText(entry?.text || "");
          setSavedAt(entry?.updatedAt || null);
        } catch (err) {
          api.log.warn("quick-notes: could not load notes", err);
        } finally {
          if (!cancelled) setLoaded(true);
        }
      })();
      return () => {
        cancelled = true;
      };
    }, [emailId]);
    const persist = useCallback(async (nextText) => {
      if (!emailId) return;
      try {
        const stored = await api.storage.get("notes") || {};
        const maxNotes = Number(api.plugin?.settings?.maxNotes) || 100;
        const map = withNote(stored, emailId, nextText, maxNotes);
        await api.storage.set("notes", map);
        setSavedAt(map[emailId]?.updatedAt || null);
      } catch (err) {
        api.log.warn("quick-notes: save failed", err);
      }
    }, [emailId]);
    const onChange = useCallback((ev) => {
      const next = ev.target.value;
      setText(next);
      if (debounceRef.current) clearTimeout(debounceRef.current);
      debounceRef.current = setTimeout(() => {
        void persist(next);
      }, SAVE_DELAY_MS);
    }, [persist]);
    useEffect(() => () => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current);
        debounceRef.current = null;
      }
    }, [emailId]);
    if (!emailId) {
      return h(import_ui.EmptyState, { compact: true, icon: "note", title: "Quick Notes", description: "Open an email to add a note." });
    }
    return h(import_ui.Page, null, h(
      import_ui.Stack,
      { gap: 3 },
      h(
        import_ui.Row,
        { justify: "between", align: "baseline" },
        h(import_ui.Heading, { level: 3 }, "Quick Notes"),
        savedAt ? h(import_ui.Text, { size: "xs", tone: "muted" }, `Saved ${new Date(savedAt).toLocaleTimeString()}`) : null
      ),
      h(
        import_ui.Field,
        { label: "Note for this email", hint: "Saved half a second after you stop typing." },
        h(import_ui.Textarea, {
          value: loaded ? text : "",
          onChange,
          disabled: !loaded,
          placeholder: "Jot a note for this email…",
          rows: 8
        })
      )
    ));
  };
}

// quick-notes/src/index.js
var React = require("react");
var slotApi = require("@plugin-host");
var pluginApi = null;
var notes = {};
var NoteBanner = makeNoteBanner(React);
var NotesSidebar = makeNotesPanel(React, slotApi);
function shouldShowBanner(extraProps) {
  if (!pluginApi) return false;
  if (pluginApi.plugin.settings.showBanner === false) return false;
  const email = extraProps?.email;
  if (!email?.id) return false;
  return !!notes[email.id];
}
var slots = {
  "email-banner": {
    component: NoteBanner,
    shouldShow: shouldShowBanner,
    order: 80
  },
  "email-detail-sidebar": {
    component: NotesSidebar,
    order: 20
  }
};
var hooks = {
  // Refresh the in-memory cache when an email is opened so the banner gate
  // is accurate even after edits from the sidebar slot.
  async onEmailOpen() {
    if (!pluginApi) return;
    const stored = await pluginApi.storage.get("notes");
    notes = stored && typeof stored === "object" ? stored : {};
  }
};
async function activate(api) {
  pluginApi = api;
  const stored = await api.storage.get("notes");
  notes = stored && typeof stored === "object" ? stored : {};
  api.log.info(`Quick Notes plugin activated (${Object.keys(notes).length} note(s) stored)`);
}
