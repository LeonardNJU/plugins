var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// email-to-task/src/index.js
var index_exports = {};
__export(index_exports, {
  default: () => index_default
});
module.exports = __toCommonJS(index_exports);
var React2 = __toESM(require("react"), 1);

// email-to-task/src/ui/task-dialog.js
var React = __toESM(require("react"), 1);

// email-to-task/src/lib/due-date.js
var L = "(?<![\\p{L}\\p{N}])";
var R = "(?![\\p{L}\\p{N}])";
var TRIGGERS = [
  "no later than",
  "not later than",
  "at the latest by",
  "deadline",
  "until",
  "till",
  "due",
  "before",
  "within",
  "by",
  "bis spätestens",
  "spätestens",
  "fällig",
  "frist",
  "innerhalb von",
  "innerhalb",
  "binnen",
  "bis"
];
var FILLER = /^(?:(?:the|this|coming|on|at|by|until|am|zum|zur|zu|dem|den|diesen|diesem|dieser|kommenden|kommender|kommendem|spätestens|bis|latest|date)\s*:?\s+)*/iu;
var MONTHS = {
  january: 1,
  jan: 1,
  januar: 1,
  jänner: 1,
  jaenner: 1,
  february: 2,
  feb: 2,
  februar: 2,
  march: 3,
  mar: 3,
  märz: 3,
  maerz: 3,
  mär: 3,
  mrz: 3,
  april: 4,
  apr: 4,
  may: 5,
  mai: 5,
  june: 6,
  jun: 6,
  juni: 6,
  july: 7,
  jul: 7,
  juli: 7,
  august: 8,
  aug: 8,
  september: 9,
  sep: 9,
  sept: 9,
  october: 10,
  oct: 10,
  oktober: 10,
  okt: 10,
  november: 11,
  nov: 11,
  december: 12,
  dec: 12,
  dezember: 12,
  dez: 12
};
var MONTH_RE = Object.keys(MONTHS).sort((a, b) => b.length - a.length).join("|");
var WEEKDAYS = {
  sunday: 0,
  sonntag: 0,
  monday: 1,
  montag: 1,
  tuesday: 2,
  dienstag: 2,
  wednesday: 3,
  mittwoch: 3,
  thursday: 4,
  donnerstag: 4,
  friday: 5,
  freitag: 5,
  saturday: 6,
  samstag: 6,
  sonnabend: 6
};
var WEEKDAY_RE = Object.keys(WEEKDAYS).sort((a, b) => b.length - a.length).join("|");
var NUMBER_WORDS = {
  a: 1,
  an: 1,
  one: 1,
  ein: 1,
  eine: 1,
  einer: 1,
  einem: 1,
  einen: 1,
  two: 2,
  zwei: 2,
  three: 3,
  drei: 3,
  four: 4,
  vier: 4,
  five: 5,
  fünf: 5,
  six: 6,
  sechs: 6,
  seven: 7,
  sieben: 7,
  ten: 10,
  zehn: 10,
  fourteen: 14,
  vierzehn: 14
};
var NUMBER_RE = `\\d{1,3}|${Object.keys(NUMBER_WORDS).sort((a, b) => b.length - a.length).join("|")}`;
function pad(n) {
  return String(n).padStart(2, "0");
}
function isoDate(d) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
function startOfDay(d) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}
function addDays(d, n) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
}
function validDate(y, m, d) {
  if (m < 1 || m > 12 || d < 1 || d > 31) return null;
  const date = new Date(y, m - 1, d);
  return date.getMonth() === m - 1 && date.getDate() === d ? date : null;
}
function fullYear(raw) {
  const y = Number(raw);
  return raw.length <= 2 ? 2e3 + y : y;
}
function nextDayMonth(ref, m, d) {
  let date = validDate(ref.getFullYear(), m, d);
  if (date && date < ref) date = validDate(ref.getFullYear() + 1, m, d);
  for (let y = ref.getFullYear() + 1; !date && y < ref.getFullYear() + 8; y++) date = validDate(y, m, d);
  return date;
}
function count(raw) {
  const n = NUMBER_WORDS[raw.toLowerCase()];
  return n ?? Number(raw);
}
var PARSERS = [
  // 2026-10-20
  (s) => {
    const m = /^(\d{4})-(\d{1,2})-(\d{1,2})(?!\d)/u.exec(s);
    return m && { date: validDate(+m[1], +m[2], +m[3]), length: m[0].length };
  },
  // 20.10.2026, 20.10.26, 20.10.
  (s, ref) => {
    const m = /^(\d{1,2})\.\s?(\d{1,2})\.(?:\s?(\d{4}|\d{2})(?!\d))?/u.exec(s);
    if (!m) return null;
    const date = m[3] ? validDate(fullYear(m[3]), +m[2], +m[1]) : nextDayMonth(ref, +m[2], +m[1]);
    return { date, length: m[0].length };
  },
  // 10/20/2026 or 20/10/2026, only when it can't be read both ways.
  (s, ref) => {
    const m = /^(\d{1,2})\/(\d{1,2})(?:\/(\d{4}|\d{2}))?(?![\d/])/u.exec(s);
    if (!m) return null;
    const a = +m[1];
    const b = +m[2];
    let month;
    let day;
    if (a > 12 && b <= 12) {
      day = a;
      month = b;
    } else if (b > 12 && a <= 12) {
      month = a;
      day = b;
    } else return null;
    const date = m[3] ? validDate(fullYear(m[3]), month, day) : nextDayMonth(ref, month, day);
    return { date, length: m[0].length };
  },
  // 20 October 2026, 20th of Oct, 20. Oktober
  (s, ref) => {
    const m = new RegExp(`^(\\d{1,2})(?:st|nd|rd|th|\\.)?\\s*(?:of\\s+)?(${MONTH_RE})${R}\\.?(?:,?\\s*(\\d{4})(?!\\d))?`, "iu").exec(s);
    if (!m) return null;
    const month = MONTHS[m[2].toLowerCase()];
    const date = m[3] ? validDate(+m[3], month, +m[1]) : nextDayMonth(ref, month, +m[1]);
    return { date, length: m[0].length };
  },
  // October 20, 2026; Oct 20th
  (s, ref) => {
    const m = new RegExp(`^(${MONTH_RE})${R}\\.?\\s+(\\d{1,2})(?:st|nd|rd|th)?(?!\\d)(?:,?\\s*(\\d{4})(?!\\d))?`, "iu").exec(s);
    if (!m) return null;
    const month = MONTHS[m[1].toLowerCase()];
    const date = m[3] ? validDate(+m[3], month, +m[2]) : nextDayMonth(ref, month, +m[2]);
    return { date, length: m[0].length };
  },
  // end of October, Ende Oktober
  (s, ref) => {
    const m = new RegExp(`^(?:the\\s+)?(?:end\\s+of|ende)\\s+(${MONTH_RE})${R}(?:\\s+(\\d{4})(?!\\d))?`, "iu").exec(s);
    if (!m) return null;
    const month = MONTHS[m[1].toLowerCase()];
    let year = m[2] ? +m[2] : ref.getFullYear();
    if (!m[2] && month < ref.getMonth() + 1) year += 1;
    return { date: new Date(year, month, 0), length: m[0].length };
  },
  // today, tomorrow, the day after tomorrow, heute, morgen, übermorgen, tonight, EOD
  (s, ref) => {
    const m = new RegExp(`^(?:the\\s+)?(day\\s+after\\s+tomorrow|übermorgen|tomorrow|morgen|today|tonight|heute(?:\\s+abend)?|end\\s+of\\s+(?:the\\s+)?day|eod|cob)${R}`, "iu").exec(s);
    if (!m) return null;
    const word = m[1].toLowerCase();
    const days = /after|über/u.test(word) ? 2 : /tomorrow|morgen/u.test(word) ? 1 : 0;
    return { date: addDays(ref, days), length: m[0].length };
  },
  // end of the week / month / year, Ende der Woche, Monatsende, Jahresende
  (s, ref) => {
    const m = new RegExp(`^(?:the\\s+)?(?:end\\s+of\\s+(?:the\\s+|this\\s+)?(week|month|year)|ende\\s+(?:der|dieser)\\s+(woche)|ende\\s+(?:des|dieses)\\s+(monats|jahres)|(wochenende|monatsende|jahresende))${R}`, "iu").exec(s);
    if (!m) return null;
    const unit = (m[1] || m[2] || m[3] || m[4]).toLowerCase();
    let date;
    if (/^(week|woche|wochenende)$/u.test(unit)) {
      const diff = (5 - ref.getDay() + 7) % 7;
      date = ref.getDay() === 6 || ref.getDay() === 0 ? ref : addDays(ref, diff);
    } else if (/^(month|monats|monatsende)$/u.test(unit)) {
      date = new Date(ref.getFullYear(), ref.getMonth() + 1, 0);
    } else {
      date = new Date(ref.getFullYear(), 11, 31);
    }
    return { date, length: m[0].length };
  },
  // next week, nächste Woche, kommende Woche: the Monday of next week
  (s, ref) => {
    const m = new RegExp(`^(?:next|nächste|nächsten|kommende|kommenden)\\s+(week|woche)${R}`, "iu").exec(s);
    if (!m) return null;
    const diff = (1 - ref.getDay() + 7) % 7 || 7;
    return { date: addDays(ref, diff), length: m[0].length };
  },
  // in 3 days, within two weeks, in einer Woche, innerhalb von 5 Tagen
  (s, ref) => {
    const m = new RegExp(`^(?:(?:in|within|innerhalb\\s+(?:von\\s+)?|binnen)\\s+)?(${NUMBER_RE})\\s+(days?|weeks?|tagen?|wochen?)${R}`, "iu").exec(s);
    if (!m) return null;
    const n = count(m[1]);
    if (!Number.isFinite(n) || n > 365) return null;
    const weeks = /^(week|woche)/iu.test(m[2]);
    return { date: addDays(ref, weeks ? n * 7 : n), length: m[0].length };
  },
  // Friday, next Friday, nächsten Freitag
  (s, ref) => {
    const m = new RegExp(`^(?:(next|nächsten|nächster|nächstem|nächste)\\s+)?(${WEEKDAY_RE})${R}`, "iu").exec(s);
    if (!m) return null;
    const wanted = WEEKDAYS[m[2].toLowerCase()];
    let diff = (wanted - ref.getDay() + 7) % 7;
    if (diff === 0 && m[1]) diff = 7;
    return { date: addDays(ref, diff), length: m[0].length };
  }
];
var TRIGGER_RE = new RegExp(`${L}(${TRIGGERS.map((t) => t.replace(/ /g, "\\s+")).join("|")})${R}\\s*:?\\s*`, "giu");
function ownText(text) {
  const out = [];
  for (const line of String(text ?? "").split(/\r?\n/)) {
    if (/^\s*>/.test(line)) continue;
    if (/^\s*-{2,}\s*(original message|ursprüngliche nachricht|forwarded message|weitergeleitete nachricht)/iu.test(line)) break;
    if (/^\s*(on .{4,200} wrote:|am .{4,200} schrieb .{1,200}:)\s*$/iu.test(line)) break;
    out.push(line);
  }
  return out.join("\n");
}
function findDueDateIn(text, reference) {
  const ref = startOfDay(reference instanceof Date && !Number.isNaN(reference.getTime()) ? reference : /* @__PURE__ */ new Date());
  const source = String(text ?? "");
  TRIGGER_RE.lastIndex = 0;
  for (let m = TRIGGER_RE.exec(source); m; m = TRIGGER_RE.exec(source)) {
    const after = source.slice(m.index + m[0].length, m.index + m[0].length + 80);
    const filler = FILLER.exec(after)?.[0] ?? "";
    const rest = after.slice(filler.length);
    for (const parse of PARSERS) {
      const found = parse(rest, ref);
      if (found?.date) {
        const end = m.index + m[0].length + filler.length + found.length;
        return { date: isoDate(found.date), match: source.slice(m.index, end).replace(/\s+/g, " ").trim() };
      }
    }
  }
  return null;
}
function findDueDate({ subject, text, receivedAt }) {
  const ref = receivedAt ? new Date(receivedAt) : /* @__PURE__ */ new Date();
  return findDueDateIn(subject, ref) ?? findDueDateIn(ownText(text).slice(0, 8e3), ref);
}

// email-to-task/src/lib/priority.js
var PRIORITIES = ["none", "low", "medium", "high"];
var URGENT_WORDS = /(?<![\p{L}\p{N}])(urgent|asap|important|high priority|dringend|eilig|eilt|wichtig|hohe priorität|sofort)(?![\p{L}\p{N}])/iu;
function header(headers, name) {
  if (!headers || typeof headers !== "object") return "";
  for (const [key, value] of Object.entries(headers)) {
    if (key.toLowerCase() === name) return String(Array.isArray(value) ? value[0] : value ?? "");
  }
  return "";
}
function detectPriority({ subject, headers }) {
  const xPriority = header(headers, "x-priority").trim();
  const importance = header(headers, "importance").trim().toLowerCase();
  const priority = header(headers, "priority").trim().toLowerCase();
  if (/^[12](\D|$)/.test(xPriority) || importance === "high" || priority === "urgent") return "high";
  if (URGENT_WORDS.test(String(subject ?? ""))) return "high";
  if (/^[45](\D|$)/.test(xPriority) || importance === "low" || priority === "non-urgent") return "low";
  return "none";
}
function priorityFor(target, level) {
  const i = Math.max(0, PRIORITIES.indexOf(level));
  switch (target) {
    // JSCalendar and iCalendar: 0 none, 1 highest ... 9 lowest; the webmail
    // writes 1, 5 and 9.
    case "bulwark":
    case "caldav":
      return [0, 9, 5, 1][i];
    // Vikunja: 0 unset, 1 low, 2 medium, 3 high (4 urgent, 5 do now).
    case "vikunja":
      return [0, 1, 2, 3][i];
    // Todoist: 1 normal (p4) ... 4 urgent (p1).
    case "todoist":
      return [1, 2, 3, 4][i];
    default:
      return 0;
  }
}

// email-to-task/src/lib/message.js
var REPLY_PREFIX = /^\s*((re|fwd?|aw|wg|sv|vs|antw|tr|rv|r|fw|ref|réf|rif|odp|pd|ynt|отв|ha|回复|转发|答复)\s*(\[\d+\])?\s*[:：]\s*)+/iu;
function taskTitle(subject) {
  const clean = String(subject ?? "").replace(REPLY_PREFIX, "").replace(/\s+/g, " ").trim();
  return clean.length > 250 ? `${clean.slice(0, 249)}…` : clean;
}
function webmailBase(location) {
  if (!location?.origin || location.origin === "null") return "";
  const path = String(location.pathname ?? "");
  const i = path.search(/\/plugin-sandbox(-privileged)?(\/|$)/);
  const base = i >= 0 ? path.slice(0, i) : "";
  return `${location.origin}${base}`;
}
function messageLink(base, emailId) {
  return `${base}/mail/message/${encodeURIComponent(emailId)}`;
}
function sender(email) {
  const from = email?.from?.[0];
  if (!from) return "";
  return from.name && from.name !== from.email ? `${from.name} <${from.email}>` : from.email;
}
function excerpt(text, max = 600) {
  const own = ownText(text).replace(/\n{3,}/g, "\n\n").trim();
  if (own.length <= max) return own;
  const cut = own.slice(0, max);
  const lastSpace = cut.lastIndexOf(" ");
  return `${cut.slice(0, lastSpace > max * 0.6 ? lastSpace : max)}…`;
}
function taskDescription(email, { link, t, withExcerpt = true, formatDate: formatDate2 = (iso) => iso }) {
  const lines = [];
  const from = sender(email);
  if (from) lines.push(t("description.from", { sender: from }));
  if (email?.receivedAt) lines.push(t("description.date", { date: formatDate2(email.receivedAt) }));
  if (link) lines.push(t("description.link", { link }));
  const body = withExcerpt ? excerpt(email?.text ?? email?.preview ?? "") : "";
  return body ? `${lines.join("\n")}

${body}` : lines.join("\n");
}
var HTML_ESCAPES = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
function escapeHtml(text) {
  return String(text).replace(/[&<>"']/g, (c) => HTML_ESCAPES[c]);
}
function textToHtml(text) {
  return String(text ?? "").split(/\n{2,}/).map((para) => {
    const html = escapeHtml(para).replace(/https?:\/\/[^\s<>"']+/g, (url) => `<a href="${url}">${url}</a>`).replace(/\n/g, "<br>");
    return `<p>${html}</p>`;
  }).join("");
}

// email-to-task/src/lib/errors.js
var TaskError = class extends Error {
  /**
   * @param {string} code one of the `error.<code>` translation keys
   * @param {{ status?: number, retryAfter?: number, detail?: string }} info
   */
  constructor(code, info = {}) {
    super(info.detail ? `${code}: ${info.detail}` : code);
    this.name = "TaskError";
    this.code = code;
    this.status = info.status;
    this.retryAfter = info.retryAfter;
  }
};
var RECONNECT_CODES = /* @__PURE__ */ new Set(["auth", "not_connected"]);
var PROXY_CODES = {
  no_credential: "not_connected",
  rate_limited: "rate_limited",
  timeout: "timeout",
  unreachable: "unreachable",
  blocked_address: "blocked",
  wrong_origin: "wrong_server",
  redirect_off_origin: "wrong_server",
  too_large: "too_large"
};
function retryAfterOf(headers) {
  const raw = headers?.["retry-after"];
  if (!raw) return void 0;
  const seconds = Number(raw);
  if (Number.isFinite(seconds)) return Math.max(1, Math.round(seconds));
  const when = Date.parse(raw);
  return Number.isFinite(when) ? Math.max(1, Math.round((when - Date.now()) / 1e3)) : void 0;
}
function codeForStatus(status) {
  if (status === 401) return "auth";
  if (status === 403) return "forbidden";
  if (status === 404 || status === 410) return "not_found";
  if (status === 409 || status === 412) return "conflict";
  if (status === 413) return "too_large";
  if (status === 429) return "rate_limited";
  if (status === 507) return "quota";
  if (status === 408 || status === 504) return "timeout";
  if (status === 400 || status === 422) return "bad_request";
  return "server";
}
function errorForResponse(res) {
  if (res.proxyError) {
    return new TaskError(PROXY_CODES[res.proxyError] ?? "server", {
      status: res.status,
      retryAfter: retryAfterOf(res.headers),
      detail: typeof res.body === "string" ? res.body : res.proxyError
    });
  }
  return new TaskError(codeForStatus(res.status), {
    status: res.status,
    retryAfter: retryAfterOf(res.headers)
  });
}
function toTaskError(err) {
  if (err instanceof TaskError) return err;
  const message = String(err?.message ?? err ?? "");
  if (/timed out/i.test(message)) return new TaskError("timeout", { detail: message });
  if (/lacks permission/i.test(message)) return new TaskError("permission", { detail: message });
  if (/no calendar to put it in|no active session/i.test(message)) return new TaskError("no_task_list", { detail: message });
  if (/network|failed to fetch/i.test(message)) return new TaskError("unreachable", { detail: message });
  return new TaskError("unknown", { detail: message });
}
function errorText(t, err, service) {
  const e = toTaskError(err);
  const vars = { service: service ?? "", seconds: e.retryAfter ?? 60 };
  if (e.code === "rate_limited" && !e.retryAfter) return t("error.rate_limited_later", vars);
  return t(`error.${e.code}`, vars);
}
async function request(api, credentialId, url, init = {}) {
  let res;
  try {
    res = await api.proxy.fetch(credentialId, url, init);
  } catch (err) {
    throw toTaskError(err);
  }
  if (!res || !res.ok) throw errorForResponse(res ?? { status: 0 });
  return res;
}

// email-to-task/src/lib/targets/bulwark.js
var bulwark = {
  id: "bulwark",
  credentialId: null,
  name: "Bulwark",
  /**
   * Whether the server keeps tasks. api.tasks.list throws when the server or
   * the account has no calendars; a server without a calendar to put a
   * task in fails on create, which `create` reports as no_task_list.
   */
  async available(api) {
    try {
      const list = await api.tasks.list({ includeCompleted: false });
      return Array.isArray(list);
    } catch {
      return false;
    }
  },
  async containers() {
    return [];
  },
  async create(ctx, task) {
    let created;
    try {
      created = await ctx.api.tasks.create({
        title: task.title.slice(0, 500),
        description: task.description.slice(0, 1e4),
        ...task.due ? { due: task.due } : {},
        priority: priorityFor("bulwark", task.priority)
      });
    } catch (err) {
      throw toTaskError(err);
    }
    if (!created) throw new TaskError("stopped");
    return { taskId: created.id, url: null };
  },
  async exists(ctx, ref) {
    try {
      return !!await ctx.api.tasks.get(ref.taskId);
    } catch {
      return null;
    }
  }
};

// email-to-task/src/lib/targets/common.js
function trimSlash(url) {
  return String(url ?? "").replace(/\/+$/, "");
}
function originOf(url) {
  try {
    const u = new URL(url);
    return u.protocol === "http:" || u.protocol === "https:" ? u.origin : null;
  } catch {
    return null;
  }
}
function baseOn(origin, configured, usualPath = "") {
  if (configured && originOf(configured) === origin) {
    return trimSlash(`${origin}${new URL(configured).pathname}`);
  }
  return trimSlash(`${origin}${usualPath}`);
}
function noonOf(date) {
  const [y, m, d] = date.split("-").map(Number);
  return new Date(y, m - 1, d, 12, 0, 0).toISOString();
}
function randomId() {
  const bytes = new Uint8Array(16);
  if (globalThis.crypto?.getRandomValues) globalThis.crypto.getRandomValues(bytes);
  else for (let i = 0; i < bytes.length; i++) bytes[i] = Math.floor(Math.random() * 256);
  return [...bytes].map((b) => b.toString(16).padStart(2, "0")).join("");
}

// email-to-task/src/lib/targets/vikunja.js
var PAGE = 50;
function apiBase(ctx) {
  return `${baseOn(ctx.origin, ctx.config.vikunjaUrl)}/api/v1`;
}
function frontendBase(ctx) {
  return baseOn(ctx.origin, ctx.config.vikunjaUrl);
}
var vikunja = {
  id: "vikunja",
  credentialId: "vikunja",
  name: "Vikunja",
  suggestedServer: (config) => originOf(config.vikunjaUrl) ?? void 0,
  /** Projects a task can go into (saved filters, which have negative ids, can't take tasks). */
  async containers(ctx) {
    const out = [];
    for (let page = 1; page <= 10; page++) {
      const res = await request(ctx.api, "vikunja", `${apiBase(ctx)}/projects?page=${page}&per_page=${PAGE}`, { responseType: "json" });
      const list = Array.isArray(res.body) ? res.body : [];
      for (const p of list) {
        if (typeof p?.id === "number" && p.id > 0 && !p.is_archived) out.push({ id: String(p.id), name: String(p.title ?? p.id) });
      }
      if (list.length < PAGE) break;
    }
    return out;
  },
  async create(ctx, task) {
    if (!task.containerId) throw new TaskError("no_project");
    const body = {
      title: task.title,
      description: textToHtml(task.description),
      priority: priorityFor("vikunja", task.priority),
      ...task.due ? { due_date: noonOf(task.due) } : {}
    };
    const res = await request(ctx.api, "vikunja", `${apiBase(ctx)}/projects/${encodeURIComponent(task.containerId)}/tasks`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      responseType: "json"
    });
    const id = res.body?.id;
    if (id === void 0 || id === null) throw new TaskError("server", { detail: "no task id in the answer" });
    return { taskId: String(id), url: `${trimSlash(frontendBase(ctx))}/tasks/${id}` };
  },
  /** true, false (deleted) or null (can't tell right now). */
  async exists(ctx, ref) {
    try {
      await request(ctx.api, "vikunja", `${apiBase(ctx)}/tasks/${encodeURIComponent(ref.taskId)}`, { responseType: "json" });
      return true;
    } catch (err) {
      return err?.code === "not_found" ? false : null;
    }
  }
};

// email-to-task/src/lib/targets/todoist.js
var TODOIST_API = "https://api.todoist.com/api/v1";
function apiBase2(ctx) {
  return baseOn(ctx.origin, ctx.config.todoistApiUrl || TODOIST_API, "/api/v1");
}
var todoist = {
  id: "todoist",
  credentialId: "todoist",
  name: "Todoist",
  suggestedServer: (config) => originOf(config.todoistApiUrl || TODOIST_API) ?? void 0,
  async containers(ctx) {
    const out = [];
    let cursor = null;
    for (let page = 0; page < 10; page++) {
      const query = cursor ? `?cursor=${encodeURIComponent(cursor)}` : "";
      const res = await request(ctx.api, "todoist", `${apiBase2(ctx)}/projects${query}`, { responseType: "json" });
      const results = Array.isArray(res.body?.results) ? res.body.results : [];
      for (const p of results) {
        if (p?.id && !p.is_archived) out.push({ id: String(p.id), name: String(p.name ?? p.id), inbox: !!p.inbox_project });
      }
      cursor = res.body?.next_cursor;
      if (!cursor) break;
    }
    return out.sort((a, b) => Number(b.inbox) - Number(a.inbox)).map(({ id, name }) => ({ id, name }));
  },
  async create(ctx, task) {
    const body = {
      content: task.title.slice(0, 500),
      description: task.description,
      priority: priorityFor("todoist", task.priority),
      ...task.containerId ? { project_id: task.containerId } : {},
      ...task.due ? { due_date: task.due } : {}
    };
    const res = await request(ctx.api, "todoist", `${apiBase2(ctx)}/tasks`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      responseType: "json"
    });
    const id = res.body?.id;
    if (!id) throw new TaskError("server", { detail: "no task id in the answer" });
    const url = ctx.origin === originOf(TODOIST_API) ? `https://app.todoist.com/app/task/${encodeURIComponent(id)}` : null;
    return { taskId: String(id), url };
  },
  async exists(ctx, ref) {
    try {
      await request(ctx.api, "todoist", `${apiBase2(ctx)}/tasks/${encodeURIComponent(ref.taskId)}`, { responseType: "json" });
      return true;
    } catch (err) {
      return err?.code === "not_found" ? false : null;
    }
  }
};

// email-to-task/src/lib/ical.js
function escapeText(value) {
  return String(value ?? "").replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\r\n|\r|\n/g, "\\n");
}
function foldLine(line) {
  const encoder = new TextEncoder();
  const parts = [];
  let current = "";
  let bytes = 0;
  let limit = 75;
  for (const ch of line) {
    const size = encoder.encode(ch).length;
    if (bytes + size > limit) {
      parts.push(current);
      current = "";
      bytes = 0;
      limit = 74;
    }
    current += ch;
    bytes += size;
  }
  parts.push(current);
  return parts.join("\r\n ");
}
function utcStamp(date) {
  return date.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
}
function buildVtodo({ uid, title, description, due, priority, url, now = /* @__PURE__ */ new Date() }) {
  const lines = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Bulwark//Email to task//EN",
    "BEGIN:VTODO",
    `UID:${uid}`,
    `DTSTAMP:${utcStamp(now)}`,
    `CREATED:${utcStamp(now)}`,
    `SUMMARY:${escapeText(title)}`
  ];
  if (description) lines.push(`DESCRIPTION:${escapeText(description)}`);
  if (due && /^\d{4}-\d{2}-\d{2}$/.test(due)) lines.push(`DUE;VALUE=DATE:${due.replace(/-/g, "")}`);
  if (priority) lines.push(`PRIORITY:${priority}`);
  if (url) lines.push(`URL:${url}`);
  lines.push("STATUS:NEEDS-ACTION", "END:VTODO", "END:VCALENDAR");
  return `${lines.map(foldLine).join("\r\n")}\r
`;
}

// email-to-task/src/lib/dav-xml.js
var ENTITIES = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'" };
function decode(text) {
  return text.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e) => {
    if (e[0] === "#") {
      const code = e[1] === "x" || e[1] === "X" ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      return Number.isFinite(code) ? String.fromCodePoint(code) : m;
    }
    return ENTITIES[e.toLowerCase()] ?? m;
  });
}
function localName(name) {
  const i = name.indexOf(":");
  return (i >= 0 ? name.slice(i + 1) : name).toLowerCase();
}
function parseXml(xml) {
  const source = String(xml ?? "").replace(/<\?[\s\S]*?\?>/g, "").replace(/<!--[\s\S]*?-->/g, "").replace(/<!DOCTYPE[^>]*>/gi, "");
  const root = { name: "#root", attrs: {}, children: [], text: "" };
  const stack = [root];
  const tagRe = /<!\[CDATA\[([\s\S]*?)\]\]>|<(\/?)([A-Za-z_][\w.:-]*)((?:\s+[\w.:-]+\s*=\s*(?:"[^"]*"|'[^']*'))*)\s*(\/?)>/g;
  let last = 0;
  for (let m = tagRe.exec(source); m; m = tagRe.exec(source)) {
    const top = stack[stack.length - 1];
    if (m.index > last) top.text += decode(source.slice(last, m.index));
    last = tagRe.lastIndex;
    if (m[1] !== void 0) {
      top.text += m[1];
      continue;
    }
    const [, , closing, rawName, rawAttrs, selfClosing] = m;
    const name = localName(rawName);
    if (closing) {
      if (stack.length < 2 || top.name !== name) throw new Error(`Unexpected </${rawName}>`);
      stack.pop();
      continue;
    }
    const attrs = {};
    for (const a of rawAttrs.matchAll(/([\w.:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g)) {
      attrs[localName(a[1])] = decode(a[2] ?? a[3] ?? "");
    }
    const node = { name, attrs, children: [], text: "" };
    top.children.push(node);
    if (!selfClosing) stack.push(node);
  }
  if (stack.length !== 1) throw new Error("Unclosed element");
  return root;
}
function child(node, name) {
  return node?.children.find((c) => c.name === name) ?? null;
}
function children(node, name) {
  return node?.children.filter((c) => c.name === name) ?? [];
}
function descendants(node, name, out = []) {
  for (const c of node?.children ?? []) {
    if (c.name === name) out.push(c);
    descendants(c, name, out);
  }
  return out;
}
function textOf(node) {
  return (node?.text ?? "").trim();
}
function multistatus(xml) {
  const doc = parseXml(xml);
  const ms = descendants(doc, "multistatus")[0];
  if (!ms) return [];
  return children(ms, "response").map((response) => {
    const props = {};
    for (const propstat of children(response, "propstat")) {
      const status = textOf(child(propstat, "status"));
      if (status && !/\s2\d\d(\s|$)/.test(status)) continue;
      for (const prop of children(propstat, "prop")) {
        for (const p of prop.children) props[p.name] = p;
      }
    }
    return { href: textOf(child(response, "href")), props };
  });
}
function hrefIn(propNode) {
  return textOf(descendants(propNode, "href")[0]) || null;
}
function isTaskList(props) {
  const types = props.resourcetype?.children.map((c) => c.name) ?? [];
  if (!types.includes("calendar")) return false;
  const set = props["supported-calendar-component-set"];
  if (!set) return true;
  return descendants(set, "comp").some((c) => (c.attrs.name ?? "").toUpperCase() === "VTODO");
}
function isTasksOnly(props) {
  const set = props["supported-calendar-component-set"];
  if (!set) return false;
  const comps = descendants(set, "comp").map((c) => (c.attrs.name ?? "").toUpperCase());
  return comps.length > 0 && comps.every((c) => c === "VTODO");
}
function displayName(props) {
  return textOf(props.displayname);
}

// email-to-task/src/lib/targets/caldav.js
var PROPFIND_BODY = '<?xml version="1.0" encoding="utf-8"?><d:propfind xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav"><d:prop><d:current-user-principal/><c:calendar-home-set/><d:resourcetype/><d:displayname/><c:supported-calendar-component-set/></d:prop></d:propfind>';
var USUAL_PATHS = ["/.well-known/caldav", "/", "/dav/", "/dav/cal/", "/remote.php/dav/", "/dav.php/", "/caldav/", "/caldav.php/", "/cal.php/"];
async function propfind(ctx, url, depth) {
  const res = await request(ctx.api, "caldav", url, {
    method: "PROPFIND",
    headers: { Depth: String(depth), "Content-Type": "application/xml; charset=utf-8" },
    body: PROPFIND_BODY,
    responseType: "text"
  });
  try {
    return multistatus(res.body);
  } catch {
    return [];
  }
}
function resolve(ctx, href, base) {
  try {
    const url = new URL(href, base);
    return url.origin === ctx.origin ? url.toString() : null;
  } catch {
    return null;
  }
}
function listsIn(ctx, responses, base) {
  const out = [];
  for (const r of responses) {
    if (!isTaskList(r.props)) continue;
    const url = resolve(ctx, r.href, base);
    if (!url) continue;
    const name = displayName(r.props) || decodeURIComponent(url.replace(/\/+$/, "").split("/").pop() || url);
    out.push({ id: url.endsWith("/") ? url : `${url}/`, name, tasksOnly: isTasksOnly(r.props) });
  }
  return out.sort((a, b) => Number(b.tasksOnly) - Number(a.tasksOnly)).map(({ id, name }) => ({ id, name }));
}
function tryNext(err) {
  return ["not_found", "bad_request", "server", "forbidden", "conflict", "wrong_server"].includes(err?.code);
}
async function discoverTaskLists(ctx, starts = []) {
  const candidates = [];
  for (const s of [...starts, ...USUAL_PATHS.map((p) => `${ctx.origin}${p}`)]) {
    if (s && originOf(s) === ctx.origin && !candidates.includes(s)) candidates.push(s);
  }
  for (const url of candidates) {
    let responses;
    try {
      responses = await propfind(ctx, url, 0);
    } catch (err) {
      if (tryNext(err)) continue;
      throw err;
    }
    const direct = listsIn(ctx, responses, url);
    if (direct.length) return direct;
    const props = responses[0]?.props ?? {};
    let home = props["calendar-home-set"] ? resolve(ctx, hrefIn(props["calendar-home-set"]), url) : null;
    const principal = props["current-user-principal"] ? resolve(ctx, hrefIn(props["current-user-principal"]), url) : null;
    if (!home && principal) {
      try {
        const p = await propfind(ctx, principal, 0);
        const set = p[0]?.props["calendar-home-set"];
        home = set ? resolve(ctx, hrefIn(set), principal) : null;
      } catch (err) {
        if (!tryNext(err)) throw err;
      }
    }
    if (!home) continue;
    try {
      const lists = listsIn(ctx, await propfind(ctx, home, 1), home);
      if (lists.length) return lists;
    } catch (err) {
      if (!tryNext(err)) throw err;
    }
  }
  return [];
}
var caldav = {
  id: "caldav",
  credentialId: "caldav",
  name: "CalDAV",
  suggestedServer: (config) => originOf(config.caldavUrl) ?? void 0,
  async containers(ctx) {
    return discoverTaskLists(ctx, [ctx.manualUrl, ctx.config.caldavUrl]);
  },
  async create(ctx, task) {
    if (!task.containerId || originOf(task.containerId) !== ctx.origin) throw new TaskError("no_task_list");
    const uid = `${randomId()}@bulwark-email-to-task`;
    const url = `${task.containerId.replace(/\/?$/, "/")}${encodeURIComponent(uid)}.ics`;
    await request(ctx.api, "caldav", url, {
      method: "PUT",
      headers: { "Content-Type": "text/calendar; charset=utf-8", "If-None-Match": "*" },
      body: buildVtodo({
        uid,
        title: task.title,
        description: task.description,
        due: task.due,
        priority: priorityFor("caldav", task.priority),
        url: task.link
      })
    });
    return { taskId: url, url: null };
  },
  async exists(ctx, ref) {
    if (originOf(ref.taskId) !== ctx.origin) return null;
    try {
      await request(ctx.api, "caldav", ref.taskId, { method: "GET", responseType: "text" });
      return true;
    } catch (err) {
      return err?.code === "not_found" ? false : null;
    }
  }
};

// email-to-task/src/lib/targets/index.js
var TARGETS = [bulwark, vikunja, todoist, caldav];
function targetById(id) {
  return TARGETS.find((t) => t.id === id) ?? null;
}
async function loadConfig(api) {
  try {
    const all = await api.admin.getAllConfig() ?? {};
    return {
      vikunjaUrl: typeof all.vikunjaUrl === "string" ? all.vikunjaUrl.trim() : "",
      todoistApiUrl: typeof all.todoistApiUrl === "string" ? all.todoistApiUrl.trim() : "",
      caldavUrl: typeof all.caldavUrl === "string" ? all.caldavUrl.trim() : ""
    };
  } catch {
    return { vikunjaUrl: "", todoistApiUrl: "", caldavUrl: "" };
  }
}
async function loadAccounts(api) {
  try {
    const list = await api.proxy.accounts() ?? [];
    const out = {};
    for (const a of list) if (a?.connected && a.origin) out[a.credentialId] = { origin: a.origin, username: a.username };
    return out;
  } catch {
    return {};
  }
}
function contextFor(api, target, { config, accounts, manualUrl }) {
  if (!target.credentialId) return { api, config };
  const account = accounts[target.credentialId];
  if (!account) return null;
  return { api, config, origin: account.origin, username: account.username, manualUrl };
}

// email-to-task/src/lib/task-store.js
var PREFS_KEY = "prefs";
var DEFAULT_PREFS = { target: null, containers: {}, after: "keyword", withExcerpt: true, caldavUrl: "" };
async function loadPrefs(api) {
  const raw = await api.storage.get(PREFS_KEY);
  return { ...DEFAULT_PREFS, ...raw && typeof raw === "object" ? raw : {} };
}
async function savePrefs(api, patch) {
  const next = { ...await loadPrefs(api), ...patch };
  await api.storage.set(PREFS_KEY, next);
  return next;
}

// email-to-task/src/lib/dialog-model.js
var MAX_MESSAGES_PER_DIALOG = 25;
function formatDate(iso, locale) {
  try {
    return new Intl.DateTimeFormat(locale || "en", { dateStyle: "medium", timeStyle: "short" }).format(new Date(iso));
  } catch {
    return iso;
  }
}
function itemFor(email, { t, base, locale, withExcerpt }) {
  const link = base ? messageLink(base, email.id) : "";
  const due = findDueDate(email);
  return {
    emailId: email.id,
    subject: email.subject ?? "",
    title: taskTitle(email.subject) || t("dialog.no_subject"),
    description: taskDescription(email, { link, t, withExcerpt, formatDate: (iso) => formatDate(iso, locale) }),
    link,
    due: due?.date ?? "",
    dueMatch: due?.match ?? "",
    priority: detectPriority(email),
    existing: []
  };
}
async function prepareDialog(api, { emailIds, location = globalThis.location } = {}) {
  const t = (k, v) => api.i18n.t(k, v);
  const locale = api.i18n.getLocale?.() ?? "en";
  const ids = [...new Set((emailIds ?? []).filter((id) => typeof id === "string" && id))];
  const [config, accounts, prefs, bulwarkAvailable] = await Promise.all([
    loadConfig(api),
    loadAccounts(api),
    loadPrefs(api),
    TARGETS[0].available(api)
  ]);
  const base = webmailBase(location);
  const items = [];
  const missing = [];
  for (const id of ids.slice(0, MAX_MESSAGES_PER_DIALOG)) {
    let email = null;
    try {
      email = await api.email.get(id);
    } catch {
      email = null;
    }
    if (!email) {
      missing.push(id);
      continue;
    }
    const item = itemFor(email, { t, base, locale, withExcerpt: prefs.withExcerpt !== false });
    items.push(item);
  }
  const targets = TARGETS.map((target2) => ({
    id: target2.id,
    name: target2.id === "bulwark" ? t("target.bulwark") : target2.name,
    available: target2.id === "bulwark" ? bulwarkAvailable : true,
    connected: !target2.credentialId || !!accounts[target2.credentialId]
  })).filter((target2) => target2.available);
  const remembered = targets.find((x) => x.id === prefs.target);
  const target = remembered?.id ?? targets.find((x) => x.connected)?.id ?? targets[0]?.id ?? null;
  return {
    items,
    missing,
    skipped: Math.max(0, ids.length - MAX_MESSAGES_PER_DIALOG),
    config,
    accounts,
    prefs,
    targets,
    target
  };
}
async function containersFor(api, state, targetId) {
  const target = targetById(targetId);
  if (!target) return [];
  const ctx = contextFor(api, target, { config: state.config, accounts: state.accounts, manualUrl: state.prefs.caldavUrl });
  if (!ctx) throw new TaskError("not_connected");
  return target.containers(ctx);
}
async function connectTarget(api, state, targetId) {
  const target = targetById(targetId);
  if (!target?.credentialId) return state.accounts;
  const server = target.suggestedServer?.(state.config);
  await api.proxy.connect(target.credentialId, { mode: "password", ...server ? { server } : {} });
  return loadAccounts(api);
}
async function createTasks(api, state, form, onProgress = () => {
}) {
  const target = targetById(form.target);
  if (!target) throw new TaskError("unknown");
  const ctx = contextFor(api, target, { config: state.config, accounts: state.accounts, manualUrl: state.prefs.caldavUrl });
  if (!ctx) throw new TaskError("not_connected");
  const created = [];
  const failed = [];
  let done = 0;
  for (const item of form.items) {
    onProgress(done, form.items.length);
    const title = String(item.title ?? "").trim();
    if (!title) {
      failed.push({ emailId: item.emailId, error: new TaskError("no_title") });
      done++;
      continue;
    }
    try {
      const result = await target.create(ctx, {
        title,
        description: String(item.description ?? ""),
        due: item.due || null,
        priority: item.priority || "none",
        containerId: form.containerId || null,
        link: item.link || null
      });
      created.push({
        emailId: item.emailId,
        ref: { target: target.id, taskId: result.taskId, title, url: result.url ?? null, containerId: form.containerId || null }
      });
    } catch (err) {
      const error = toTaskError(err);
      failed.push({ emailId: item.emailId, error });
      if (["auth", "not_connected", "forbidden", "rate_limited", "quota", "no_project", "no_task_list", "permission", "unreachable", "blocked"].includes(error.code)) {
        for (const rest of form.items.slice(done + 1)) failed.push({ emailId: rest.emailId, error, skipped: true });
        break;
      }
    }
    done++;
  }
  onProgress(form.items.length, form.items.length);
  await savePrefs(api, {
    target: target.id,
    containers: { ...state.prefs.containers, ...form.containerId ? { [target.id]: form.containerId } : {} }
  });
  return { created, failed };
}

// email-to-task/src/ui/task-dialog.js
var h = React.createElement;
var { useEffect, useMemo, useRef, useState } = React;
var CSS = `
:root.dark { color-scheme: dark; }
.e2t { font-size: 14px; color: var(--color-popover-foreground, var(--color-foreground)); display: flex; flex-direction: column; gap: 12px; }
.e2t label.field { display: flex; flex-direction: column; gap: 4px; font-size: 12px; font-weight: 500; }
.e2t input[type=text], .e2t input[type=url], .e2t input[type=date], .e2t select, .e2t textarea {
  box-sizing: border-box; width: 100%; min-width: 0; font: inherit; font-size: 14px; font-weight: 400;
  color: var(--color-foreground); background: var(--color-background);
  border: 1px solid var(--color-input, var(--color-border)); border-radius: 6px; padding: 7px 9px;
}
.e2t textarea { resize: vertical; min-height: 96px; }
.e2t :focus-visible { outline: 2px solid var(--color-ring, var(--color-primary)); outline-offset: 1px; }
.e2t .row { display: flex; gap: 10px; flex-wrap: wrap; }
.e2t .row > * { flex: 1 1 160px; }
.e2t .stack { display: flex; flex-direction: column; gap: 4px; }
.e2t .hint { font-size: 12px; font-weight: 400; color: var(--color-muted-foreground); }
.e2t .note { font-size: 13px; border-radius: 6px; padding: 8px 10px; background: var(--color-muted); color: var(--color-foreground); }
.e2t .note.warn { background: color-mix(in srgb, var(--color-warning, #d97706) 14%, transparent); }
.e2t .error { font-size: 13px; border-radius: 6px; padding: 8px 10px; color: var(--color-destructive);
  background: color-mix(in srgb, var(--color-destructive) 10%, transparent); }
.e2t button { font: inherit; font-size: 14px; border-radius: 6px; padding: 7px 14px; cursor: pointer;
  border: 1px solid var(--color-border); background: var(--color-background); color: var(--color-foreground); }
.e2t button.primary { background: var(--color-primary); color: var(--color-primary-foreground); border-color: var(--color-primary); }
.e2t button:disabled { opacity: .55; cursor: default; }
.e2t button.link { border: 0; background: none; padding: 0; color: var(--color-primary); text-decoration: underline; cursor: pointer; }
.e2t .actions { display: flex; gap: 8px; justify-content: flex-end; flex-wrap: wrap; align-items: center; }
.e2t .actions .grow { flex: 1 1 180px; }
.e2t ul.items { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 8px; }
.e2t ul.items li { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
.e2t ul.items li .title { flex: 1 1 200px; }
.e2t ul.items li input[type=date] { flex: 0 0 150px; width: 150px; }
.e2t ul.items li .item-error { flex-basis: 100%; font-size: 12px; color: var(--color-destructive); }
`;
function useStyle() {
  useEffect(() => {
    if (document.getElementById("e2t-style")) return;
    const el = document.createElement("style");
    el.id = "e2t-style";
    el.textContent = CSS;
    document.head.appendChild(el);
  }, []);
}
var CONTAINER_LABEL = { vikunja: "container.project", todoist: "container.project", caldav: "container.list" };
function TaskDialog({ api, emailIds, onResult }) {
  useStyle();
  const t = (key, vars) => api.i18n.t(key, vars);
  const [state, setState] = useState(null);
  const [loadError, setLoadError] = useState(null);
  const [items, setItems] = useState([]);
  const [target, setTarget] = useState(null);
  const [containers, setContainers] = useState({ status: "idle", list: [], error: null });
  const [containerId, setContainerId] = useState("");
  const [bulkPriority, setBulkPriority] = useState("auto");
  const [manualUrl, setManualUrl] = useState("");
  const [busy, setBusy] = useState(null);
  const [error, setError] = useState(null);
  const [failures, setFailures] = useState({});
  const firstField = useRef(null);
  const single = items.length === 1;
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const s = await prepareDialog(api, { emailIds });
        if (cancelled) return;
        setState(s);
        setItems(s.items.map((i) => ({ ...i, include: true })));
        setTarget(s.target);
        setManualUrl(s.prefs.caldavUrl || "");
      } catch (err) {
        if (!cancelled) setLoadError(toTaskError(err));
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);
  const targetInfo = useMemo(() => state?.targets.find((x) => x.id === target) ?? null, [state, target]);
  const loadContainers = async (s = state, id = target) => {
    if (!s || !id || id === "bulwark") {
      setContainers({ status: "ready", list: [], error: null });
      return;
    }
    if (!s.targets.find((x) => x.id === id)?.connected) {
      setContainers({ status: "idle", list: [], error: null });
      return;
    }
    setContainers({ status: "loading", list: [], error: null });
    try {
      const list = await containersFor(api, s, id);
      setContainers({ status: "ready", list, error: null });
      const remembered = s.prefs.containers?.[id];
      setContainerId(list.some((c) => c.id === remembered) ? remembered : list[0]?.id ?? "");
    } catch (err) {
      setContainers({ status: "error", list: [], error: toTaskError(err) });
      setContainerId("");
    }
  };
  useEffect(() => {
    if (state && target) void loadContainers(state, target);
  }, [state, target]);
  useEffect(() => {
    if (state && firstField.current) firstField.current.focus();
  }, [state]);
  const serviceName = targetInfo?.name ?? "";
  const connect = async () => {
    setError(null);
    try {
      const accounts = await connectTarget(api, state, target);
      const next = {
        ...state,
        accounts,
        targets: state.targets.map((x) => x.id === target ? { ...x, connected: x.id === "bulwark" || !!accounts[target] } : x)
      };
      setState(next);
    } catch (err) {
      setError(toTaskError(err));
    }
  };
  const searchAgain = async () => {
    const prefs = await savePrefs(api, { caldavUrl: manualUrl.trim() });
    const next = { ...state, prefs };
    setState(next);
  };
  const update = (emailId, patch) => setItems((now) => now.map((i) => i.emailId === emailId ? { ...i, ...patch } : i));
  const chosen = items.filter((i) => i.include);
  const needsContainer = target === "vikunja";
  const canCreate = !!state && !!targetInfo?.connected && !busy && chosen.length > 0 && containers.status !== "loading" && (!needsContainer || !!containerId) && !(target === "caldav" && !containerId);
  const create = async () => {
    setError(null);
    setFailures({});
    const form = {
      target,
      containerId,
      items: chosen.map((i) => ({ ...i, priority: single || bulkPriority === "auto" ? i.priority : bulkPriority }))
    };
    setBusy({ done: 0, total: form.items.length });
    let result;
    try {
      result = await createTasks(api, state, form, (done, total) => setBusy({ done, total }));
    } catch (err) {
      setBusy(null);
      setError(toTaskError(err));
      return;
    }
    setBusy(null);
    const { created, failed } = result;
    if (created.length) {
      api.toast.success(created.length === 1 ? t("created.one", { service: serviceName }) : t("created.many", { count: created.length, service: serviceName }));
    }
    if (!failed.length) {
      onResult?.({ created: created.map((c) => c.emailId) });
      return;
    }
    const createdIds = new Set(created.map((c) => c.emailId));
    setItems((now) => now.filter((i) => !createdIds.has(i.emailId)));
    setFailures(Object.fromEntries(failed.map((f) => [f.emailId, f.error])));
    setError(failed[0].error);
  };
  if (loadError) {
    return h(
      "div",
      { className: "e2t" },
      h("p", { className: "error", role: "alert" }, errorText(t, loadError, "")),
      h("div", { className: "actions" }, h("button", { type: "button", onClick: () => onResult?.(null) }, t("dialog.close")))
    );
  }
  if (!state) {
    return h("div", { className: "e2t" }, h("p", { role: "status", className: "hint" }, t("dialog.loading")));
  }
  if (!state.items.length) {
    return h(
      "div",
      { className: "e2t" },
      h("p", { className: "error", role: "alert" }, t("dialog.no_message")),
      h("div", { className: "actions" }, h("button", { type: "button", onClick: () => onResult?.(null) }, t("dialog.close")))
    );
  }
  const targetField = h(
    "label",
    { className: "field" },
    t("dialog.service"),
    h("select", {
      value: target ?? "",
      disabled: !!busy,
      onChange: (e) => {
        setTarget(e.target.value);
        setError(null);
      }
    }, state.targets.map((x) => h("option", { key: x.id, value: x.id }, x.connected ? x.name : t("dialog.service_not_connected", { service: x.name }))))
  );
  const connectBox = targetInfo && !targetInfo.connected && h(
    "div",
    { className: "note" },
    h("p", { style: { margin: "0 0 8px" } }, t(`connect.needed.${target}`, { service: serviceName })),
    h("button", { type: "button", className: "primary", onClick: connect }, t("connect.button", { service: serviceName }))
  );
  let containerField = null;
  if (targetInfo?.connected && target !== "bulwark") {
    if (containers.status === "loading") {
      containerField = h("p", { role: "status", className: "hint" }, t("dialog.loading_lists"));
    } else if (containers.status === "error") {
      const reconnect2 = RECONNECT_CODES.has(containers.error?.code);
      containerField = h(
        "div",
        { className: "error", role: "alert" },
        errorText(t, containers.error, serviceName),
        " ",
        reconnect2 ? h("button", { type: "button", className: "link", onClick: connect }, t("connect.again")) : h("button", { type: "button", className: "link", onClick: () => loadContainers() }, t("dialog.retry"))
      );
    } else if (containers.list.length) {
      containerField = h(
        "label",
        { className: "field" },
        t(CONTAINER_LABEL[target]),
        h(
          "select",
          { value: containerId, disabled: !!busy, onChange: (e) => setContainerId(e.target.value) },
          containers.list.map((c) => h("option", { key: c.id, value: c.id }, c.name))
        )
      );
    } else if (target === "caldav" && containers.status === "ready") {
      containerField = h(
        "div",
        { className: "note warn" },
        h("p", { style: { margin: "0 0 8px" } }, t("caldav.none_found")),
        h(
          "label",
          { className: "field" },
          t("caldav.address"),
          h("input", { type: "url", value: manualUrl, placeholder: "https://", onChange: (e) => setManualUrl(e.target.value) })
        ),
        h(
          "div",
          { className: "actions", style: { marginTop: "8px" } },
          h("button", { type: "button", onClick: searchAgain }, t("caldav.search_again"))
        )
      );
    }
  }
  const priorityOptions = (withAuto) => [
    ...withAuto ? [h("option", { key: "auto", value: "auto" }, t("priority.auto"))] : [],
    ...PRIORITIES.map((p) => h("option", { key: p, value: p }, t(`priority.${p}`)))
  ];
  const fields = single ? (() => {
    const item = items[0];
    return [
      h(
        "label",
        { key: "title", className: "field" },
        t("dialog.title"),
        h("input", { type: "text", ref: firstField, value: item.title, maxLength: 500, onChange: (e) => update(item.emailId, { title: e.target.value }) })
      ),
      h(
        "div",
        { key: "description", className: "stack" },
        h(
          "label",
          { className: "field" },
          t("dialog.description"),
          h("textarea", { value: item.description, rows: 6, maxLength: 1e4, "aria-describedby": "e2t-desc-hint", onChange: (e) => update(item.emailId, { description: e.target.value }) })
        ),
        h("span", { id: "e2t-desc-hint", className: "hint" }, t("dialog.description_hint", { service: serviceName }))
      ),
      h(
        "div",
        { key: "row", className: "row" },
        h(
          "div",
          { className: "stack" },
          h(
            "label",
            { className: "field" },
            t("dialog.due"),
            h("input", { type: "date", value: item.due, "aria-describedby": item.dueMatch ? "e2t-due-hint" : void 0, onChange: (e) => update(item.emailId, { due: e.target.value, dueMatch: "" }) })
          ),
          item.dueMatch ? h("span", { id: "e2t-due-hint", className: "hint" }, t("dialog.due_found", { words: item.dueMatch })) : null
        ),
        h(
          "label",
          { className: "field" },
          t("dialog.priority"),
          h("select", { value: item.priority, onChange: (e) => update(item.emailId, { priority: e.target.value }) }, priorityOptions(false))
        )
      )
    ];
  })() : [
    h("p", { key: "count", className: "hint", style: { margin: 0 } }, t("dialog.bulk_intro", { count: items.length })),
    h("ul", { key: "items", className: "items" }, items.map((item, index) => h(
      "li",
      { key: item.emailId },
      h("input", {
        type: "checkbox",
        checked: item.include,
        "aria-label": t("dialog.include", { title: item.title }),
        onChange: (e) => update(item.emailId, { include: e.target.checked })
      }),
      h("input", {
        type: "text",
        className: "title",
        ref: index === 0 ? firstField : void 0,
        value: item.title,
        maxLength: 500,
        "aria-label": t("dialog.title_for", { subject: item.subject || item.title }),
        onChange: (e) => update(item.emailId, { title: e.target.value })
      }),
      h("input", {
        type: "date",
        value: item.due,
        "aria-label": t("dialog.due_for", { subject: item.subject || item.title }),
        title: item.dueMatch ? t("dialog.due_found", { words: item.dueMatch }) : void 0,
        onChange: (e) => update(item.emailId, { due: e.target.value })
      }),
      failures[item.emailId] ? h("span", { className: "item-error" }, errorText(t, failures[item.emailId], serviceName)) : null
    ))),
    h(
      "label",
      { key: "priority", className: "field" },
      t("dialog.priority"),
      h("select", { value: bulkPriority, onChange: (e) => setBulkPriority(e.target.value) }, priorityOptions(true))
    )
  ];
  const reconnect = error && RECONNECT_CODES.has(error.code);
  return h(
    "div",
    {
      className: "e2t",
      onKeyDown: (e) => {
        if (e.key === "Enter" && e.target?.tagName === "INPUT" && e.target.type === "text" && canCreate) {
          e.preventDefault();
          void create();
        }
      }
    },
    targetField,
    connectBox,
    containerField,
    state.missing.length > 0 && h("p", { className: "note warn" }, t("dialog.missing", { count: state.missing.length })),
    state.skipped > 0 && h("p", { className: "note warn" }, t("dialog.too_many", { count: state.skipped })),
    ...fields,
    error && h(
      "div",
      { className: "error", role: "alert" },
      errorText(t, error, serviceName),
      reconnect ? h("span", null, " ", h("button", { type: "button", className: "link", onClick: connect }, t("connect.again"))) : null
    ),
    h(
      "div",
      { className: "actions" },
      h("button", { type: "button", disabled: !!busy, onClick: () => onResult?.(null) }, t("dialog.cancel")),
      h(
        "button",
        { type: "button", className: "primary", disabled: !canCreate, onClick: () => {
          void create();
        } },
        busy ? busy.total > 1 ? t("dialog.creating_many", { done: busy.done, total: busy.total }) : t("dialog.creating") : chosen.length > 1 ? t("dialog.create_many", { count: chosen.length }) : t("dialog.create")
      )
    )
  );
}

// email-to-task/src/lib/wiring.js
var SINGLE_SURFACES = ["message-row-actions", "reader-actions"];
var BULK_SURFACE = "message-bulk-actions";
var ACTION_ID = "create-task";
var BULK_ACTION_ID = "create-tasks";
function createWiring(initialApi) {
  let api = initialApi;
  let openEmailId = null;
  let dialogOpen = false;
  const t = (key, vars) => api.i18n.t(key, vars);
  async function setActions() {
    const single = [{ id: ACTION_ID, label: t("action.create"), icon: "checklist", order: 60 }];
    for (const surface of SINGLE_SURFACES) await api.ui.setActions(surface, single);
    await api.ui.setActions(BULK_SURFACE, [{ id: BULK_ACTION_ID, label: t("action.create_bulk"), icon: "checklist", order: 60 }]);
  }
  async function openDialog(emailIds) {
    const ids = (emailIds ?? []).filter((id) => typeof id === "string" && id);
    if (!ids.length) {
      api.toast.info(t("shortcut.no_message"));
      return null;
    }
    if (dialogOpen) return null;
    dialogOpen = true;
    try {
      const result = await api.ui.openDialog({
        title: ids.length > 1 ? t("dialog.heading_many", { count: ids.length }) : t("dialog.heading"),
        slot: "plugin-dialog",
        extraProps: { emailIds: ids },
        width: 560
      });
      return result;
    } catch (err) {
      api.log.error("dialog failed", err);
      api.toast.error(t("error.unknown"));
      return null;
    } finally {
      dialogOpen = false;
    }
  }
  const hooks = {
    onAction({ surface, actionId, context } = {}) {
      if (actionId === ACTION_ID && SINGLE_SURFACES.includes(surface)) {
        void openDialog(context?.emailId ? [context.emailId] : []);
      } else if (actionId === BULK_ACTION_ID && surface === BULK_SURFACE) {
        void openDialog(Array.isArray(context?.emailIds) ? context.emailIds : []);
      }
    },
    onEmailOpen(email) {
      openEmailId = email?.id ?? null;
    },
    onEmailClose({ emailId } = {}) {
      if (!emailId || emailId === openEmailId) openEmailId = null;
    }
  };
  return {
    hooks,
    async activate(next) {
      if (next) api = next;
      await setActions();
      api.i18n.onLocaleChange?.(() => {
        void setActions();
      });
    },
    fromShortcut() {
      void openDialog(openEmailId ? [openEmailId] : []);
    },
    openDialog,
    /** For tests. */
    get openEmailId() {
      return openEmailId;
    }
  };
}

// email-to-task/src/index.js
var hostApi = require("@plugin-host");
var wiring = createWiring(hostApi);
var index_default = {
  activate: (api) => wiring.activate(api),
  hooks: wiring.hooks,
  shortcuts: {
    "create-task": {
      keys: "Alt+Shift+T",
      label: hostApi.i18n.t("shortcut.label"),
      category: "Email",
      handler: () => wiring.fromShortcut()
    }
  },
  slots: {
    "plugin-dialog": {
      component: (props) => React2.createElement(TaskDialog, { ...props, api: hostApi })
    }
  }
};
