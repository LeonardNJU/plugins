var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// ai-assistant/src/index.js
var index_exports = {};
__export(index_exports, {
  default: () => index_default
});
module.exports = __toCommonJS(index_exports);

// ai-assistant/src/ui/SettingsPanel.jsx
var import_react2 = require("react");

// ai-assistant/src/ui/common.jsx
var import_react = require("react");

// ai-assistant/src/lib/config.js
var PROVIDERS = ["openai", "anthropic"];
var DEFAULT_MODELS = {
  openai: "gpt-4o-mini",
  anthropic: "claude-haiku-4-5"
};
var OFFICIAL_BASE_URLS = {
  openai: "https://api.openai.com/v1",
  anthropic: "https://api.anthropic.com/v1"
};
var ADMIN_CREDENTIALS = { openai: "openai", anthropic: "anthropic" };
var OWN_CREDENTIALS = { openai: "own-openai", anthropic: "own-anthropic" };
function normalizeBaseUrl(value) {
  if (typeof value !== "string") return null;
  const trimmed = value.trim().replace(/\/+$/, "");
  if (!trimmed) return null;
  let url;
  try {
    url = new URL(trimmed);
  } catch {
    return null;
  }
  if (url.protocol !== "https:" && url.protocol !== "http:") return null;
  if (url.username || url.password || url.search || url.hash) return null;
  return trimmed;
}
function originOf(value) {
  try {
    return new URL(value).origin;
  } catch {
    return null;
  }
}
function hostOf(value) {
  try {
    return new URL(value).host;
  } catch {
    return "";
  }
}
function cleanModel(value) {
  return typeof value === "string" ? value.trim().slice(0, 200) : "";
}
function adminProviders(config = {}) {
  const out = [];
  for (const provider of PROVIDERS) {
    const baseUrl = normalizeBaseUrl(config[`${provider}BaseUrl`]);
    if (!baseUrl) continue;
    out.push({ provider, baseUrl, model: cleanModel(config[`${provider}Model`]) });
  }
  return out;
}
function userKeysAllowed(config = {}) {
  return config.allowUserKeys === true || config.allowUserKeys === "true";
}
function resolveEndpoint({ config = {}, prefs = {}, accounts = [] } = {}) {
  if (userKeysAllowed(config) && prefs.useOwn && prefs.own && PROVIDERS.includes(prefs.own.provider)) {
    const provider = prefs.own.provider;
    const credentialId = OWN_CREDENTIALS[provider];
    const account = accounts.find((a) => a && a.credentialId === credentialId && a.connected);
    if (account) {
      const wanted2 = normalizeBaseUrl(prefs.own.baseUrl) || OFFICIAL_BASE_URLS[provider];
      const path = new URL(wanted2).pathname.replace(/\/+$/, "");
      const baseUrl = originOf(wanted2) === account.origin ? wanted2 : `${account.origin}${path}`;
      return {
        provider,
        credentialId,
        baseUrl,
        origin: account.origin,
        model: cleanModel(prefs.own.model) || DEFAULT_MODELS[provider],
        own: true
      };
    }
  }
  const list = adminProviders(config);
  if (list.length === 0) return null;
  const wanted = PROVIDERS.includes(prefs.provider) ? prefs.provider : config.defaultProvider;
  const pick = list.find((p) => p.provider === wanted) ?? list[0];
  return {
    provider: pick.provider,
    credentialId: ADMIN_CREDENTIALS[pick.provider],
    baseUrl: pick.baseUrl,
    origin: originOf(pick.baseUrl),
    model: cleanModel(prefs.model) || pick.model || DEFAULT_MODELS[pick.provider],
    own: false
  };
}

// ai-assistant/src/lib/assistant.js
var PREFS_KEY = "prefs";
var PROVIDER_LABELS = { openai: "OpenAI-compatible", anthropic: "Anthropic" };
async function loadPrefs(api) {
  try {
    const value = await api.storage.get(PREFS_KEY);
    return value && typeof value === "object" ? value : {};
  } catch {
    return {};
  }
}
async function savePrefs(api, patch) {
  const next = { ...await loadPrefs(api), ...patch };
  await api.storage.set(PREFS_KEY, next);
  return next;
}
async function loadConfig(api) {
  try {
    const config = await api.admin.getAllConfig();
    return config && typeof config === "object" ? config : {};
  } catch {
    return {};
  }
}
async function loadSetup(api) {
  const [config, prefs] = await Promise.all([loadConfig(api), loadPrefs(api)]);
  let accounts = [];
  if (userKeysAllowed(config)) {
    try {
      accounts = await api.proxy.accounts() ?? [];
    } catch {
      accounts = [];
    }
  }
  return { config, prefs, accounts, endpoint: resolveEndpoint({ config, prefs, accounts }) };
}

// ai-assistant/src/ui/common.jsx
var import_jsx_runtime = require("react/jsx-runtime");
var host = () => require("@plugin-host");
var t = (key, vars) => host().i18n.t(key, vars);
var CSS = `
* { box-sizing: border-box; }
body { margin: 0; }
.ai { font-size: 13px; line-height: 1.45; color: var(--color-foreground); }
.ai-row { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; }
.ai-btn {
  font: inherit; font-size: 12px; line-height: 1.2; cursor: pointer;
  display: inline-flex; align-items: center; gap: 5px;
  padding: 5px 10px; border-radius: 6px;
  border: 1px solid var(--color-border); background: var(--color-background); color: var(--color-foreground);
}
.ai-btn:hover:not(:disabled) { background: var(--color-accent); color: var(--color-accent-foreground); }
.ai-btn:focus-visible, .ai-input:focus-visible, .ai-select:focus-visible, .ai-text:focus-visible {
  outline: 2px solid var(--color-ring); outline-offset: 1px;
}
.ai-btn:disabled { opacity: .55; cursor: default; }
.ai-btn.primary { background: var(--color-primary); color: var(--color-primary-foreground); border-color: var(--color-primary); }
.ai-btn.primary:hover:not(:disabled) { opacity: .9; background: var(--color-primary); color: var(--color-primary-foreground); }
.ai-btn.ghost { border-color: transparent; background: transparent; }
.ai-btn.small { padding: 3px 8px; font-size: 11.5px; }
.ai-input, .ai-select, .ai-text {
  font: inherit; font-size: 13px; color: var(--color-foreground); background: var(--color-background);
  border: 1px solid var(--color-input); border-radius: 6px; padding: 6px 8px; min-width: 0;
}
.ai-text { width: 100%; resize: vertical; min-height: 120px; line-height: 1.5; }
.ai-muted { color: var(--color-muted-foreground); font-size: 12px; }
.ai-card { border: 1px solid var(--color-border); border-radius: 8px; background: var(--color-card, var(--color-background)); color: var(--color-card-foreground, var(--color-foreground)); }
.ai-out { white-space: pre-wrap; overflow-wrap: anywhere; padding: 10px 12px; }
.ai-head { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 6px 8px 6px 12px; border-bottom: 1px solid var(--color-border); }
.ai-title { font-weight: 600; font-size: 12.5px; }
.ai-error { color: var(--color-destructive); padding: 10px 12px; }
.ai-cursor::after { content: '▍'; opacity: .6; margin-left: 1px; }
.ai-label { font-size: 12px; font-weight: 500; display: block; margin-bottom: 4px; }
.ai-sr { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; }
ul.ai-list { margin: 0; padding: 0 12px 10px 28px; }
ul.ai-list li { margin: 3px 0; }
.ai-section { padding: 8px 12px 0; font-weight: 600; font-size: 12px; }
del.ai-from { color: var(--color-destructive); text-decoration: line-through; }
ins.ai-to { color: var(--color-success, var(--color-primary)); text-decoration: none; font-weight: 600; }
.ai-change { background: var(--color-muted); border-radius: 4px; padding: 0 2px; }
.ai-change-actions { display: inline-flex; gap: 2px; margin: 0 4px; vertical-align: middle; }
`;
function Styles() {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: CSS });
}

// ai-assistant/src/ui/SettingsPanel.jsx
var import_jsx_runtime2 = require("react/jsx-runtime");
function SettingsPanel() {
  const [setup, setSetup] = (0, import_react2.useState)(null);
  const [model, setModel] = (0, import_react2.useState)("");
  const [ownProvider, setOwnProvider] = (0, import_react2.useState)("openai");
  const [ownUrl, setOwnUrl] = (0, import_react2.useState)(OFFICIAL_BASE_URLS.openai);
  const [ownModel, setOwnModel] = (0, import_react2.useState)("");
  const [busy, setBusy] = (0, import_react2.useState)(false);
  const [message, setMessage] = (0, import_react2.useState)("");
  const ids = { model: (0, import_react2.useId)(), provider: (0, import_react2.useId)(), ownProvider: (0, import_react2.useId)(), ownUrl: (0, import_react2.useId)(), ownModel: (0, import_react2.useId)(), reader: (0, import_react2.useId)() };
  const reload = (0, import_react2.useCallback)(async () => {
    const next = await loadSetup(host());
    setSetup(next);
    setModel(next.prefs.model ?? "");
    const own = next.prefs.own ?? {};
    if (PROVIDERS.includes(own.provider)) setOwnProvider(own.provider);
    if (own.baseUrl) setOwnUrl(own.baseUrl);
    setOwnModel(own.model ?? "");
  }, []);
  (0, import_react2.useEffect)(() => {
    void reload();
  }, [reload]);
  if (!setup) return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "ai ai-muted", style: { padding: 4 }, children: [
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(Styles, {}),
    t("common.loading")
  ] });
  const { config, prefs, accounts, endpoint } = setup;
  const admin = adminProviders(config);
  const allowOwn = userKeysAllowed(config);
  const ownAccount = accounts.find((a) => a.credentialId === OWN_CREDENTIALS[ownProvider] && a.connected);
  const usingOwn = !!endpoint?.own;
  const save = async (patch) => {
    await savePrefs(host(), patch);
    await reload();
    setMessage(t("settings.saved"));
  };
  const connect = async () => {
    const baseUrl = normalizeBaseUrl(ownUrl);
    if (!baseUrl) {
      setMessage(t("settings.bad_url"));
      return;
    }
    setBusy(true);
    setMessage("");
    try {
      const result = await host().proxy.connect(OWN_CREDENTIALS[ownProvider], { mode: "password", server: baseUrl });
      if (result?.connected) {
        await save({ useOwn: true, own: { provider: ownProvider, baseUrl, model: ownModel.trim() } });
        setMessage(t("settings.connected", { host: hostOf(result.origin ?? baseUrl) }));
      }
    } catch {
      setMessage(t("settings.connect_failed"));
    } finally {
      setBusy(false);
    }
  };
  const disconnect = async () => {
    setBusy(true);
    try {
      await host().proxy.disconnect(OWN_CREDENTIALS[ownProvider]);
      await save({ useOwn: false });
      setMessage(t("settings.disconnected"));
    } finally {
      setBusy(false);
    }
  };
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "ai", style: { display: "grid", gap: 14, padding: "2px 0" }, children: [
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(Styles, {}),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("section", { "aria-labelledby": `${ids.model}-status`, children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { id: `${ids.model}-status`, className: "ai-title", children: t("settings.service") }),
      endpoint ? /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { style: { margin: "4px 0" }, "data-testid": "ai-status", children: t(usingOwn ? "settings.status_own" : "settings.status_admin", {
        provider: PROVIDER_LABELS[endpoint.provider],
        host: hostOf(endpoint.baseUrl),
        model: endpoint.model
      }) }) : /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { style: { margin: "4px 0" }, "data-testid": "ai-status", children: t(allowOwn ? "settings.not_set_up_own" : "settings.not_set_up") }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { className: "ai-muted", style: { margin: "4px 0" }, children: t("settings.privacy") })
    ] }),
    admin.length > 1 && !usingOwn && /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("label", { className: "ai-label", htmlFor: ids.provider, children: t("settings.provider") }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
        "select",
        {
          id: ids.provider,
          className: "ai-select",
          value: endpoint?.provider ?? admin[0].provider,
          onChange: (e) => void save({ provider: e.target.value }),
          children: admin.map((p) => /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("option", { value: p.provider, children: [
            PROVIDER_LABELS[p.provider],
            " (",
            hostOf(p.baseUrl),
            ")"
          ] }, p.provider))
        }
      )
    ] }),
    admin.length > 0 && !usingOwn && /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("label", { className: "ai-label", htmlFor: ids.model, children: t("settings.model") }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "ai-row", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
          "input",
          {
            id: ids.model,
            className: "ai-input",
            style: { flex: "1 1 200px" },
            value: model,
            placeholder: endpoint?.provider ? admin.find((p) => p.provider === endpoint.provider)?.model || DEFAULT_MODELS[endpoint.provider] : "",
            onChange: (e) => setModel(e.target.value)
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("button", { type: "button", className: "ai-btn", onClick: () => void save({ model: model.trim() }), children: t("settings.save") })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { className: "ai-muted", style: { marginTop: 3 }, children: t("settings.model_hint") })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("label", { className: "ai-row", htmlFor: ids.reader, style: { gap: 8 }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
        "input",
        {
          id: ids.reader,
          type: "checkbox",
          checked: prefs.showInReader !== false,
          onChange: (e) => void save({ showInReader: e.target.checked })
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { children: t("settings.show_in_reader") })
    ] }),
    allowOwn && /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("section", { className: "ai-card", style: { padding: 12, display: "grid", gap: 10 }, "aria-labelledby": `${ids.ownProvider}-title`, children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { id: `${ids.ownProvider}-title`, className: "ai-title", children: t("settings.own_title") }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { className: "ai-muted", children: t("settings.own_hint") }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("label", { className: "ai-label", htmlFor: ids.ownProvider, children: t("settings.provider") }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
          "select",
          {
            id: ids.ownProvider,
            className: "ai-select",
            value: ownProvider,
            disabled: usingOwn,
            onChange: (e) => {
              setOwnProvider(e.target.value);
              setOwnUrl(OFFICIAL_BASE_URLS[e.target.value]);
            },
            children: PROVIDERS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("option", { value: p, children: PROVIDER_LABELS[p] }, p))
          }
        )
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("label", { className: "ai-label", htmlFor: ids.ownUrl, children: t("settings.address") }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("input", { id: ids.ownUrl, className: "ai-input", style: { width: "100%" }, value: ownUrl, disabled: usingOwn, onChange: (e) => setOwnUrl(e.target.value), inputMode: "url" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("label", { className: "ai-label", htmlFor: ids.ownModel, children: t("settings.model") }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("input", { id: ids.ownModel, className: "ai-input", style: { width: "100%" }, value: ownModel, placeholder: DEFAULT_MODELS[ownProvider], onChange: (e) => setOwnModel(e.target.value) })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { className: "ai-row", children: usingOwn || ownAccount ? /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_jsx_runtime2.Fragment, { children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("button", { type: "button", className: "ai-btn", disabled: busy, onClick: () => void save({ useOwn: true, own: { provider: ownProvider, baseUrl: normalizeBaseUrl(ownUrl) ?? OFFICIAL_BASE_URLS[ownProvider], model: ownModel.trim() } }), children: t("settings.save") }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("button", { type: "button", className: "ai-btn", disabled: busy, onClick: () => void disconnect(), children: t("settings.disconnect") })
      ] }) : /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("button", { type: "button", className: "ai-btn primary", disabled: busy, onClick: () => void connect(), children: t("settings.connect") }) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { className: "ai-muted", role: "status", "aria-live": "polite", children: message })
  ] });
}

// ai-assistant/src/index.js
var index_default = {
  slots: {
    "settings-section": { component: SettingsPanel }
  }
};
