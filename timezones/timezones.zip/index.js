var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// timezones/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  default: () => index_default,
  hooks: () => hooks,
  slots: () => slots,
  slotsFor: () => slotsFor
});
module.exports = __toCommonJS(index_exports);

// timezones/src/host.js
var hostApi = null;
try {
  hostApi = typeof require === "function" ? require("@plugin-host") : null;
} catch {
  hostApi = null;
}
function getApi() {
  return hostApi;
}
function t(key, vars) {
  return hostApi ? hostApi.i18n.t(key, vars) : key;
}
function locale() {
  try {
    return hostApi?.i18n?.getLocale?.() || "en";
  } catch {
    return "en";
  }
}

// timezones/src/lib/zones.js
var MINUTE = 6e4;
var HOUR = 60 * MINUTE;
var DAY = 24 * HOUR;
var partsFormatters = /* @__PURE__ */ new Map();
function partsFormatter(zone) {
  let f = partsFormatters.get(zone);
  if (!f) {
    f = new Intl.DateTimeFormat("en-US", {
      timeZone: zone,
      hourCycle: "h23",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    });
    partsFormatters.set(zone, f);
  }
  return f;
}
function isValidZone(zone) {
  if (typeof zone !== "string" || !zone) return false;
  try {
    partsFormatter(zone);
    return true;
  } catch {
    return false;
  }
}
function wallClock(instant, zone) {
  const parts = {};
  for (const p of partsFormatter(zone).formatToParts(new Date(instant))) parts[p.type] = p.value;
  return {
    year: Number(parts.year),
    month: Number(parts.month),
    day: Number(parts.day),
    hour: Number(parts.hour) % 24,
    minute: Number(parts.minute),
    second: Number(parts.second)
  };
}
function offsetMinutes(zone, instant) {
  const w = wallClock(instant, zone);
  const asUtc = Date.UTC(w.year, w.month - 1, w.day, w.hour, w.minute, w.second);
  const whole = Math.floor(instant / 1e3) * 1e3;
  return Math.round((asUtc - whole) / MINUTE);
}
function formatOffset(minutes) {
  if (!minutes) return "UTC";
  const sign = minutes > 0 ? "+" : "−";
  const abs = Math.abs(minutes);
  const h = Math.floor(abs / 60);
  const m = abs % 60;
  return `UTC${sign}${h}${m ? `:${String(m).padStart(2, "0")}` : ""}`;
}
var LOCAL_RE = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?$/;
function parseLocal(text) {
  const m = LOCAL_RE.exec(String(text ?? "").trim());
  if (!m) return null;
  const [, y, mo, d, h, mi, s] = m.map(Number);
  if (mo < 1 || mo > 12 || d < 1 || d > 31 || h > 23 || mi > 59) return null;
  return { year: y, month: mo, day: d, hour: h, minute: mi, second: s || 0 };
}
function sameWall(a, b) {
  return a.year === b.year && a.month === b.month && a.day === b.day && a.hour === b.hour && a.minute === b.minute;
}
function zonedToInstant(local, zone) {
  const f = typeof local === "string" ? parseLocal(local) : local;
  if (!f) return NaN;
  const asUtc = Date.UTC(f.year, f.month - 1, f.day, f.hour, f.minute, f.second || 0);
  const before = offsetMinutes(zone, asUtc - DAY);
  const after = offsetMinutes(zone, asUtc + DAY);
  const candidates = [.../* @__PURE__ */ new Set([before, after])].map((off) => asUtc - off * MINUTE).filter((t2) => sameWall(wallClock(t2, zone), f)).sort((a, b) => a - b);
  if (candidates.length) return candidates[0];
  return asUtc - before * MINUTE;
}
function minutesOfDay(instant, zone) {
  const w = wallClock(instant, zone);
  return w.hour * 60 + w.minute;
}
function localDate(instant, zone) {
  const w = wallClock(instant, zone);
  return `${w.year}-${String(w.month).padStart(2, "0")}-${String(w.day).padStart(2, "0")}`;
}
function dayShift(instant, zone, homeZone) {
  const a = Date.parse(`${localDate(instant, zone)}T00:00:00Z`);
  const b = Date.parse(`${localDate(instant, homeZone)}T00:00:00Z`);
  return Math.round((a - b) / DAY);
}
function isOutsideHours(start, end, zone, fromHour = 8, toHour = 20) {
  const s = minutesOfDay(start, zone);
  const stop = Number.isFinite(end) && end > start ? end : start;
  let e = minutesOfDay(stop, zone);
  const days = Math.round((Date.parse(`${localDate(stop, zone)}T00:00:00Z`) - Date.parse(`${localDate(start, zone)}T00:00:00Z`)) / DAY);
  if (days === 1 && e === 0) e = 24 * 60;
  else if (days !== 0) return true;
  return s < fromHour * 60 || s >= toHour * 60 || e > toHour * 60;
}
function zoneCity(zone) {
  if (!zone) return "";
  if (/^(Etc\/)?(UTC|GMT|UCT|Zulu|Universal)$/i.test(zone)) return "UTC";
  const last = zone.split("/").pop() || zone;
  return last.replace(/_/g, " ");
}
var allZones = null;
function knownZones() {
  if (allZones) return allZones;
  try {
    allZones = typeof Intl.supportedValuesOf === "function" ? Intl.supportedValuesOf("timeZone") : [];
  } catch {
    allZones = [];
  }
  if (!allZones.includes("UTC")) allZones = [...allZones, "UTC"];
  return allZones;
}
function fold(text) {
  return String(text).normalize("NFD").replace(/\p{M}/gu, "").toLowerCase().replace(/[\s_-]+/g, " ").trim();
}
var ALIASES = {
  "utc": "UTC",
  "gmt": "UTC",
  "z": "UTC",
  "san francisco": "America/Los_Angeles",
  "seattle": "America/Los_Angeles",
  "silicon valley": "America/Los_Angeles",
  "washington": "America/New_York",
  "boston": "America/New_York",
  "miami": "America/New_York",
  "atlanta": "America/New_York",
  "houston": "America/Chicago",
  "dallas": "America/Chicago",
  "austin": "America/Chicago",
  "munich": "Europe/Berlin",
  "muenchen": "Europe/Berlin",
  "munchen": "Europe/Berlin",
  "hamburg": "Europe/Berlin",
  "frankfurt": "Europe/Berlin",
  "cologne": "Europe/Berlin",
  "koln": "Europe/Berlin",
  "zurich": "Europe/Zurich",
  "geneva": "Europe/Zurich",
  "mumbai": "Asia/Kolkata",
  "bombay": "Asia/Kolkata",
  "delhi": "Asia/Kolkata",
  "new delhi": "Asia/Kolkata",
  "bangalore": "Asia/Kolkata",
  "bengaluru": "Asia/Kolkata",
  "calcutta": "Asia/Kolkata",
  "beijing": "Asia/Shanghai",
  "peking": "Asia/Shanghai",
  "shenzhen": "Asia/Shanghai",
  "saigon": "Asia/Ho_Chi_Minh",
  "ho chi minh city": "Asia/Ho_Chi_Minh",
  "kyiv": "Europe/Kyiv",
  "kiev": "Europe/Kyiv",
  "sao paulo": "America/Sao_Paulo",
  "rio de janeiro": "America/Sao_Paulo",
  "rio": "America/Sao_Paulo",
  "mexico city": "America/Mexico_City",
  "tel aviv": "Asia/Jerusalem",
  "abu dhabi": "Asia/Dubai",
  "osaka": "Asia/Tokyo",
  "canberra": "Australia/Sydney",
  "wellington": "Pacific/Auckland"
};
function resolveZone(entry) {
  const raw = String(entry ?? "").trim();
  if (!raw) return null;
  const zones = knownZones();
  const exact = zones.find((z) => z.toLowerCase() === raw.toLowerCase());
  if (exact) return exact;
  if (raw.includes("/") && isValidZone(raw)) return canonical(raw);
  const key = fold(raw);
  if (ALIASES[key]) return ALIASES[key];
  const byCity = zones.find((z) => fold(zoneCity(z)) === key);
  if (byCity) return byCity;
  return null;
}
function canonical(zone) {
  try {
    return new Intl.DateTimeFormat("en-US", { timeZone: zone }).resolvedOptions().timeZone || zone;
  } catch {
    return zone;
  }
}
function parseZoneList(text) {
  const zones = [];
  const unknown = [];
  for (const part of String(text ?? "").split(/[,;\n]+/)) {
    const entry = part.trim();
    if (!entry) continue;
    const zone = resolveZone(entry);
    if (!zone) unknown.push(entry);
    else if (!zones.includes(zone)) zones.push(zone);
  }
  return { zones, unknown };
}
var timeFormatters = /* @__PURE__ */ new Map();
function formatTime(instant, zone, locale2 = "en") {
  const key = `${locale2}|${zone}`;
  let f = timeFormatters.get(key);
  if (!f) {
    let tag = locale2;
    try {
      new Intl.DateTimeFormat(tag);
    } catch {
      tag = "en";
    }
    const twelve = new Intl.DateTimeFormat(tag, { hour: "numeric" }).resolvedOptions().hour12 === true;
    f = new Intl.DateTimeFormat(tag, { timeZone: zone, hour: twelve ? "numeric" : "2-digit", minute: "2-digit" });
    timeFormatters.set(key, f);
  }
  return f.format(new Date(instant));
}
function formatWeekday(instant, zone, locale2 = "en") {
  try {
    return new Intl.DateTimeFormat(locale2, { timeZone: zone, weekday: "short" }).format(new Date(instant));
  } catch {
    return new Intl.DateTimeFormat("en", { timeZone: zone, weekday: "short" }).format(new Date(instant));
  }
}
function formatMultiZone(instant, zones, locale2 = "en") {
  const list = zones.filter(isValidZone);
  if (!list.length) return "";
  const dates = new Set(list.map((z) => localDate(instant, z)));
  const withDay = dates.size > 1;
  return list.map((z) => `${withDay ? `${formatWeekday(instant, z, locale2)} ` : ""}${formatTime(instant, z, locale2)} ${zoneCity(z)}`).join(" / ");
}
function browserZone() {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
  } catch {
    return "UTC";
  }
}

// timezones/src/lib/address-zones.js
var STORAGE_KEY = "addressZones";
var MAX_ENTRIES = 500;
function normaliseAddress(address) {
  const a = String(address ?? "").trim().toLowerCase();
  return /^[^\s@]+@[^\s@]+$/.test(a) ? a : null;
}
function clean(map) {
  const out = {};
  if (!map || typeof map !== "object") return out;
  for (const [address, zone] of Object.entries(map)) {
    const a = normaliseAddress(address);
    if (a && isValidZone(zone)) out[a] = zone;
  }
  return out;
}
async function loadAddressZones(storage) {
  try {
    return clean(await storage.get(STORAGE_KEY));
  } catch {
    return {};
  }
}
async function setAddressZone(storage, address, zone) {
  const a = normaliseAddress(address);
  if (!a) throw new Error("invalid-address");
  if (zone !== null && !isValidZone(zone)) throw new Error("invalid-zone");
  const map = await loadAddressZones(storage);
  if (zone === null) delete map[a];
  else {
    delete map[a];
    map[a] = zone;
    const keys = Object.keys(map);
    for (const k of keys.slice(0, Math.max(0, keys.length - MAX_ENTRIES))) delete map[k];
  }
  await storage.set(STORAGE_KEY, map);
  return map;
}
function zoneFor(map, address) {
  const a = normaliseAddress(address);
  return a && map ? map[a] ?? null : null;
}

// timezones/src/lib/event.js
function parseDuration(text) {
  const m = /^P(?:(\d+)W)?(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$/.exec(String(text ?? ""));
  if (!m || text === "P" || text === "PT") return NaN;
  const [, w, d, h, mi, sec] = m.map((v) => Number(v || 0));
  return ((((w * 7 + d) * 24 + h) * 60 + mi) * 60 + sec) * 1e3;
}
function normaliseEvent(e) {
  if (!e || typeof e !== "object") return null;
  const attendees = Array.isArray(e.attendees) ? e.attendees.filter((a) => typeof a === "string") : Array.isArray(e.participants) ? e.participants.map((p) => p?.email).filter((a) => typeof a === "string" && a) : [];
  return {
    start: e.start,
    end: typeof e.end === "string" ? e.end : null,
    duration: typeof e.duration === "string" ? e.duration : null,
    zone: isValidZone(e.timeZone) ? e.timeZone : null,
    isAllDay: !!e.isAllDay,
    attendees
  };
}
function eventZones(eventData, settings, addressZones) {
  const ev = normaliseEvent(eventData);
  if (!ev) return null;
  const home = settings.home;
  const evZone = ev.zone ?? home;
  const start = zonedToInstant(ev.start, evZone);
  if (!Number.isFinite(start)) return null;
  let end = ev.end ? zonedToInstant(ev.end, evZone) : start + parseDuration(ev.duration);
  if (!Number.isFinite(end) || end < start) end = start;
  const byZone = /* @__PURE__ */ new Map();
  const missing = [];
  for (const address of ev.attendees) {
    const zone = zoneFor(addressZones, address);
    if (!zone) {
      if (address) missing.push(address);
      continue;
    }
    if (zone === home) continue;
    const row = byZone.get(zone) ?? { zone, emails: [], favourite: false };
    row.emails.push(address);
    byZone.set(zone, row);
  }
  for (const zone of settings.favourites) {
    const row = byZone.get(zone) ?? { zone, emails: [], favourite: false };
    row.favourite = true;
    byZone.set(zone, row);
  }
  const allDay = ev.isAllDay;
  const rows = [...byZone.values()].map((row) => ({
    ...row,
    start,
    end,
    outside: !allDay && isOutsideHours(start, end, row.zone, settings.workStart, settings.workEnd),
    dayShift: dayShift(start, row.zone, evZone)
  }));
  return {
    allDay,
    start,
    end,
    rows,
    missing,
    // Only participants get a warning; favourites just show the time.
    warnings: rows.filter((r) => r.outside && r.emails.length > 0)
  };
}
function hourLabel(hour2, locale2) {
  return formatTime(Date.UTC(2026, 0, 1, hour2 % 24, 0), "UTC", locale2);
}
function outsideHoursWarning(info, settings, t2, locale2) {
  if (!info || info.allDay || info.warnings.length === 0) return null;
  const names = info.warnings.map((r) => `${r.emails.join(", ")} (${zoneCity(r.zone)})`).join("; ");
  return {
    key: "timezones-outside-hours",
    severity: "warning",
    message: t2("event.warning", { from: hourLabel(settings.workStart, locale2), to: hourLabel(settings.workEnd, locale2), names })
  };
}

// timezones/src/lib/date-header.js
var MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
var NAMED_ZONES = {
  ut: 0,
  gmt: 0,
  z: 0,
  est: -300,
  edt: -240,
  cst: -360,
  cdt: -300,
  mst: -420,
  mdt: -360,
  pst: -480,
  pdt: -420
};
function findDateHeader(headers) {
  if (!headers || typeof headers !== "object") return null;
  for (const [name, value] of Object.entries(headers)) {
    if (name.toLowerCase() !== "date") continue;
    const v = Array.isArray(value) ? value[0] : value;
    return typeof v === "string" ? v : null;
  }
  return null;
}
function parseDateHeader(value) {
  if (typeof value !== "string") return null;
  let text = value;
  for (let i = 0; i < 3 && /\([^()]*\)/.test(text); i++) text = text.replace(/\([^()]*\)/g, " ");
  text = text.replace(/\s+/g, " ").trim();
  text = text.replace(/^[A-Za-z]{3,9},?\s*/, "");
  const m = /^(\d{1,2})\s+([A-Za-z]{3,9})\.?\s+(\d{2,4})\s+(\d{1,2}):(\d{2})(?::(\d{2}))?(?:\s+([+-]\d{4}|[A-Za-z]{1,5}))?$/.exec(text);
  if (!m) return null;
  const day = Number(m[1]);
  const month = MONTHS.indexOf(m[2].slice(0, 3).toLowerCase());
  let year = Number(m[3]);
  if (m[3].length === 2) year += year < 50 ? 2e3 : 1900;
  else if (m[3].length === 3) year += 1900;
  const hour2 = Number(m[4]);
  const minute = Number(m[5]);
  const second = Number(m[6] || 0);
  if (month < 0 || day < 1 || day > 31 || hour2 > 23 || minute > 59 || second > 60) return null;
  let offsetMinutes2 = null;
  const zone = m[7];
  if (!zone) {
    offsetMinutes2 = null;
  } else if (/^[+-]\d{4}$/.test(zone)) {
    const sign = zone[0] === "-" ? -1 : 1;
    const hh = Number(zone.slice(1, 3));
    const mm = Number(zone.slice(3, 5));
    if (hh > 23 || mm > 59) return null;
    offsetMinutes2 = zone === "-0000" ? null : sign * (hh * 60 + mm);
  } else {
    const named = NAMED_ZONES[zone.toLowerCase()];
    offsetMinutes2 = named === void 0 ? null : named;
  }
  const wall = Date.UTC(year, month, day, hour2, minute, Math.min(second, 59));
  const instant = wall - (offsetMinutes2 ?? 0) * 6e4;
  return { instant, offsetMinutes: offsetMinutes2 };
}
function senderClock(parsed) {
  if (!parsed || parsed.offsetMinutes === null) return null;
  const shifted = new Date(parsed.instant + parsed.offsetMinutes * 6e4);
  return {
    hour: shifted.getUTCHours(),
    minute: shifted.getUTCMinutes(),
    date: shifted.toISOString().slice(0, 10),
    shifted: shifted.getTime()
  };
}

// timezones/src/lib/sender.js
function senderTime(email, { home, addressZones = {}, locale: locale2 = "en", now = Date.now() } = {}) {
  if (!email) return null;
  const parsed = parseDateHeader(findDateHeader(email.headers));
  const clock = senderClock(parsed);
  if (!clock) return null;
  const address = Array.isArray(email.from) && email.from[0]?.email ? email.from[0].email : null;
  const savedZone = address ? zoneFor(addressZones, address) : null;
  return {
    sent: formatTime(clock.shifted, "UTC", locale2),
    yours: formatTime(parsed.instant, home || void 0, locale2),
    offsetMinutes: parsed.offsetMinutes,
    offset: formatOffset(parsed.offsetMinutes),
    sameAsYours: home ? offsetMinutes(home, parsed.instant) === parsed.offsetMinutes : false,
    address,
    savedZone,
    nowThere: savedZone ? formatTime(now, savedZone, locale2) : null
  };
}
function worthShowing(info, home) {
  return !!info && (!info.sameAsYours || !!info.savedZone && info.savedZone !== home);
}

// timezones/src/lib/settings.js
var DEFAULTS = {
  favouriteZones: "",
  homeZone: "",
  workStart: 8,
  workEnd: 20,
  worldClock: false
};
function hour(value, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(24, Math.max(0, Math.round(n)));
}
function readSettings(raw = {}) {
  const s = { ...DEFAULTS, ...raw || {} };
  const homeEntry = String(s.homeZone ?? "").trim();
  const homeResolved = homeEntry ? resolveZone(homeEntry) : null;
  const home = homeResolved || browserZone();
  const { zones, unknown } = parseZoneList(s.favouriteZones);
  let workStart = hour(s.workStart, DEFAULTS.workStart);
  let workEnd = hour(s.workEnd, DEFAULTS.workEnd);
  if (workEnd <= workStart) {
    workStart = DEFAULTS.workStart;
    workEnd = DEFAULTS.workEnd;
  }
  return {
    home,
    homeUnknown: homeEntry && !homeResolved ? homeEntry : null,
    favourites: zones.filter((z) => z !== home),
    unknown,
    workStart,
    workEnd,
    worldClock: s.worldClock === true || s.worldClock === "true"
  };
}
var SETTINGS_MIRROR_KEY = "settingsMirror";
function mirrorSettings(api) {
  const save = (settings) => {
    Promise.resolve(api.storage.set(SETTINGS_MIRROR_KEY, { ...settings ?? api.plugin.settings })).catch(() => {
    });
  };
  save(api.plugin.settings);
  return api.plugin.onSettingsChange((next) => save(next));
}
async function readMirroredSettings(api) {
  try {
    const value = await api.storage.get(SETTINGS_MIRROR_KEY);
    return value && typeof value === "object" && !Array.isArray(value) ? value : null;
  } catch {
    return null;
  }
}

// timezones/src/ui/compose-time.jsx
var import_react2 = require("react");
var import_ui2 = require("@plugin-host/ui");

// timezones/src/lib/compose.js
function nextFullHour(now, zone) {
  const w = wallClock(now, zone);
  const base = zonedToInstant({ ...w, minute: 0, second: 0 }, zone);
  const next = base + 36e5;
  const n = wallClock(next, zone);
  return { date: localDate(next, zone), time: `${String(n.hour).padStart(2, "0")}:${String(n.minute).padStart(2, "0")}` };
}
function composeLine({ date, time, fromZone, zones, locale: locale2 = "en" }) {
  if (!zones || !zones.length) return "";
  const instant = zonedToInstant(`${date}T${time}`, fromZone);
  if (!Number.isFinite(instant)) return "";
  return formatMultiZone(instant, zones, locale2);
}

// timezones/src/ui/common.jsx
var import_react = require("react");
var import_ui = require("@plugin-host/ui");
var import_jsx_runtime = require("react/jsx-runtime");
function useSettings() {
  const api = getApi();
  const [mirror, setMirror] = (0, import_react.useState)(null);
  (0, import_react.useEffect)(() => {
    if (!api) return void 0;
    let live = true;
    void readMirroredSettings(api).then((value) => {
      if (live && value) setMirror(value);
    });
    const off = api.plugin?.onSettingsChange?.(() => {
      if (live) setMirror(null);
    });
    return () => {
      live = false;
      if (typeof off === "function") off();
    };
  }, [api]);
  return readSettings(mirror ?? api?.plugin?.settings ?? {});
}
var ADDRESS_ZONES_REFRESH_MS = 3e3;
function useAddressZones() {
  const [zones, setZones] = (0, import_react.useState)({});
  const [loaded, setLoaded] = (0, import_react.useState)(false);
  (0, import_react.useEffect)(() => {
    let live = true;
    const api = getApi();
    if (!api) {
      setLoaded(true);
      return void 0;
    }
    let last = null;
    const load = () => loadAddressZones(api.storage).then((map) => {
      if (!live) return;
      const key = JSON.stringify(map);
      if (key !== last) {
        last = key;
        setZones(map);
      }
      setLoaded(true);
    }, () => {
      if (live) setLoaded(true);
    });
    void load();
    const id = setInterval(() => {
      void load();
    }, ADDRESS_ZONES_REFRESH_MS);
    return () => {
      live = false;
      clearInterval(id);
    };
  }, []);
  const save = (0, import_react.useCallback)(async (address, zone) => {
    const map = await setAddressZone(getApi().storage, address, zone);
    setZones(map);
    return map;
  }, []);
  return { zones, loaded, save };
}
var zoneOptions = null;
function options() {
  if (!zoneOptions) zoneOptions = knownZones().map((z) => ({ zone: z, city: zoneCity(z) }));
  return zoneOptions;
}
function ZoneField({ label, onSubmit, onCancel, submitLabel, autoFocus = true }) {
  const listId = (0, import_react.useId)();
  const [value, setValue] = (0, import_react.useState)("");
  const [error, setError] = (0, import_react.useState)("");
  const [busy, setBusy] = (0, import_react.useState)(false);
  const submit = async () => {
    const zone = resolveZone(value);
    if (!zone) {
      setError(t("zone.unknown"));
      return;
    }
    setError("");
    setBusy(true);
    try {
      await onSubmit(zone);
    } catch {
      setError(t("zone.saveFailed"));
    } finally {
      setBusy(false);
    }
  };
  return (
    // No <form>: the slot iframe's sandbox has no allow-forms, so a submit
    // would be blocked before any handler ran. Enter is handled by hand.
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Stack, { gap: 2, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Field, { label, error: error || void 0, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        import_ui.Input,
        {
          list: listId,
          value,
          autoFocus,
          placeholder: t("zone.placeholder"),
          "aria-invalid": error ? "true" : void 0,
          onChange: (e) => {
            setValue(e.target.value);
            setError("");
          },
          onKeyDown: (e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              void submit();
            }
            if (e.key === "Escape" && onCancel) {
              e.preventDefault();
              onCancel();
            }
          }
        }
      ) }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", { id: listId, children: options().map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: o.zone, children: o.city }, o.zone)) }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Row, { gap: 2, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Button, { size: "sm", busy, disabled: !value.trim(), onClick: () => void submit(), children: submitLabel ?? t("zone.save") }),
        onCancel && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Button, { size: "sm", variant: "secondary", onClick: onCancel, children: t("zone.cancel") })
      ] })
    ] })
  );
}

// timezones/src/ui/compose-time.jsx
var import_jsx_runtime2 = require("react/jsx-runtime");
var OPTIONS_SURFACE = "composer-options-menu";
var INSERT_ACTION = "insert-zone-times";
function composerActions() {
  return [{ id: INSERT_ACTION, label: t("compose.menu"), icon: "clock" }];
}
function openComposeDialog(api, composerId) {
  return api.ui.openDialog({
    title: t("compose.dialogTitle"),
    slot: "plugin-dialog",
    width: 520,
    extraProps: { composerId }
  });
}
async function copyText(text, field) {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
  }
  try {
    field?.focus();
    field?.select();
    if (document.execCommand?.("copy")) return true;
  } catch {
  }
  return false;
}
var STATUS = {
  copied: { tone: "success", key: "compose.copied" },
  blocked: { tone: "warning", key: "compose.copyFailed" },
  insertFailed: { tone: "danger", key: "compose.insertFailed" }
};
function ComposeDialog({ onResult, composerId }) {
  const settings = useSettings();
  const loc = locale();
  const start = (0, import_react2.useMemo)(() => nextFullHour(Date.now(), settings.home), [settings.home]);
  const [date, setDate] = (0, import_react2.useState)(start.date);
  const [time, setTime] = (0, import_react2.useState)(start.time);
  const [extra, setExtra] = (0, import_react2.useState)([]);
  const [off, setOff] = (0, import_react2.useState)([]);
  const [adding, setAdding] = (0, import_react2.useState)(false);
  const [status, setStatus] = (0, import_react2.useState)(null);
  const [busy, setBusy] = (0, import_react2.useState)(false);
  const fieldRef = (0, import_react2.useRef)(null);
  const all = [settings.home, ...settings.favourites, ...extra].filter((z, i, list) => list.indexOf(z) === i);
  const picked = all.filter((z) => !off.includes(z));
  const text = composeLine({ date, time, fromZone: settings.home, zones: picked, locale: loc });
  const canInsert = typeof composerId === "string" && composerId !== "";
  const toggle = (zone) => setOff((list) => list.includes(zone) ? list.filter((z) => z !== zone) : [...list, zone]);
  const copy = async () => {
    const ok = await copyText(text, fieldRef.current);
    setStatus(ok ? "copied" : "blocked");
  };
  const insert = async () => {
    setBusy(true);
    let ok = false;
    try {
      ok = await getApi()?.composer.replaceSelection(composerId, { text }) !== false;
    } catch {
      ok = false;
    }
    setBusy(false);
    if (ok) onResult?.(text);
    else setStatus("insertFailed");
  };
  const showCopy = !canInsert || status !== null;
  const buttons = [
    { id: "cancel", label: t("zone.cancel"), variant: "secondary" },
    ...showCopy ? [{ id: "copy", label: t("compose.copy"), variant: canInsert ? "secondary" : "primary", disabled: !text }] : [],
    ...canInsert ? [{ id: "insert", label: t("compose.insert"), variant: "primary", disabled: !text, busy }] : []
  ];
  const onButton = (id) => {
    if (id === "cancel") onResult?.(null);
    else if (id === "copy") void copy();
    else if (id === "insert") void insert();
  };
  const shown = status ? STATUS[status] : null;
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Stack, { gap: 4, children: [
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Row, { gap: 4, align: "start", children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Field, { label: t("compose.date"), children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Input, { type: "date", value: date, onChange: (e) => {
        setDate(e.target.value);
        setStatus(null);
      } }) }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Field, { label: t("compose.time", { city: zoneCity(settings.home) }), children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Input, { type: "time", value: time, onChange: (e) => {
        setTime(e.target.value);
        setStatus(null);
      } }) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.Stack, { gap: 2, children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Text, { weight: "medium", children: t("compose.zones") }),
      all.map((zone) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
        import_ui2.Checkbox,
        {
          checked: !off.includes(zone),
          onChange: () => {
            toggle(zone);
            setStatus(null);
          },
          label: zoneCity(zone),
          hint: zone
        },
        zone
      )),
      adding ? /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
        ZoneField,
        {
          label: t("compose.addZone"),
          submitLabel: t("compose.add"),
          onCancel: () => setAdding(false),
          onSubmit: (zone) => {
            setExtra((list) => [...list, zone]);
            setOff((list) => list.filter((z) => z !== zone));
            setAdding(false);
            setStatus(null);
          }
        }
      ) : /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Row, { children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.LinkButton, { icon: "plus", onClick: () => setAdding(true), children: t("compose.addZone") }) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Field, { label: t("compose.preview"), children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Textarea, { ref: fieldRef, readOnly: true, rows: 2, value: text }) }),
    !text && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Alert, { tone: "warning", icon: "alert-triangle", children: t("compose.noZones") }),
    shown && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Alert, { tone: shown.tone, children: t(shown.key) }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.DialogButtons, { buttons, onClick: onButton })
  ] });
}

// timezones/src/ui/event-zones.jsx
var import_react3 = require("react");
var import_ui3 = require("@plugin-host/ui");
var import_jsx_runtime3 = require("react/jsx-runtime");
function range(row, loc) {
  const from = formatTime(row.start, row.zone, loc);
  if (row.end <= row.start) return from;
  return `${from}–${formatTime(row.end, row.zone, loc)}`;
}
function detail(row, loc) {
  const parts = [range(row, loc) + (row.dayShift !== 0 ? ` (${t(row.dayShift > 0 ? "event.nextDay" : "event.prevDay")})` : "")];
  parts.push(formatOffset(offsetMinutes(row.zone, row.start)));
  if (row.emails.length === 0) parts.push(t("event.favourite"));
  return parts.join(" · ");
}
function title(row) {
  return [zoneCity(row.zone), ...row.emails].join(" · ");
}
function EventZones(props) {
  const eventData = props?.event ?? props?.eventData ?? null;
  const settings = useSettings();
  const { zones, loaded, save } = useAddressZones();
  const [editing, setEditing] = (0, import_react3.useState)(null);
  if (!loaded) return null;
  const info = eventZones(eventData, settings, zones);
  if (!info || info.allDay) return null;
  if (info.rows.length === 0 && info.missing.length === 0) return null;
  const loc = locale();
  const warning = outsideHoursWarning(info, settings, t, loc);
  return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(import_ui3.Stack, { gap: 2, children: [
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.Text, { weight: "medium", children: t("event.heading") }),
    info.rows.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.List, { label: t("event.heading"), children: info.rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
      import_ui3.ListRow,
      {
        title: title(row),
        subtitle: detail(row, loc),
        actions: row.outside ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.Badge, { tone: "warning", children: t("event.outside") }) : void 0
      },
      row.zone
    )) }),
    warning && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.Alert, { tone: "warning", icon: "alert-triangle", children: warning.message }),
    info.missing.map((address) => editing === address ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
      ZoneField,
      {
        label: t("zone.labelFor", { address }),
        onCancel: () => setEditing(null),
        onSubmit: async (zone) => {
          await save(address, zone);
          setEditing(null);
        }
      },
      address
    ) : /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(import_ui3.Row, { gap: 2, children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.Text, { tone: "muted", children: t("event.missing", { address }) }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_ui3.LinkButton, { onClick: () => setEditing(address), "aria-label": t("zone.labelFor", { address }), children: t("event.set") })
    ] }, address))
  ] });
}

// timezones/src/ui/sender-time.jsx
var import_react4 = require("react");
var import_ui4 = require("@plugin-host/ui");
var import_jsx_runtime4 = require("react/jsx-runtime");
function useSenderInfo(email) {
  const settings = useSettings();
  const { zones, loaded, save } = useAddressZones();
  const info = senderTime(email, { home: settings.home, addressZones: zones, locale: locale() });
  return { info, settings, loaded, save };
}
function nowThere(info) {
  return info.nowThere ? t("reader.nowThere", { time: info.nowThere, city: zoneCity(info.savedZone) }) : "";
}
function SenderBanner({ email }) {
  const { info, settings, loaded } = useSenderInfo(email);
  if (!loaded || !worthShowing(info, settings.home)) return null;
  const there = nowThere(info);
  return (
    // The time there now is a second, muted part: on a narrow reader it
    // wraps below the line rather than pushing the line under the icon.
    /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(import_ui4.InfoBar, { compact: true, icon: "clock", title: t("reader.banner", { time: info.sent, offset: info.offset, yours: info.yours }), children: there && /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(import_ui4.Text, { tone: "muted", children: there }) })
  );
}
function SenderDetails({ email }) {
  const { info, loaded, save } = useSenderInfo(email);
  const [editing, setEditing] = (0, import_react4.useState)(false);
  if (!loaded || !info) return null;
  const there = nowThere(info);
  return (
    // The details' label and value columns, so the row lines up with Sent
    // and Received above it.
    /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(import_ui4.DetailList, { children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(import_ui4.DetailRow, { label: t("reader.label"), children: /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(import_ui4.Stack, { gap: 2, children: [
      /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(import_ui4.Row, { gap: 2, align: "baseline", children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(import_ui4.Text, { children: `${info.sent} (${info.offset})${there ? ` · ${there}` : ""}` }),
        info.address && !editing && /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(import_ui4.LinkButton, { onClick: () => setEditing(true), children: t(info.savedZone ? "reader.change" : "reader.setFor") })
      ] }),
      editing && /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
        ZoneField,
        {
          label: t("zone.labelFor", { address: info.address }),
          onCancel: () => setEditing(false),
          onSubmit: async (zone) => {
            await save(info.address, zone);
            setEditing(false);
          }
        }
      )
    ] }) }) })
  );
}

// timezones/src/ui/world-clock.jsx
var import_react5 = require("react");
var import_ui5 = require("@plugin-host/ui");
var import_jsx_runtime5 = require("react/jsx-runtime");
function useNow(ms = 3e4) {
  const [now, setNow] = (0, import_react5.useState)(() => Date.now());
  (0, import_react5.useEffect)(() => {
    const id = setInterval(() => setNow(Date.now()), ms);
    return () => clearInterval(id);
  }, [ms]);
  return now;
}
function WorldClock() {
  const settings = useSettings();
  const now = useNow();
  const loc = locale();
  const zones = [settings.home, ...settings.favourites];
  return /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)(import_jsx_runtime5.Fragment, { children: [
    zones.map((zone) => {
      const shift = dayShift(now, zone, settings.home);
      const off = isOutsideHours(now, now, zone, settings.workStart, settings.workEnd);
      const city = zoneCity(zone);
      const title2 = [city, formatOffset(offsetMinutes(zone, now)), ...off ? [t("event.outside")] : []].join(" · ");
      return /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
        import_ui5.SidebarRow,
        {
          icon: off ? "moon" : "sun",
          label: city,
          detail: `${formatTime(now, zone, loc)}${shift !== 0 ? shift > 0 ? " +1" : " −1" : ""}`,
          title: title2
        },
        zone
      );
    }),
    settings.favourites.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(import_ui5.SidebarEmpty, { children: t("clock.empty") })
  ] });
}

// timezones/src/ui/settings-section.jsx
var import_react6 = require("react");
var import_ui6 = require("@plugin-host/ui");
var import_jsx_runtime6 = require("react/jsx-runtime");
function ZoneRow({ zone, now }) {
  return /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(
    import_ui6.ListRow,
    {
      title: zoneCity(zone),
      subtitle: `${zone} · ${formatOffset(offsetMinutes(zone, now))}`,
      meta: [formatTime(now, zone, locale())]
    }
  );
}
function SettingsSection() {
  const settings = useSettings();
  const { zones, save } = useAddressZones();
  const [address, setAddress] = (0, import_react6.useState)("");
  const [addressError, setAddressError] = (0, import_react6.useState)("");
  const [adding, setAdding] = (0, import_react6.useState)(false);
  const now = Date.now();
  const people = Object.entries(zones);
  return /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)(import_ui6.Stack, { gap: 6, children: [
    /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)(import_ui6.Section, { title: t("settings.yourZone"), children: [
      /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(import_ui6.List, { label: t("settings.yourZone"), children: /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(ZoneRow, { zone: settings.home, now }) }),
      settings.homeUnknown && /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(import_ui6.Alert, { tone: "warning", icon: "alert-triangle", children: t("settings.homeUnknown", { entry: settings.homeUnknown }) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)(import_ui6.Section, { title: t("settings.favourites"), children: [
      settings.favourites.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(import_ui6.Text, { tone: "muted", children: t("settings.noFavourites") }) : /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(import_ui6.List, { label: t("settings.favourites"), children: settings.favourites.map((z) => /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(ZoneRow, { zone: z, now }, z)) }),
      settings.unknown.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(import_ui6.Alert, { tone: "warning", icon: "alert-triangle", children: t("settings.unknown", { entries: settings.unknown.join(", ") }) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)(import_ui6.Section, { title: t("settings.people"), children: [
      people.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(import_ui6.Text, { tone: "muted", children: t("settings.noPeople") }) : /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(import_ui6.List, { label: t("settings.people"), children: people.map(([a, z]) => /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(
        import_ui6.ListRow,
        {
          title: a,
          subtitle: `${zoneCity(z)} · ${formatOffset(offsetMinutes(z, now))}`,
          actions: /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(import_ui6.RowAction, { icon: "trash", label: `${t("remove")}: ${a}`, onClick: () => void save(a, null) })
        },
        a
      )) }),
      !adding ? /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(import_ui6.Row, { children: /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(import_ui6.Button, { variant: "secondary", icon: "plus", onClick: () => setAdding(true), children: t("settings.addPerson") }) }) : /* @__PURE__ */ (0, import_jsx_runtime6.jsxs)(import_ui6.Stack, { gap: 4, children: [
        /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(import_ui6.Field, { label: t("settings.address"), error: addressError || void 0, children: /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(
          import_ui6.Input,
          {
            type: "email",
            value: address,
            autoFocus: true,
            onChange: (e) => {
              setAddress(e.target.value);
              setAddressError("");
            }
          }
        ) }),
        /* @__PURE__ */ (0, import_jsx_runtime6.jsx)(
          ZoneField,
          {
            autoFocus: false,
            label: t("zone.label"),
            onCancel: () => {
              setAdding(false);
              setAddress("");
              setAddressError("");
            },
            onSubmit: async (zone) => {
              const a = normaliseAddress(address);
              if (!a) {
                setAddressError(t("settings.invalidAddress"));
                return;
              }
              await save(a, zone);
              setAdding(false);
              setAddress("");
            }
          }
        )
      ] })
    ] })
  ] });
}

// timezones/src/index.js
var ALWAYS = {
  "settings-section": { component: SettingsSection },
  "calendar-event-form": { component: EventZones },
  "email-banner": {
    component: SenderBanner,
    // Only when the sender's clock differed from yours, or a zone other
    // than yours is saved for them (the bar then says the time there now).
    shouldShow: (ctx) => {
      const api = getApi();
      const home = readSettings(api?.plugin?.settings ?? {}).home;
      return worthShowing(senderTime(ctx?.email, { home }), home);
    }
  },
  "plugin-dialog": { component: ComposeDialog },
  "email-details-section": {
    component: SenderDetails,
    // One row under "Recipients & routing", where the Sent date is.
    shouldShow: (ctx) => ctx?.category === "recipients_routing" && !!senderTime(ctx?.email, {})
  }
};
function slotsFor(settings) {
  return settings.worldClock ? { ...ALWAYS, "sidebar-section": { component: WorldClock } } : { ...ALWAYS };
}
var slots = slotsFor(readSettings(getApi()?.plugin?.settings ?? {}));
var hooks = {
  /** The Options menu entry: the dialog, which inserts into that composer. */
  onAction({ surface, actionId, context } = {}) {
    const api = getApi();
    if (!api || surface !== OPTIONS_SURFACE || actionId !== INSERT_ACTION) return;
    const composerId = context?.composerId;
    if (typeof composerId !== "string" || !composerId) return;
    void Promise.resolve(openComposeDialog(api, composerId)).catch(() => {
    });
  },
  /** Adds "Outside 08:00–20:00 for …" to the event form's warnings. */
  async onCheckEventConflicts(warnings, context) {
    const api = getApi();
    const list = Array.isArray(warnings) ? warnings : [];
    if (!api) return list;
    const settings = readSettings(api.plugin.settings);
    const info = eventZones(context?.event, settings, await loadAddressZones(api.storage));
    const warning = outsideHoursWarning(info, settings, api.i18n.t, api.i18n.getLocale());
    return warning ? [...list, warning] : list;
  }
};
async function registerActions(api) {
  await api.ui.setActions(OPTIONS_SURFACE, composerActions());
}
function activate(api) {
  mirrorSettings(api);
  const register = () => registerActions(api).catch((err) => api.log?.warn?.("setActions failed", err));
  void register();
  api.i18n.onLocaleChange?.(() => {
    void register();
  });
}
var index_default = { slots, hooks, activate };
