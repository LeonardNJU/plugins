var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// timezones/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  default: () => index_default,
  hooks: () => hooks,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);

// timezones/src/host.js
var hostApi = null;
try {
  hostApi = typeof require === "function" ? require("@plugin-host") : null;
} catch {
  hostApi = null;
}
function getApi() {
  return hostApi;
}
function t(key, vars) {
  return hostApi ? hostApi.i18n.t(key, vars) : key;
}
function locale() {
  try {
    return hostApi?.i18n?.getLocale?.() || "en";
  } catch {
    return "en";
  }
}

// timezones/src/lib/zones.js
var MINUTE = 6e4;
var HOUR = 60 * MINUTE;
var DAY = 24 * HOUR;
var partsFormatters = /* @__PURE__ */ new Map();
function partsFormatter(zone) {
  let f = partsFormatters.get(zone);
  if (!f) {
    f = new Intl.DateTimeFormat("en-US", {
      timeZone: zone,
      hourCycle: "h23",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    });
    partsFormatters.set(zone, f);
  }
  return f;
}
function isValidZone(zone) {
  if (typeof zone !== "string" || !zone) return false;
  try {
    partsFormatter(zone);
    return true;
  } catch {
    return false;
  }
}
function wallClock(instant, zone) {
  const parts = {};
  for (const p of partsFormatter(zone).formatToParts(new Date(instant))) parts[p.type] = p.value;
  return {
    year: Number(parts.year),
    month: Number(parts.month),
    day: Number(parts.day),
    hour: Number(parts.hour) % 24,
    minute: Number(parts.minute),
    second: Number(parts.second)
  };
}
function offsetMinutes(zone, instant) {
  const w = wallClock(instant, zone);
  const asUtc = Date.UTC(w.year, w.month - 1, w.day, w.hour, w.minute, w.second);
  const whole = Math.floor(instant / 1e3) * 1e3;
  return Math.round((asUtc - whole) / MINUTE);
}
function formatOffset(minutes) {
  if (!minutes) return "UTC";
  const sign = minutes > 0 ? "+" : "−";
  const abs = Math.abs(minutes);
  const h = Math.floor(abs / 60);
  const m = abs % 60;
  return `UTC${sign}${h}${m ? `:${String(m).padStart(2, "0")}` : ""}`;
}
var LOCAL_RE = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?$/;
function parseLocal(text) {
  const m = LOCAL_RE.exec(String(text ?? "").trim());
  if (!m) return null;
  const [, y, mo, d, h, mi, s] = m.map(Number);
  if (mo < 1 || mo > 12 || d < 1 || d > 31 || h > 23 || mi > 59) return null;
  return { year: y, month: mo, day: d, hour: h, minute: mi, second: s || 0 };
}
function sameWall(a, b) {
  return a.year === b.year && a.month === b.month && a.day === b.day && a.hour === b.hour && a.minute === b.minute;
}
function zonedToInstant(local, zone) {
  const f = typeof local === "string" ? parseLocal(local) : local;
  if (!f) return NaN;
  const asUtc = Date.UTC(f.year, f.month - 1, f.day, f.hour, f.minute, f.second || 0);
  const before = offsetMinutes(zone, asUtc - DAY);
  const after = offsetMinutes(zone, asUtc + DAY);
  const candidates = [.../* @__PURE__ */ new Set([before, after])].map((off) => asUtc - off * MINUTE).filter((t2) => sameWall(wallClock(t2, zone), f)).sort((a, b) => a - b);
  if (candidates.length) return candidates[0];
  return asUtc - before * MINUTE;
}
function minutesOfDay(instant, zone) {
  const w = wallClock(instant, zone);
  return w.hour * 60 + w.minute;
}
function localDate(instant, zone) {
  const w = wallClock(instant, zone);
  return `${w.year}-${String(w.month).padStart(2, "0")}-${String(w.day).padStart(2, "0")}`;
}
function dayShift(instant, zone, homeZone) {
  const a = Date.parse(`${localDate(instant, zone)}T00:00:00Z`);
  const b = Date.parse(`${localDate(instant, homeZone)}T00:00:00Z`);
  return Math.round((a - b) / DAY);
}
function isOutsideHours(start, end, zone, fromHour = 8, toHour = 20) {
  const s = minutesOfDay(start, zone);
  const stop = Number.isFinite(end) && end > start ? end : start;
  let e = minutesOfDay(stop, zone);
  const days = Math.round((Date.parse(`${localDate(stop, zone)}T00:00:00Z`) - Date.parse(`${localDate(start, zone)}T00:00:00Z`)) / DAY);
  if (days === 1 && e === 0) e = 24 * 60;
  else if (days !== 0) return true;
  return s < fromHour * 60 || s >= toHour * 60 || e > toHour * 60;
}
function zoneCity(zone) {
  if (!zone) return "";
  if (/^(Etc\/)?(UTC|GMT|UCT|Zulu|Universal)$/i.test(zone)) return "UTC";
  const last = zone.split("/").pop() || zone;
  return last.replace(/_/g, " ");
}
var allZones = null;
function knownZones() {
  if (allZones) return allZones;
  try {
    allZones = typeof Intl.supportedValuesOf === "function" ? Intl.supportedValuesOf("timeZone") : [];
  } catch {
    allZones = [];
  }
  if (!allZones.includes("UTC")) allZones = [...allZones, "UTC"];
  return allZones;
}
function fold(text) {
  return String(text).normalize("NFD").replace(/\p{M}/gu, "").toLowerCase().replace(/[\s_-]+/g, " ").trim();
}
var ALIASES = {
  "utc": "UTC",
  "gmt": "UTC",
  "z": "UTC",
  "san francisco": "America/Los_Angeles",
  "seattle": "America/Los_Angeles",
  "silicon valley": "America/Los_Angeles",
  "washington": "America/New_York",
  "boston": "America/New_York",
  "miami": "America/New_York",
  "atlanta": "America/New_York",
  "houston": "America/Chicago",
  "dallas": "America/Chicago",
  "austin": "America/Chicago",
  "munich": "Europe/Berlin",
  "muenchen": "Europe/Berlin",
  "munchen": "Europe/Berlin",
  "hamburg": "Europe/Berlin",
  "frankfurt": "Europe/Berlin",
  "cologne": "Europe/Berlin",
  "koln": "Europe/Berlin",
  "zurich": "Europe/Zurich",
  "geneva": "Europe/Zurich",
  "mumbai": "Asia/Kolkata",
  "bombay": "Asia/Kolkata",
  "delhi": "Asia/Kolkata",
  "new delhi": "Asia/Kolkata",
  "bangalore": "Asia/Kolkata",
  "bengaluru": "Asia/Kolkata",
  "calcutta": "Asia/Kolkata",
  "beijing": "Asia/Shanghai",
  "peking": "Asia/Shanghai",
  "shenzhen": "Asia/Shanghai",
  "saigon": "Asia/Ho_Chi_Minh",
  "ho chi minh city": "Asia/Ho_Chi_Minh",
  "kyiv": "Europe/Kyiv",
  "kiev": "Europe/Kyiv",
  "sao paulo": "America/Sao_Paulo",
  "rio de janeiro": "America/Sao_Paulo",
  "rio": "America/Sao_Paulo",
  "mexico city": "America/Mexico_City",
  "tel aviv": "Asia/Jerusalem",
  "abu dhabi": "Asia/Dubai",
  "osaka": "Asia/Tokyo",
  "canberra": "Australia/Sydney",
  "wellington": "Pacific/Auckland"
};
function resolveZone(entry) {
  const raw = String(entry ?? "").trim();
  if (!raw) return null;
  const zones = knownZones();
  const exact = zones.find((z) => z.toLowerCase() === raw.toLowerCase());
  if (exact) return exact;
  if (raw.includes("/") && isValidZone(raw)) return canonical(raw);
  const key = fold(raw);
  if (ALIASES[key]) return ALIASES[key];
  const byCity = zones.find((z) => fold(zoneCity(z)) === key);
  if (byCity) return byCity;
  return null;
}
function canonical(zone) {
  try {
    return new Intl.DateTimeFormat("en-US", { timeZone: zone }).resolvedOptions().timeZone || zone;
  } catch {
    return zone;
  }
}
function parseZoneList(text) {
  const zones = [];
  const unknown = [];
  for (const part of String(text ?? "").split(/[,;\n]+/)) {
    const entry = part.trim();
    if (!entry) continue;
    const zone = resolveZone(entry);
    if (!zone) unknown.push(entry);
    else if (!zones.includes(zone)) zones.push(zone);
  }
  return { zones, unknown };
}
var timeFormatters = /* @__PURE__ */ new Map();
function formatTime(instant, zone, locale2 = "en") {
  const key = `${locale2}|${zone}`;
  let f = timeFormatters.get(key);
  if (!f) {
    let tag = locale2;
    try {
      new Intl.DateTimeFormat(tag);
    } catch {
      tag = "en";
    }
    const twelve = new Intl.DateTimeFormat(tag, { hour: "numeric" }).resolvedOptions().hour12 === true;
    f = new Intl.DateTimeFormat(tag, { timeZone: zone, hour: twelve ? "numeric" : "2-digit", minute: "2-digit" });
    timeFormatters.set(key, f);
  }
  return f.format(new Date(instant));
}
function browserZone() {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
  } catch {
    return "UTC";
  }
}

// timezones/src/lib/address-zones.js
var STORAGE_KEY = "addressZones";
var MAX_ENTRIES = 500;
function normaliseAddress(address) {
  const a = String(address ?? "").trim().toLowerCase();
  return /^[^\s@]+@[^\s@]+$/.test(a) ? a : null;
}
function clean(map) {
  const out = {};
  if (!map || typeof map !== "object") return out;
  for (const [address, zone] of Object.entries(map)) {
    const a = normaliseAddress(address);
    if (a && isValidZone(zone)) out[a] = zone;
  }
  return out;
}
async function loadAddressZones(storage) {
  try {
    return clean(await storage.get(STORAGE_KEY));
  } catch {
    return {};
  }
}
async function setAddressZone(storage, address, zone) {
  const a = normaliseAddress(address);
  if (!a) throw new Error("invalid-address");
  if (zone !== null && !isValidZone(zone)) throw new Error("invalid-zone");
  const map = await loadAddressZones(storage);
  if (zone === null) delete map[a];
  else {
    delete map[a];
    map[a] = zone;
    const keys = Object.keys(map);
    for (const k of keys.slice(0, Math.max(0, keys.length - MAX_ENTRIES))) delete map[k];
  }
  await storage.set(STORAGE_KEY, map);
  return map;
}
function zoneFor(map, address) {
  const a = normaliseAddress(address);
  return a && map ? map[a] ?? null : null;
}

// timezones/src/lib/event.js
function parseDuration(text) {
  const m = /^P(?:(\d+)W)?(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$/.exec(String(text ?? ""));
  if (!m || text === "P" || text === "PT") return NaN;
  const [, w, d, h, mi, sec] = m.map((v) => Number(v || 0));
  return ((((w * 7 + d) * 24 + h) * 60 + mi) * 60 + sec) * 1e3;
}
function normaliseEvent(e) {
  if (!e || typeof e !== "object") return null;
  const attendees = Array.isArray(e.attendees) ? e.attendees.filter((a) => typeof a === "string") : Array.isArray(e.participants) ? e.participants.map((p) => p?.email).filter((a) => typeof a === "string" && a) : [];
  return {
    start: e.start,
    end: typeof e.end === "string" ? e.end : null,
    duration: typeof e.duration === "string" ? e.duration : null,
    zone: isValidZone(e.timeZone) ? e.timeZone : null,
    isAllDay: !!e.isAllDay,
    attendees
  };
}
function eventZones(eventData, settings, addressZones) {
  const ev = normaliseEvent(eventData);
  if (!ev) return null;
  const home = settings.home;
  const evZone = ev.zone ?? home;
  const start = zonedToInstant(ev.start, evZone);
  if (!Number.isFinite(start)) return null;
  let end = ev.end ? zonedToInstant(ev.end, evZone) : start + parseDuration(ev.duration);
  if (!Number.isFinite(end) || end < start) end = start;
  const byZone = /* @__PURE__ */ new Map();
  const missing = [];
  for (const address of ev.attendees) {
    const zone = zoneFor(addressZones, address);
    if (!zone) {
      if (address) missing.push(address);
      continue;
    }
    if (zone === home) continue;
    const row = byZone.get(zone) ?? { zone, emails: [], favourite: false };
    row.emails.push(address);
    byZone.set(zone, row);
  }
  for (const zone of settings.favourites) {
    const row = byZone.get(zone) ?? { zone, emails: [], favourite: false };
    row.favourite = true;
    byZone.set(zone, row);
  }
  const allDay = ev.isAllDay;
  const rows = [...byZone.values()].map((row) => ({
    ...row,
    start,
    end,
    outside: !allDay && isOutsideHours(start, end, row.zone, settings.workStart, settings.workEnd),
    dayShift: dayShift(start, row.zone, evZone)
  }));
  return {
    allDay,
    start,
    end,
    rows,
    missing,
    // Only participants get a warning; favourites just show the time.
    warnings: rows.filter((r) => r.outside && r.emails.length > 0)
  };
}
function hourLabel(hour2, locale2) {
  return formatTime(Date.UTC(2026, 0, 1, hour2 % 24, 0), "UTC", locale2);
}
function outsideHoursWarning(info, settings, t2, locale2) {
  if (!info || info.allDay || info.warnings.length === 0) return null;
  const names = info.warnings.map((r) => `${r.emails.join(", ")} (${zoneCity(r.zone)})`).join("; ");
  return {
    key: "timezones-outside-hours",
    severity: "warning",
    message: t2("event.warning", { from: hourLabel(settings.workStart, locale2), to: hourLabel(settings.workEnd, locale2), names })
  };
}

// timezones/src/lib/settings.js
var DEFAULTS = {
  favouriteZones: "",
  homeZone: "",
  workStart: 8,
  workEnd: 20,
  worldClock: false
};
function hour(value, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(24, Math.max(0, Math.round(n)));
}
function readSettings(raw = {}) {
  const s = { ...DEFAULTS, ...raw || {} };
  const homeEntry = String(s.homeZone ?? "").trim();
  const homeResolved = homeEntry ? resolveZone(homeEntry) : null;
  const home = homeResolved || browserZone();
  const { zones, unknown } = parseZoneList(s.favouriteZones);
  let workStart = hour(s.workStart, DEFAULTS.workStart);
  let workEnd = hour(s.workEnd, DEFAULTS.workEnd);
  if (workEnd <= workStart) {
    workStart = DEFAULTS.workStart;
    workEnd = DEFAULTS.workEnd;
  }
  return {
    home,
    homeUnknown: homeEntry && !homeResolved ? homeEntry : null,
    favourites: zones.filter((z) => z !== home),
    unknown,
    workStart,
    workEnd,
    worldClock: s.worldClock === true || s.worldClock === "true"
  };
}
var SETTINGS_MIRROR_KEY = "settingsMirror";
function mirrorSettings(api) {
  const save = (settings) => {
    Promise.resolve(api.storage.set(SETTINGS_MIRROR_KEY, { ...settings ?? api.plugin.settings })).catch(() => {
    });
  };
  save(api.plugin.settings);
  return api.plugin.onSettingsChange((next) => save(next));
}
async function readMirroredSettings(api) {
  try {
    const value = await api.storage.get(SETTINGS_MIRROR_KEY);
    return value && typeof value === "object" && !Array.isArray(value) ? value : null;
  } catch {
    return null;
  }
}

// timezones/src/ui/event-zones.jsx
var import_react2 = require("react");

// timezones/src/ui/common.jsx
var import_react = require("react");
var import_jsx_runtime = require("react/jsx-runtime");
var CSS = `
*, *::before, *::after { box-sizing: border-box; }
body { margin: 0; font-size: 13px; line-height: 1.45; }
.tz-muted { color: var(--color-muted-foreground); }
.tz-warn { color: var(--color-warning, #b45309); }
.tz-error { color: var(--color-destructive); }
.tz-btn {
  display: inline-flex; align-items: center; gap: 6px; height: 28px; padding: 0 10px;
  border: 1px solid var(--color-border); border-radius: var(--radius-md, 6px);
  background: var(--color-background); color: var(--color-foreground);
  font: inherit; font-size: 12px; cursor: pointer; white-space: nowrap;
}
.tz-btn:hover { background: var(--color-muted); }
.tz-btn:disabled { opacity: .5; cursor: default; }
.tz-btn-primary { background: var(--color-primary); color: var(--color-primary-foreground); border-color: var(--color-primary); }
.tz-btn-primary:hover { background: var(--color-primary); opacity: .9; }
.tz-btn-ghost { border-color: transparent; background: transparent; color: var(--color-muted-foreground); padding: 0 6px; }
.tz-btn-ghost:hover { color: var(--color-foreground); }
.tz-link { border: 0; background: none; padding: 0; font: inherit; font-size: 12px; color: var(--color-primary); cursor: pointer; text-decoration: underline; }
.tz-input {
  height: 28px; padding: 0 8px; min-width: 0;
  border: 1px solid var(--color-input, var(--color-border)); border-radius: var(--radius-md, 6px);
  background: var(--color-background); color: var(--color-foreground); font: inherit; font-size: 12px;
}
.tz-btn:focus-visible, .tz-input:focus-visible, .tz-link:focus-visible, input[type=checkbox]:focus-visible {
  outline: 2px solid var(--color-ring, var(--color-primary)); outline-offset: 1px;
}
.tz-row { display: flex; align-items: baseline; gap: 8px; flex-wrap: wrap; }
.tz-label { font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: .04em; color: var(--color-muted-foreground); }
.tz-sr { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; }
`;
function Styles() {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { children: CSS });
}
function ClockIcon({ size = 14 }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", "aria-hidden": "true", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", { cx: "12", cy: "12", r: "9" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 7v5l3 3" })
  ] });
}
function useSettings() {
  const api = getApi();
  const [mirror, setMirror] = (0, import_react.useState)(null);
  (0, import_react.useEffect)(() => {
    if (!api) return void 0;
    let live = true;
    void readMirroredSettings(api).then((value) => {
      if (live && value) setMirror(value);
    });
    const off = api.plugin?.onSettingsChange?.(() => {
      if (live) setMirror(null);
    });
    return () => {
      live = false;
      if (typeof off === "function") off();
    };
  }, [api]);
  return readSettings(mirror ?? api?.plugin?.settings ?? {});
}
function useAddressZones() {
  const [zones, setZones] = (0, import_react.useState)({});
  const [loaded, setLoaded] = (0, import_react.useState)(false);
  (0, import_react.useEffect)(() => {
    let live = true;
    const api = getApi();
    if (!api) {
      setLoaded(true);
      return void 0;
    }
    void loadAddressZones(api.storage).then((map) => {
      if (live) {
        setZones(map);
        setLoaded(true);
      }
    });
    return () => {
      live = false;
    };
  }, []);
  const save = (0, import_react.useCallback)(async (address, zone) => {
    const map = await setAddressZone(getApi().storage, address, zone);
    setZones(map);
    return map;
  }, []);
  return { zones, loaded, save };
}
var zoneOptions = null;
function options() {
  if (!zoneOptions) zoneOptions = knownZones().map((z) => ({ zone: z, city: zoneCity(z) }));
  return zoneOptions;
}
function ZoneField({ label, onSubmit, onCancel, submitLabel, autoFocus = true }) {
  const listId = (0, import_react.useId)();
  const inputId = (0, import_react.useId)();
  const [value, setValue] = (0, import_react.useState)("");
  const [error, setError] = (0, import_react.useState)("");
  const [busy, setBusy] = (0, import_react.useState)(false);
  const submit = async () => {
    const zone = resolveZone(value);
    if (!zone) {
      setError(t("zone.unknown"));
      return;
    }
    setError("");
    setBusy(true);
    try {
      await onSubmit(zone);
    } catch {
      setError(t("zone.saveFailed"));
    } finally {
      setBusy(false);
    }
  };
  return (
    // No <form>: the slot iframe's sandbox has no allow-forms, so a submit
    // would be blocked before any handler ran. Enter is handled by hand.
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { display: "flex", flexDirection: "column", gap: 4 }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { htmlFor: inputId, className: "tz-muted", style: { fontSize: 12 }, children: label }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { display: "flex", gap: 6, flexWrap: "wrap" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          "input",
          {
            id: inputId,
            className: "tz-input",
            list: listId,
            value,
            autoFocus,
            placeholder: t("zone.placeholder"),
            "aria-invalid": error ? "true" : void 0,
            onChange: (e) => {
              setValue(e.target.value);
              setError("");
            },
            onKeyDown: (e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                void submit();
              }
              if (e.key === "Escape" && onCancel) {
                e.preventDefault();
                onCancel();
              }
            },
            style: { flex: "1 1 160px" }
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", { id: listId, children: options().map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: o.zone, children: o.city }, o.zone)) }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "tz-btn tz-btn-primary", disabled: busy || !value.trim(), onClick: () => void submit(), children: submitLabel ?? t("zone.save") }),
        onCancel && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "tz-btn", onClick: onCancel, children: t("zone.cancel") })
      ] }),
      error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { role: "alert", className: "tz-error", style: { fontSize: 12 }, children: error })
    ] })
  );
}

// timezones/src/ui/event-zones.jsx
var import_jsx_runtime2 = require("react/jsx-runtime");
function range(row, loc) {
  const from = formatTime(row.start, row.zone, loc);
  if (row.end <= row.start) return from;
  return `${from}–${formatTime(row.end, row.zone, loc)}`;
}
function EventZones(props) {
  const eventData = props?.event ?? props?.eventData ?? null;
  const settings = useSettings();
  const { zones, loaded, save } = useAddressZones();
  const [editing, setEditing] = (0, import_react2.useState)(null);
  if (!loaded) return null;
  const info = eventZones(eventData, settings, zones);
  if (!info || info.allDay) return null;
  if (info.rows.length === 0 && info.missing.length === 0) return null;
  const loc = locale();
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { "data-tz": "event", style: { display: "flex", flexDirection: "column", gap: 4, padding: "4px 0", fontSize: 13 }, children: [
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(Styles, {}),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "tz-row tz-muted", style: { gap: 6, alignItems: "center" }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(ClockIcon, {}),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { style: { fontWeight: 600 }, children: t("event.heading") })
    ] }),
    info.rows.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("ul", { "data-tz": "rows", style: { margin: 0, padding: 0, listStyle: "none", display: "flex", flexDirection: "column", gap: 2 }, children: info.rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("li", { className: "tz-row", style: { gap: 6 }, "data-zone": row.zone, children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("strong", { style: { fontWeight: 600 }, children: zoneCity(row.zone) }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { style: { fontVariantNumeric: "tabular-nums" }, children: range(row, loc) }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: "tz-muted", children: formatOffset(offsetMinutes(row.zone, row.start)) }),
      row.dayShift !== 0 && /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("span", { className: "tz-muted", children: [
        "(",
        t(row.dayShift > 0 ? "event.nextDay" : "event.prevDay"),
        ")"
      ] }),
      row.emails.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: "tz-muted", style: { overflowWrap: "anywhere" }, children: row.emails.join(", ") }) : /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("span", { className: "tz-muted", children: [
        "· ",
        t("event.favourite")
      ] }),
      row.outside && /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("span", { className: "tz-warn", children: [
        "· ",
        t("event.outside")
      ] })
    ] }, row.zone)) }),
    info.missing.map((address) => /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { "data-tz": "missing", children: editing === address ? /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
      ZoneField,
      {
        label: t("zone.labelFor", { address }),
        onCancel: () => setEditing(null),
        onSubmit: async (zone) => {
          await save(address, zone);
          setEditing(null);
        }
      }
    ) : /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "tz-row", style: { gap: 6 }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { className: "tz-muted", style: { overflowWrap: "anywhere" }, children: t("event.missing", { address }) }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("button", { type: "button", className: "tz-link", onClick: () => setEditing(address), "aria-label": t("zone.labelFor", { address }), children: t("event.set") })
    ] }) }, address))
  ] });
}

// timezones/src/ui/settings-section.jsx
var import_react3 = require("react");
var import_jsx_runtime3 = require("react/jsx-runtime");
function ZoneLine({ zone, now }) {
  return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("span", { children: [
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("strong", { children: zoneCity(zone) }),
    " ",
    /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("span", { className: "tz-muted", children: [
      zone,
      " · ",
      formatOffset(offsetMinutes(zone, now)),
      " · ",
      formatTime(now, zone, locale())
    ] })
  ] });
}
function SettingsSection() {
  const settings = useSettings();
  const { zones, save } = useAddressZones();
  const [address, setAddress] = (0, import_react3.useState)("");
  const [addressError, setAddressError] = (0, import_react3.useState)("");
  const [adding, setAdding] = (0, import_react3.useState)(false);
  const now = Date.now();
  const people = Object.entries(zones);
  return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { style: { display: "flex", flexDirection: "column", gap: 12, padding: "4px 0" }, "data-tz": "settings", children: [
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(Styles, {}),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("section", { "aria-labelledby": "tz-home", children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { id: "tz-home", className: "tz-label", children: t("settings.yourZone") }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(ZoneLine, { zone: settings.home, now }) }),
      settings.homeUnknown && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "tz-warn", role: "status", children: t("settings.homeUnknown", { entry: settings.homeUnknown }) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("section", { "aria-labelledby": "tz-fav", children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { id: "tz-fav", className: "tz-label", children: t("settings.favourites") }),
      settings.favourites.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "tz-muted", children: t("settings.noFavourites") }) : /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("ul", { style: { margin: 0, paddingInlineStart: 18 }, "data-tz": "favourites", children: settings.favourites.map((z) => /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(ZoneLine, { zone: z, now }) }, z)) }),
      settings.unknown.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "tz-warn", role: "status", "data-tz": "unknown", children: t("settings.unknown", { entries: settings.unknown.join(", ") }) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("section", { "aria-labelledby": "tz-people", children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { id: "tz-people", className: "tz-label", children: t("settings.people") }),
      people.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "tz-muted", children: t("settings.noPeople") }) : /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("ul", { style: { margin: 0, padding: 0, listStyle: "none", display: "flex", flexDirection: "column", gap: 2 }, "data-tz": "people", children: people.map(([a, z]) => /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("li", { className: "tz-row", style: { justifyContent: "space-between" }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("span", { style: { minWidth: 0, overflowWrap: "anywhere" }, children: [
          a,
          " ",
          /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("span", { className: "tz-muted", children: [
            "· ",
            zoneCity(z),
            " (",
            formatOffset(offsetMinutes(z, now)),
            ")"
          ] })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { type: "button", className: "tz-btn tz-btn-ghost", onClick: () => void save(a, null), "aria-label": `${t("remove")}: ${a}`, children: t("remove") })
      ] }, a)) }),
      !adding ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { type: "button", className: "tz-btn", style: { marginTop: 6 }, onClick: () => setAdding(true), children: t("settings.addPerson") }) : /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { style: { display: "flex", flexDirection: "column", gap: 6, marginTop: 6 }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("label", { className: "tz-muted", style: { fontSize: 12, display: "flex", flexDirection: "column", gap: 4 }, children: [
          t("settings.address"),
          /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
            "input",
            {
              className: "tz-input",
              type: "email",
              value: address,
              autoFocus: true,
              onChange: (e) => {
                setAddress(e.target.value);
                setAddressError("");
              }
            }
          )
        ] }),
        addressError && /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { role: "alert", className: "tz-error", children: addressError }),
        /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(
          ZoneField,
          {
            autoFocus: false,
            label: t("zone.label"),
            onCancel: () => {
              setAdding(false);
              setAddress("");
            },
            onSubmit: async (zone) => {
              const a = normaliseAddress(address);
              if (!a) {
                setAddressError(t("settings.invalidAddress"));
                return;
              }
              await save(a, zone);
              setAdding(false);
              setAddress("");
            }
          }
        )
      ] })
    ] })
  ] });
}

// timezones/src/index.js
var slots = {
  "settings-section": { component: SettingsSection },
  "calendar-event-form": { component: EventZones }
};
var hooks = {
  /** Adds "Outside 08:00–20:00 for …" to the event form's warnings. */
  async onCheckEventConflicts(warnings, context) {
    const api = getApi();
    const list = Array.isArray(warnings) ? warnings : [];
    if (!api) return list;
    const settings = readSettings(api.plugin.settings);
    const info = eventZones(context?.event, settings, await loadAddressZones(api.storage));
    const warning = outsideHoursWarning(info, settings, api.i18n.t, api.i18n.getLocale());
    return warning ? [...list, warning] : list;
  }
};
function activate(api) {
  mirrorSettings(api);
}
var index_default = { slots, hooks, activate };
