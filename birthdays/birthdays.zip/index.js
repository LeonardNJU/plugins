var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// birthdays/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);

// birthdays/src/lib/dates.js
var DAY_MS = 864e5;
function isLeapYear(year) {
  return year % 4 === 0 && year % 100 !== 0 || year % 400 === 0;
}
function daysInMonth(month, year) {
  if (month === 2) return year === null || isLeapYear(year) ? 29 : 28;
  return [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1];
}
function valid(year, month, day) {
  if (!Number.isInteger(month) || month < 1 || month > 12) return null;
  if (!Number.isInteger(day) || day < 1 || day > daysInMonth(month, year)) return null;
  if (year !== null && (!Number.isInteger(year) || year < 1 || year > 9999)) return null;
  return { year, month, day };
}
function parseBirthdayDate(value) {
  if (typeof value === "string") {
    const s = value.trim();
    let m = /^--(\d{2})-?(\d{2})$/.exec(s);
    if (m) return valid(null, +m[1], +m[2]);
    m = /^(\d{4})-?(\d{2})-?(\d{2})(?:$|T)/.exec(s);
    if (m) return valid(+m[1], +m[2], +m[3]);
    return null;
  }
  if (!value || typeof value !== "object") return null;
  if (value["@type"] === "Timestamp") return parseBirthdayDate(String(value.utc ?? "").slice(0, 10));
  if (value.calendarScale && String(value.calendarScale).toLowerCase() !== "gregorian") return null;
  const year = value.year === void 0 || value.year === null ? null : value.year;
  return valid(year, value.month, value.day);
}
var pad = (n, len = 2) => String(n).padStart(len, "0");
function isoDate(year, month, day) {
  return `${pad(year, 4)}-${pad(month)}-${pad(day)}`;
}
function localToday(now = /* @__PURE__ */ new Date()) {
  return isoDate(now.getFullYear(), now.getMonth() + 1, now.getDate());
}
function toUtcMs(iso) {
  const [y, m, d] = iso.split("-").map(Number);
  return Date.UTC(y, m - 1, d);
}
function addDays(iso, days) {
  const date = new Date(toUtcMs(iso) + days * DAY_MS);
  return isoDate(date.getUTCFullYear(), date.getUTCMonth() + 1, date.getUTCDate());
}
function daysBetween(fromIso, toIso) {
  return Math.round((toUtcMs(toIso) - toUtcMs(fromIso)) / DAY_MS);
}
function occurrenceIn(birthday, year) {
  if (birthday.month === 2 && birthday.day === 29 && !isLeapYear(year)) return isoDate(year, 2, 28);
  return isoDate(year, birthday.month, birthday.day);
}
function nextOccurrence(birthday, today) {
  const year = Number(today.slice(0, 4));
  const thisYear = occurrenceIn(birthday, year);
  if (thisYear >= today) return { date: thisYear, year };
  return { date: occurrenceIn(birthday, year + 1), year: year + 1 };
}
function ageIn(birthday, year) {
  if (birthday.year === null || birthday.year === void 0) return null;
  const age = year - birthday.year;
  return age > 0 ? age : null;
}

// birthdays/src/lib/format.js
function safeLocale(locale) {
  try {
    return Intl.getCanonicalLocales(locale)[0] || "en";
  } catch {
    return "en";
  }
}
function capitalize(textValue, locale) {
  if (!textValue) return textValue;
  return textValue.charAt(0).toLocaleUpperCase(safeLocale(locale)) + textValue.slice(1);
}
function relativeDays(days, locale) {
  try {
    return new Intl.RelativeTimeFormat(safeLocale(locale), { numeric: "auto" }).format(days, "day");
  } catch {
    return `+${days}`;
  }
}
function monthDay(iso, locale) {
  const [y, m, d] = iso.split("-").map(Number);
  try {
    return new Intl.DateTimeFormat(safeLocale(locale), { month: "long", day: "numeric", timeZone: "UTC" }).format(new Date(Date.UTC(y, m - 1, d)));
  } catch {
    return iso.slice(5);
  }
}
function ageText(age, i18n) {
  const locale = safeLocale(i18n.getLocale ? i18n.getLocale() : "en");
  let rule = "other";
  try {
    rule = new Intl.PluralRules(locale).select(age);
  } catch {
  }
  const key = i18n.has(`age.${rule}`) ? `age.${rule}` : "age.other";
  return i18n.t(key, { age });
}
function shortMonthDay(iso, locale) {
  const [y, m, d] = iso.split("-").map(Number);
  try {
    return new Intl.DateTimeFormat(safeLocale(locale), { month: "short", day: "numeric", timeZone: "UTC" }).format(new Date(Date.UTC(y, m - 1, d)));
  } catch {
    return iso.slice(5);
  }
}
function shortWhen(entry, i18n) {
  const locale = i18n.getLocale ? i18n.getLocale() : "en";
  if (entry.daysUntil <= 1) return capitalize(relativeDays(entry.daysUntil, locale), locale);
  return shortMonthDay(entry.date, locale);
}
function whenLine(entry, i18n) {
  const locale = i18n.getLocale ? i18n.getLocale() : "en";
  const parts = [capitalize(relativeDays(entry.daysUntil, locale), locale), monthDay(entry.date, locale)];
  if (entry.age) parts.push(ageText(entry.age, i18n));
  return parts.join(" · ");
}
function errorText(err, i18n) {
  const message = String(err?.message ?? err ?? "").toLowerCase();
  if (message.includes("permission") || message.includes("not granted") || message.includes("forbidden")) {
    return i18n.t("error.permission");
  }
  if (message.includes("timed out") || message.includes("timeout")) return i18n.t("error.timeout");
  if (message.includes("no active session") || message.includes("unauthor") || message.includes("401")) {
    return i18n.t("error.session");
  }
  if (message.includes("a minute")) return i18n.t("error.rate");
  return i18n.t("error.generic");
}

// birthdays/src/lib/calendar-sync.js
var LOOK_BACK_DAYS = 365;
var LOOK_AHEAD_DAYS = 366;
var SLICE_DAYS = 61;
var MARKER_RE = /\[birthdays:([^\]\s]+)\]/;
function markerFor(key) {
  return `[birthdays:${encodeURIComponent(key)}]`;
}
function keyFromDescription(description) {
  const m = MARKER_RE.exec(String(description ?? ""));
  if (!m) return null;
  try {
    return decodeURIComponent(m[1]);
  } catch {
    return null;
  }
}
function eventTitle(birthday, i18n) {
  return i18n.t("event.title", { name: birthday.name }).slice(0, 500);
}
function eventDescription(birthday, i18n) {
  return `${i18n.t("event.description")}

${markerFor(birthday.key)}`;
}
function planSync({ birthdays, events, today, enabled, i18n }) {
  const plan = { create: [], update: [], remove: [] };
  const wanted = new Map(enabled ? birthdays.map((b) => [b.key, b]) : []);
  const byKey = /* @__PURE__ */ new Map();
  for (const e of events) {
    if (!byKey.has(e.key)) byKey.set(e.key, []);
    byKey.get(e.key).push(e);
  }
  for (const [key, list] of byKey) {
    const b = wanted.get(key);
    if (!b) {
      plan.remove.push(...list.map((e) => e.id));
      continue;
    }
    const sorted = [...list].sort((x, y) => x.date < y.date ? -1 : x.date > y.date ? 1 : x.id < y.id ? -1 : 1);
    const seenPast = /* @__PURE__ */ new Set();
    for (const e of sorted.filter((x) => x.date < today)) {
      const right = e.date === occurrenceIn(b, Number(e.date.slice(0, 4)));
      if (!right || seenPast.has(e.date)) plan.remove.push(e.id);
      else seenPast.add(e.date);
    }
    const next = nextOccurrence(b, today).date;
    const upcoming = sorted.filter((x) => x.date >= today);
    const keep = upcoming.find((x) => x.date === next) ?? upcoming[0];
    if (keep) {
      const title = eventTitle(b, i18n);
      const description = eventDescription(b, i18n);
      const patch = {};
      if (keep.date !== next) Object.assign(patch, { start: next, isAllDay: true });
      if (keep.title !== title) patch.title = title;
      if (keep.description !== description) patch.description = description;
      if (Object.keys(patch).length) plan.update.push({ id: keep.id, key, patch });
      plan.remove.push(...upcoming.filter((x) => x !== keep).map((x) => x.id));
    } else {
      plan.create.push(newEvent(b, next, i18n));
    }
    wanted.delete(key);
  }
  for (const b of wanted.values()) plan.create.push(newEvent(b, nextOccurrence(b, today).date, i18n));
  return plan;
}
function newEvent(b, date, i18n) {
  return {
    key: b.key,
    event: { title: eventTitle(b, i18n), description: eventDescription(b, i18n), start: date, isAllDay: true }
  };
}
async function loadManagedEvents(api2, today) {
  const found = /* @__PURE__ */ new Map();
  for (let from = -LOOK_BACK_DAYS; from < LOOK_AHEAD_DAYS; from += SLICE_DAYS) {
    const to = Math.min(from + SLICE_DAYS, LOOK_AHEAD_DAYS);
    const events = await api2.calendar.getEvents({ from: addDays(today, from), to: addDays(today, to) });
    if (events.length >= 1e3) api2.log.warn("more than 1000 events in a slice; some birthdays may be missed");
    for (const e of events) {
      const key = keyFromDescription(e.description);
      if (key === null || e.isRecurring) continue;
      found.set(e.id, { id: e.id, key, date: String(e.start).slice(0, 10), title: e.title, description: e.description });
    }
  }
  return [...found.values()];
}
function calendarErrorText(err, i18n) {
  const message = String(err?.message ?? err ?? "").toLowerCase();
  if (/forbidden|read-?only|maywrite|not allowed/.test(message)) return i18n.t("error.readOnly");
  if (/quota|507|storage is full/.test(message)) return i18n.t("error.quota");
  return errorText(err, i18n);
}
async function syncCalendar(api2, { birthdays, today, enabled, beat = null }) {
  const events = await loadManagedEvents(api2, today);
  const plan = planSync({ birthdays, events, today, enabled, i18n: api2.i18n });
  const result = { created: 0, updated: 0, removed: 0, failed: 0, error: null };
  const attempt = async (fn, field) => {
    try {
      if (beat) await beat();
      const ok = await fn();
      if (ok === null) throw new Error("the calendar refused the change");
      result[field] += 1;
    } catch (err) {
      result.failed += 1;
      result.error ?? (result.error = err);
      api2.log.warn("calendar change failed", err);
    }
  };
  for (const id of plan.remove) await attempt(() => api2.calendar.deleteEvent(id), "removed");
  for (const { id, patch } of plan.update) await attempt(() => api2.calendar.updateEvent(id, patch), "updated");
  for (const { event } of plan.create) await attempt(() => api2.calendar.createEvent(event), "created");
  return result;
}

// birthdays/src/lib/contacts.js
var BIRTH_KINDS = /* @__PURE__ */ new Set(["birth", "birthday", "bday"]);
function text(value) {
  return typeof value === "string" ? value.trim() : "";
}
function contactName(card) {
  if (!card || typeof card !== "object") return "";
  const name = card.name;
  if (typeof name === "string" && name.trim()) return name.trim();
  if (name && typeof name === "object") {
    if (text(name.full)) return text(name.full);
    const parts = Array.isArray(name.components) ? name.components : Object.values(name.components ?? {});
    const given = parts.filter((p) => p?.kind === "given").map((p) => text(p.value)).filter(Boolean);
    const surname = parts.filter((p) => p?.kind === "surname").map((p) => text(p.value)).filter(Boolean);
    const joined = [...given, ...surname].join(" ");
    if (joined) return joined;
  }
  if (text(card.fullName)) return text(card.fullName);
  const viewName = [text(card.firstName), text(card.lastName)].filter(Boolean).join(" ");
  if (viewName) return viewName;
  const nick = Object.values(card.nicknames ?? {}).map((n) => text(n?.name)).find(Boolean);
  if (nick) return nick;
  return primaryEmail(card) ?? "";
}
function contactFirstName(card) {
  const parts = card?.name && typeof card.name === "object" ? Array.isArray(card.name.components) ? card.name.components : Object.values(card.name.components ?? {}) : [];
  const given = parts.find((p) => p?.kind === "given" && text(p.value));
  if (given) return text(given.value);
  if (text(card?.firstName)) return text(card.firstName);
  const full = contactName(card);
  if (full.includes("@")) return "";
  return full.split(/\s+/)[0] ?? "";
}
function primaryEmail(card) {
  if (!card) return null;
  if (Array.isArray(card.emails)) {
    const first = card.emails.map((e) => typeof e === "string" ? e : e?.address).find((a) => text(a).includes("@"));
    return first ? text(first) : null;
  }
  const entries = Object.values(card.emails ?? {}).filter((e) => text(e?.address).includes("@"));
  if (!entries.length) return null;
  entries.sort((a, b) => (a.pref ?? 101) - (b.pref ?? 101));
  return text(entries[0].address);
}
function birthEntries(card) {
  const list = Array.isArray(card.anniversaries) ? card.anniversaries : Object.values(card.anniversaries ?? {});
  return list.filter((a) => a && BIRTH_KINDS.has(String(a.kind ?? "").toLowerCase()));
}
function birthdaysFromContacts(cards) {
  const out = [];
  const seen = /* @__PURE__ */ new Set();
  for (const card of Array.isArray(cards) ? cards : []) {
    if (!card || typeof card.id !== "string" || !card.id || seen.has(card.id)) continue;
    if (card.kind === "group" || card.kind === "org") continue;
    let date = null;
    for (const entry of birthEntries(card)) {
      date = parseBirthdayDate(entry.date);
      if (date) break;
    }
    if (!date) continue;
    seen.add(card.id);
    out.push({
      key: card.id,
      contactId: card.id,
      name: contactName(card),
      firstName: contactFirstName(card),
      email: primaryEmail(card),
      ...date
    });
  }
  return out;
}
function upcomingBirthdays(birthdays, today, withinDays) {
  const out = [];
  for (const b of birthdays) {
    const next = nextOccurrence(b, today);
    const daysUntil = daysBetween(today, next.date);
    if (daysUntil > withinDays) continue;
    out.push({ ...b, date: next.date, daysUntil, age: ageIn(b, next.year) });
  }
  out.sort((a, b) => a.daysUntil - b.daysUntil || a.name.localeCompare(b.name));
  return out;
}

// birthdays/src/lib/greeting.js
function recipient(name, email) {
  const clean = String(name ?? "").replace(/["<>\r\n]/g, "").trim();
  return clean && !clean.includes("@") ? `"${clean}" <${email}>` : email;
}
function greetingFor(birthday, i18n) {
  if (!birthday?.email) return null;
  const first = birthday.firstName || "";
  return {
    to: [recipient(birthday.name, birthday.email)],
    subject: first ? i18n.t("greeting.subject", { name: first }) : i18n.t("greeting.subjectNoName"),
    body: first ? i18n.t("greeting.body", { name: first }) : i18n.t("greeting.bodyNoName")
  };
}
async function sendGreeting(api2, birthday) {
  const message = greetingFor(birthday, api2.i18n);
  if (!message) return false;
  try {
    await api2.compose.open(message);
    return true;
  } catch (err) {
    api2.log.warn("could not open the composer", err);
    api2.toast.error(errorText(err, api2.i18n));
    return false;
  }
}

// birthdays/src/lib/reminders.js
var MAX_SEPARATE = 3;
function dueReminders(birthdays, today, settings, sent = {}) {
  if (!settings.notify) return [];
  const due = [];
  for (const b of birthdays) {
    const next = nextOccurrence(b, today);
    const daysUntil = daysBetween(today, next.date);
    const record = sent[b.key] ?? {};
    if (record.last === today) continue;
    let kind = null;
    if (daysUntil === 0 && record.today !== next.date) kind = "today";
    else if (daysUntil > 0 && daysUntil <= settings.daysBefore && record.soon !== next.date) kind = "soon";
    if (kind) due.push({ ...b, date: next.date, daysUntil, age: ageIn(b, next.year), kind });
  }
  due.sort((a, b) => a.daysUntil - b.daysUntil || a.name.localeCompare(b.name));
  return due;
}
function markSent(sent, reminders, today, birthdays) {
  const keep = new Set(birthdays.map((b) => b.key));
  const next = {};
  for (const [key, record] of Object.entries(sent ?? {})) {
    if (!keep.has(key)) continue;
    const latest = [record.today, record.soon, record.last].filter(Boolean).sort().at(-1);
    if (latest && daysBetween(latest, today) > 40) continue;
    next[key] = { ...record };
  }
  for (const r of reminders) {
    next[r.key] = { ...next[r.key] ?? {}, last: today, [r.kind]: r.date };
  }
  return next;
}
function tagFor(key) {
  return `bday:${String(key).replace(/[^A-Za-z0-9._-]/g, "_")}`.slice(0, 64);
}
function birthdayForTag(birthdays, tag) {
  if (typeof tag !== "string" || !tag.startsWith("bday:")) return null;
  return birthdays.find((b) => tagFor(b.key) === tag) ?? null;
}
function bodyFor(reminder, i18n) {
  const locale = i18n.getLocale ? i18n.getLocale() : "en";
  const parts = [monthDay(reminder.date, locale)];
  if (reminder.age) parts.push(ageText(reminder.age, i18n));
  return parts.join(" · ");
}
function notificationsFor(reminders, i18n) {
  const locale = i18n.getLocale ? i18n.getLocale() : "en";
  if (reminders.length > MAX_SEPARATE) {
    const today = reminders.filter((r) => r.kind === "today");
    const soon = reminders.filter((r) => r.kind === "soon");
    const out = [];
    if (today.length) {
      out.push({ title: i18n.t("notify.manyToday", { names: today.map((r) => r.name).join(", ") }), tag: "bday-today" });
    }
    if (soon.length) {
      out.push({ title: i18n.t("notify.manySoon", { names: soon.map((r) => r.name).join(", ") }), tag: "bday-soon" });
    }
    return out.map((n) => ({ ...n, title: n.title.length > 120 ? `${n.title.slice(0, 119)}…` : n.title }));
  }
  return reminders.map((r) => {
    const title = r.kind === "today" ? i18n.t("notify.today", { name: r.name }) : i18n.t("notify.soon", { name: r.name, when: relativeDays(r.daysUntil, locale) });
    return {
      title: title.length > 120 ? `${title.slice(0, 119)}…` : title,
      body: bodyFor(r, i18n),
      tag: tagFor(r.key)
    };
  });
}

// birthdays/src/lib/settings.js
var DEFAULTS = Object.freeze({
  widgetDays: 30,
  notify: true,
  daysBefore: 3,
  addToCalendar: false
});
function clampInt(value, min, max, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.round(n)));
}
function readSettings(settings = {}) {
  return {
    widgetDays: clampInt(settings.widgetDays, 1, 365, DEFAULTS.widgetDays),
    notify: settings.notify === void 0 ? DEFAULTS.notify : settings.notify !== false,
    daysBefore: clampInt(settings.daysBefore, 0, 30, DEFAULTS.daysBefore),
    addToCalendar: settings.addToCalendar === true
  };
}

// birthdays/src/lib/background.js
var SENT_KEY = "sent";
var RECHECK_MS = 60 * 60 * 1e3;
var CHANGE_DELAY_MS = 3e3;
var CALENDAR_KEY = "calendarEvents";
var LOCK_KEY = "calendarLock";
var LOCK_MS = 30 * 1e3;
function createBackground(api2, { now = () => /* @__PURE__ */ new Date() } = {}) {
  let birthdays = [];
  let lastDay = null;
  let lastRunAt = 0;
  let running = null;
  let again = false;
  let timer = null;
  let calendarErrorShown = false;
  let lockRetry = null;
  async function remind(today) {
    const settings = readSettings(api2.plugin.settings);
    const sent = await api2.storage.get(SENT_KEY) ?? {};
    const due = dueReminders(birthdays, today, settings, sent);
    await api2.storage.set(SENT_KEY, markSent(sent, due, today, birthdays));
    for (const notification of notificationsFor(due, api2.i18n)) {
      try {
        await api2.notifications.show(notification);
      } catch (err) {
        api2.log.warn("could not show a reminder", err);
      }
    }
  }
  async function calendar(today) {
    const { addToCalendar } = readSettings(api2.plugin.settings);
    const hasEvents = await api2.storage.get(CALENDAR_KEY) === true;
    if (!addToCalendar && !hasEvents) return;
    const lockedUntil = Number(await api2.storage.get(LOCK_KEY)) || 0;
    if (lockedUntil > now().getTime()) {
      clearTimeout(lockRetry);
      lockRetry = setTimeout(() => {
        void run();
      }, lockedUntil - now().getTime() + 1e3);
      return;
    }
    const beat = () => api2.storage.set(LOCK_KEY, now().getTime() + LOCK_MS);
    await beat();
    let failure = null;
    try {
      if (addToCalendar) await api2.storage.set(CALENDAR_KEY, true);
      const result = await syncCalendar(api2, { birthdays, today, enabled: addToCalendar, beat });
      failure = result.error;
      if (!failure && !addToCalendar) await api2.storage.remove(CALENDAR_KEY);
    } catch (err) {
      failure = err;
    } finally {
      await api2.storage.remove(LOCK_KEY);
    }
    if (failure) {
      api2.log.warn("calendar sync failed", failure);
      if (!calendarErrorShown) {
        calendarErrorShown = true;
        api2.toast.error(api2.i18n.t("calendar.error", { reason: calendarErrorText(failure, api2.i18n) }));
      }
    } else {
      calendarErrorShown = false;
    }
  }
  async function check() {
    const today = localToday(now());
    try {
      birthdays = birthdaysFromContacts(await api2.contacts.list());
    } catch (err) {
      api2.log.warn("could not read the contacts", err);
      return;
    }
    lastDay = today;
    lastRunAt = now().getTime();
    await remind(today);
    await calendar(today);
  }
  async function run() {
    if (running) {
      again = true;
      return running;
    }
    running = (async () => {
      do {
        again = false;
        try {
          await check();
        } catch (err) {
          api2.log.error("birthday check failed", err);
        }
      } while (again);
    })();
    try {
      await running;
    } finally {
      running = null;
    }
  }
  function runSoon() {
    clearTimeout(timer);
    timer = setTimeout(() => {
      void run();
    }, CHANGE_DELAY_MS);
  }
  const hooks2 = {
    onAppReady: () => run(),
    onInterval: () => {
      const stale = localToday(now()) !== lastDay || now().getTime() - lastRunAt >= RECHECK_MS;
      return stale ? run() : void 0;
    },
    onAfterContactCreate: runSoon,
    onAfterContactUpdate: runSoon,
    onAfterContactDelete: runSoon,
    onContactsImport: runSoon,
    // A click on a reminder for one contact opens a greeting to them.
    onNotificationClick: async ({ tag } = {}) => {
      if (typeof tag !== "string" || !tag.startsWith("bday:")) return;
      if (!birthdays.length) await run();
      const birthday = birthdayForTag(birthdays, tag);
      if (birthday && greetingFor(birthday, api2.i18n)) await sendGreeting(api2, birthday);
    }
  };
  function showSectionTitle() {
    try {
      const done = api2.ui.setSectionTitle(api2.i18n.t("widget.title").slice(0, 40));
      if (done && typeof done.catch === "function") done.catch((err) => api2.log.warn("could not set the section title", err));
    } catch (err) {
      api2.log.warn("could not set the section title", err);
    }
  }
  return {
    hooks: hooks2,
    activate() {
      showSectionTitle();
      api2.i18n.onLocaleChange(() => {
        showSectionTitle();
      });
      let addToCalendar = readSettings(api2.plugin.settings).addToCalendar;
      api2.plugin.onSettingsChange((settings) => {
        const next = readSettings(settings).addToCalendar;
        if (next === addToCalendar) return;
        addToCalendar = next;
        void run();
      });
      void run();
    },
    run,
    get birthdays() {
      return birthdays;
    }
  };
}

// birthdays/src/lib/widget.js
var import_ui = require("@plugin-host/ui");
var COLLAPSED_ROWS = 5;
var REFRESH_MS = 10 * 60 * 1e3;
function makeWidget(React2, api2, { now = () => /* @__PURE__ */ new Date(), onGreet = null } = {}) {
  const { createElement: h, useCallback, useEffect, useState } = React2;
  const t = (key, vars) => api2.i18n.t(key, vars);
  return function BirthdayWidget2() {
    const [state, setState] = useState({ status: "loading", birthdays: [], error: "" });
    const [expanded, setExpanded] = useState(false);
    const load = useCallback(async () => {
      try {
        const cards = await api2.contacts.list();
        setState({ status: "ready", birthdays: birthdaysFromContacts(cards), error: "" });
      } catch (err) {
        api2.log.warn("could not load contacts", err);
        setState((prev) => ({ ...prev, status: "error", error: errorText(err, api2.i18n) }));
      }
    }, []);
    useEffect(() => {
      void load();
      const timer = setInterval(() => {
        void load();
      }, REFRESH_MS);
      const onVisible = () => {
        if (document.visibilityState === "visible") void load();
      };
      document.addEventListener("visibilitychange", onVisible);
      return () => {
        clearInterval(timer);
        document.removeEventListener("visibilitychange", onVisible);
      };
    }, [load]);
    if (state.status === "loading") {
      return h("div", { role: "status" }, h(import_ui.SidebarEmpty, null, t("widget.loading")));
    }
    if (state.status === "error") {
      return h(
        "div",
        null,
        h("div", { role: "alert" }, h(import_ui.SidebarEmpty, null, state.error)),
        h(import_ui.SidebarRow, { icon: "refresh", label: t("widget.retry"), onClick: () => {
          void load();
        } })
      );
    }
    const { widgetDays } = readSettings(api2.plugin.settings);
    const items = upcomingBirthdays(state.birthdays, localToday(now()), widgetDays);
    if (items.length === 0) return h(import_ui.SidebarEmpty, null, t("widget.empty", { days: widgetDays }));
    const shown = expanded ? items : items.slice(0, COLLAPSED_ROWS);
    return h(
      "div",
      null,
      h("div", { role: "list", "aria-label": t("widget.title") }, shown.map((item) => {
        const greet = onGreet && item.email ? () => {
          void onGreet(item);
        } : void 0;
        const title = [`${item.name}: ${whenLine(item, api2.i18n)}`, greet ? t("greet.label", { name: item.name }) : null].filter(Boolean).join("\n");
        return h(
          "div",
          { key: item.key, role: "listitem", "data-birthday": item.key },
          h(import_ui.SidebarRow, {
            icon: "cake",
            label: item.name,
            detail: shortWhen(item, api2.i18n),
            title,
            onClick: greet,
            // Screen readers hear what the click does, not only the name.
            ...greet ? { ariaLabel: `${t("greet.label", { name: item.name })} (${whenLine(item, api2.i18n)})` } : {}
          })
        );
      })),
      items.length > COLLAPSED_ROWS ? h(import_ui.SidebarRow, {
        icon: "dots",
        label: expanded ? t("widget.showFewer") : t("widget.showAll", { count: items.length }),
        onClick: () => setExpanded((v) => !v)
      }) : null
    );
  };
}

// birthdays/src/index.js
var React = require("react");
var api = require("@plugin-host");
var background = createBackground(api);
var BirthdayWidget = makeWidget(React, api, { onGreet: (birthday) => sendGreeting(api, birthday) });
var hooks = background.hooks;
function activate() {
  background.activate();
}
var slots = {
  "sidebar-section": {
    component: BirthdayWidget,
    order: 50
  }
};
