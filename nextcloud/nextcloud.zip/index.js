var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// nextcloud/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  addLinksToMessage: () => addLinksToMessage,
  hooks: () => hooks,
  offerFirstRun: () => offerFirstRun,
  offerLargeUpload: () => offerLargeUpload,
  onAction: () => onAction,
  registerActions: () => registerActions,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);

// nextcloud/src/lib/host.js
var hostApi = null;
function getApi() {
  if (!hostApi && typeof require === "function") {
    hostApi = require("@plugin-host");
  }
  return hostApi;
}
function setApi(api) {
  hostApi = api;
}

// nextcloud/src/lib/errors.js
var NcError = class extends Error {
  /**
   * @param {string} code one of ERROR_CODES
   * @param {{ status?: number, detail?: string }} [info]
   */
  constructor(code, info = {}) {
    super(info.detail ? `${code}: ${info.detail}` : code);
    this.name = "NcError";
    this.code = code;
    this.status = info.status ?? 0;
    this.detail = info.detail ?? "";
  }
};
var ERROR_CODES = [
  "not_connected",
  "auth",
  "forbidden",
  "share_forbidden",
  "not_found",
  "exists",
  "quota",
  "too_large",
  "locked",
  "rate_limited",
  "timeout",
  "unreachable",
  "blocked",
  "maintenance",
  "server",
  "cancelled",
  "wrong_server",
  "login_expired",
  "bad_answer",
  "rejected",
  "attach_refused",
  "unknown"
];
var PROXY_CODES = {
  no_credential: "not_connected",
  rate_limited: "rate_limited",
  timeout: "timeout",
  unreachable: "unreachable",
  blocked_address: "blocked",
  wrong_origin: "blocked",
  redirect_off_origin: "blocked",
  too_large: "too_large"
};
function ocsMessage(body) {
  let data = body;
  if (typeof data === "string") {
    try {
      data = JSON.parse(data);
    } catch {
      return "";
    }
  }
  const message = data?.ocs?.meta?.message;
  return typeof message === "string" && message !== "OK" ? message : "";
}
function davMessage(body) {
  if (typeof body !== "string") return "";
  const m = /<(?:[\w.-]+:)?message>([^<]{1,300})<\//.exec(body);
  return m ? m[1].trim() : "";
}
function errorFromResponse(res, { kind } = {}) {
  if (!res || typeof res !== "object") return new NcError("unknown");
  if (res.proxyError) {
    return new NcError(PROXY_CODES[res.proxyError] ?? "unknown", { status: res.status, detail: typeof res.body === "string" ? res.body : "" });
  }
  if (res.ok) return null;
  const status = Number(res.status) || 0;
  const detail = ocsMessage(res.body) || davMessage(res.body);
  const info = { status, detail };
  if (status === 400 && detail) return new NcError("rejected", info);
  if (status === 401) return new NcError("auth", info);
  if (status === 403) return new NcError(kind === "share" ? "share_forbidden" : "forbidden", info);
  if (status === 404) return new NcError("not_found", info);
  if (status === 405 || status === 412) return new NcError("exists", info);
  if (status === 413) return new NcError("too_large", info);
  if (status === 423) return new NcError("locked", info);
  if (status === 429) return new NcError("rate_limited", info);
  if (status === 503) return new NcError("maintenance", info);
  if (status === 507) return new NcError("quota", info);
  if (status === 504 || status === 408) return new NcError("timeout", info);
  if (status >= 500) return new NcError("server", info);
  return new NcError("unknown", info);
}
function errorFromException(err, signal) {
  if (err instanceof NcError) return err;
  if (signal?.aborted) return new NcError("cancelled");
  const message = String(err?.message ?? err ?? "");
  if (/cancel|abort/i.test(message)) return new NcError("cancelled");
  if (/timed out/i.test(message)) return new NcError("timeout");
  if (/larger than/i.test(message)) return new NcError("too_large");
  if (/at most \d+ proxy requests/i.test(message)) return new NcError("rate_limited");
  if (/network/i.test(message)) return new NcError("unreachable");
  return new NcError("unknown", { detail: message.slice(0, 200) });
}
function needsSignIn(err) {
  return err instanceof NcError && (err.code === "auth" || err.code === "not_connected" || err.code === "wrong_server");
}
function errorText(t, err) {
  const e = err instanceof NcError ? err : errorFromException(err);
  const text = t(`error.${ERROR_CODES.includes(e.code) ? e.code : "unknown"}`);
  const withDetail = ["forbidden", "share_forbidden", "rejected", "unknown", "bad_answer"].includes(e.code) && e.detail;
  return withDetail ? `${text} (${e.detail})` : text;
}

// nextcloud/src/lib/paths.js
function normalizePath(path) {
  const out = [];
  for (const part of String(path ?? "").split("/")) {
    if (!part || part === ".") continue;
    if (part === "..") {
      out.pop();
      continue;
    }
    out.push(part);
  }
  return "/" + out.join("/");
}
function joinPath(...parts) {
  return normalizePath(parts.map((p) => String(p ?? "")).join("/"));
}
function parentPath(path) {
  const p = normalizePath(path);
  if (p === "/") return "/";
  return p.slice(0, p.lastIndexOf("/")) || "/";
}
function baseName(path) {
  const p = normalizePath(path);
  return p === "/" ? "" : p.slice(p.lastIndexOf("/") + 1);
}
function breadcrumb(path) {
  const p = normalizePath(path);
  const crumbs = [{ name: "", path: "/" }];
  if (p === "/") return crumbs;
  let acc = "";
  for (const part of p.slice(1).split("/")) {
    acc += "/" + part;
    crumbs.push({ name: part, path: acc });
  }
  return crumbs;
}
function encodePath(path) {
  return normalizePath(path).split("/").map((s) => encodeURIComponent(s)).join("/");
}
function davFilesUrl(origin, userId, path) {
  const p = normalizePath(path);
  return `${origin}/remote.php/dav/files/${encodeURIComponent(userId)}${p === "/" ? "/" : encodePath(p)}`;
}
function davUploadsUrl(origin, userId, uploadId, chunk) {
  const base = `${origin}/remote.php/dav/uploads/${encodeURIComponent(userId)}/${encodeURIComponent(uploadId)}`;
  return chunk === void 0 ? base : `${base}/${encodeURIComponent(chunk)}`;
}
function hrefToPath(href, userId) {
  let pathname = String(href ?? "");
  try {
    pathname = new URL(pathname, "http://x").pathname;
  } catch {
    return null;
  }
  const marker = `/remote.php/dav/files/${encodeURIComponent(userId)}`;
  let i = pathname.indexOf(marker);
  let rest;
  if (i >= 0) rest = pathname.slice(i + marker.length);
  else {
    const plain = `/remote.php/dav/files/${userId}`;
    i = pathname.indexOf(plain);
    if (i < 0) return null;
    rest = pathname.slice(i + plain.length);
  }
  if (rest && !rest.startsWith("/")) return null;
  try {
    return normalizePath(rest.split("/").map((s) => decodeURIComponent(s)).join("/"));
  } catch {
    return null;
  }
}
function sanitizeFileName(name, fallback = "file") {
  const cleaned = String(name ?? "").replace(/[\u0000-\u001f\u007f]/g, "").replace(/[\\/]/g, "_").replace(/[:*?"<>|]/g, "_").trim().replace(/^\.+/, "").slice(0, 200).trim();
  return cleaned || fallback;
}
function uniqueName(name, taken) {
  const used = new Set([...taken ?? []].map((n) => String(n).toLowerCase()));
  if (!used.has(name.toLowerCase())) return name;
  const dot = name.lastIndexOf(".");
  const stem = dot > 0 ? name.slice(0, dot) : name;
  const ext = dot > 0 ? name.slice(dot) : "";
  for (let n = 2; n < 1e4; n++) {
    const candidate = `${stem} (${n})${ext}`;
    if (!used.has(candidate.toLowerCase())) return candidate;
  }
  return `${stem} (${Date.now()})${ext}`;
}
function uploadFolder(base, layout, date = /* @__PURE__ */ new Date()) {
  const root = normalizePath(base || "Mail attachments");
  if (layout !== "date") return root;
  const day = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  return joinPath(root, day);
}
function originOf(value) {
  const raw = String(value ?? "").trim();
  if (!raw) return null;
  const withScheme = /^[a-z][a-z0-9+.-]*:\/\//i.test(raw) ? raw : `https://${raw}`;
  try {
    const url = new URL(withScheme);
    if (url.protocol !== "https:" && url.protocol !== "http:") return null;
    return url.origin;
  } catch {
    return null;
  }
}

// nextcloud/src/lib/webdav.js
var PROPS = `<d:prop>
  <d:displayname/><d:getcontentlength/><d:getcontenttype/><d:getlastmodified/><d:resourcetype/><d:getetag/>
  <oc:fileid/><oc:size/><oc:permissions/>
</d:prop>`;
var NS = 'xmlns:d="DAV:" xmlns:oc="http://owncloud.org/ns" xmlns:nc="http://nextcloud.org/ns"';
var PROPFIND_BODY = `<?xml version="1.0" encoding="UTF-8"?>
<d:propfind ${NS}>${PROPS}</d:propfind>`;
function xmlEscape(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function likePattern(text) {
  return `%${String(text).replace(/[\\%_]/g, (c) => `\\${c}`)}%`;
}
function searchBody({ userId, query = "", recent = false, limit = 50 }) {
  const where = recent ? "<d:not><d:is-collection/></d:not>" : `<d:like><d:prop><d:displayname/></d:prop><d:literal>${xmlEscape(likePattern(query))}</d:literal></d:like>`;
  return `<?xml version="1.0" encoding="UTF-8"?>
<d:searchrequest ${NS}>
<d:basicsearch>
<d:select>${PROPS}</d:select>
<d:from><d:scope><d:href>/files/${xmlEscape(userId)}</d:href><d:depth>infinity</d:depth></d:scope></d:from>
<d:where>${where}</d:where>
<d:orderby><d:order><d:prop><d:getlastmodified/></d:prop><d:descending/></d:order></d:orderby>
<d:limit><d:nresults>${Math.max(1, Math.min(200, Number(limit) || 50))}</d:nresults></d:limit>
</d:basicsearch>
</d:searchrequest>`;
}
var ENTITIES = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'" };
function decodeXml(s) {
  return String(s).replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1").replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e) => {
    if (e[0] === "#") {
      const code = e[1] === "x" || e[1] === "X" ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      return Number.isFinite(code) ? String.fromCodePoint(code) : m;
    }
    return ENTITIES[e.toLowerCase()] ?? m;
  });
}
function blocks(xml, local) {
  const re = new RegExp(`<([A-Za-z][\\w.-]*:)?${local}\\b[^>]*>([\\s\\S]*?)</\\1${local}>`, "g");
  const out = [];
  let m;
  while (m = re.exec(xml)) out.push(m[2]);
  return out;
}
function first(xml, local) {
  return blocks(xml, local)[0];
}
function parseProps(xml) {
  const props = {};
  const re = /<(?:[A-Za-z][\w.-]*:)?([A-Za-z][\w.-]*)\b[^>]*?(?:\/>|>([\s\S]*?)<\/(?:[A-Za-z][\w.-]*:)?\1>)/g;
  let m;
  while (m = re.exec(xml)) {
    const [, name, inner] = m;
    props[name] = inner === void 0 ? "" : inner;
  }
  return props;
}
function parseMultistatus(xml) {
  const out = [];
  for (const response of blocks(String(xml ?? ""), "response")) {
    const href = decodeXml((first(response, "href") ?? "").trim());
    const props = {};
    for (const propstat of blocks(response, "propstat")) {
      const status = first(propstat, "status") ?? "";
      if (!/\s2\d\d\b/.test(status)) continue;
      const prop = first(propstat, "prop");
      if (prop !== void 0) Object.assign(props, parseProps(prop));
    }
    out.push({ href, props });
  }
  return out;
}
function toEntry({ href, props }, userId) {
  const path = hrefToPath(href, userId);
  if (path === null) return null;
  const isFolder = /<(?:[\w.-]+:)?collection\b/.test(props.resourcetype ?? "");
  const sizeRaw = props.size ?? props.getcontentlength;
  const size = Number(sizeRaw);
  const modified = Date.parse(decodeXml(props.getlastmodified ?? ""));
  const displayName = decodeXml(props.displayname ?? "").trim();
  return {
    path,
    name: baseName(path) || displayName || "",
    isFolder,
    size: Number.isFinite(size) && sizeRaw !== "" ? size : 0,
    type: isFolder ? "" : decodeXml(props.getcontenttype ?? "") || "application/octet-stream",
    modified: Number.isFinite(modified) ? modified : 0,
    fileId: props.fileid ? decodeXml(props.fileid) : "",
    permissions: props.permissions ? decodeXml(props.permissions) : "",
    etag: props.getetag ? decodeXml(props.getetag).replace(/"/g, "") : ""
  };
}
function sortEntries(entries, locale) {
  const collator = new Intl.Collator(locale || void 0, { numeric: true, sensitivity: "base" });
  return [...entries].sort((a, b) => a.isFolder === b.isFolder ? collator.compare(a.name, b.name) : a.isFolder ? -1 : 1);
}

// nextcloud/src/lib/client.js
var CREDENTIAL = "nextcloud";
var BUFFERED_LIMIT = 24 * 1024 * 1024;
var OCS_HEADERS = { "OCS-APIRequest": "true", Accept: "application/json" };
async function ncRequest(api, url, init = {}, { kind, accept = [] } = {}) {
  let res;
  try {
    res = await api.proxy.fetch(CREDENTIAL, url, init);
  } catch (err2) {
    throw errorFromException(err2, init.signal);
  }
  if (init.signal?.aborted) throw new NcError("cancelled");
  if (res && accept.includes(res.status) && !res.proxyError) return res;
  const err = errorFromResponse(res, { kind });
  if (err) throw err;
  return res;
}
function parseJson(body) {
  if (body && typeof body === "object") return body;
  try {
    return JSON.parse(String(body ?? ""));
  } catch {
    throw new NcError("bad_answer");
  }
}
async function ocs(api, origin, path, init = {}, opts = {}) {
  const sep = path.includes("?") ? "&" : "?";
  const res = await ncRequest(api, `${origin}${path}${sep}format=json`, {
    ...init,
    headers: { ...OCS_HEADERS, ...init.headers ?? {} },
    responseType: "text"
  }, opts);
  return parseJson(res.body)?.ocs?.data;
}
function createClient(api, conn) {
  const { origin, userId } = conn;
  const fileUrl = (path) => davFilesUrl(origin, userId, path);
  async function propfind(path, depth = 1) {
    const res = await ncRequest(api, fileUrl(path), {
      method: "PROPFIND",
      headers: { Depth: String(depth), "Content-Type": "application/xml; charset=utf-8" },
      body: PROPFIND_BODY,
      responseType: "text"
    });
    return parseMultistatus(res.body).map((r) => toEntry(r, userId)).filter(Boolean);
  }
  const client = {
    origin,
    userId,
    /** The files and folders in `path`, folders first. */
    async list(path, locale) {
      const self = normalizePath(path);
      const entries = await propfind(self, 1);
      return sortEntries(entries.filter((e) => e.path !== self), locale);
    },
    /** One file or folder, or null when there is none. */
    async stat(path) {
      try {
        const [entry] = await propfind(path, 0);
        return entry ?? null;
      } catch (err) {
        if (err instanceof NcError && err.code === "not_found") return null;
        throw err;
      }
    },
    async search(query, { limit = 50, signal } = {}) {
      const q = String(query ?? "").trim();
      if (!q) return [];
      return runSearch({ query: q, limit, signal });
    },
    async recent({ limit = 50, signal } = {}) {
      return runSearch({ recent: true, limit, signal });
    },
    /** Create a folder; an existing one is fine. */
    async mkdir(path) {
      await ncRequest(api, fileUrl(path), { method: "MKCOL" }, { accept: [405] });
    },
    /** Create a folder and its parents. */
    async mkdirp(path) {
      const p = normalizePath(path);
      if (p === "/") return;
      if (await client.stat(p)) return;
      await client.mkdirp(parentPath(p));
      await client.mkdir(p);
    },
    /** Names taken in a folder (for picking a free name). */
    async names(path) {
      try {
        return (await client.list(path)).map((e) => e.name);
      } catch (err) {
        if (err instanceof NcError && err.code === "not_found") return [];
        throw err;
      }
    },
    /** The bytes of a file. Large files come in as a stream. */
    async download(entry, { onProgress, signal } = {}) {
      const size = Number(entry.size) || 0;
      if (size <= BUFFERED_LIMIT) {
        const res2 = await ncRequest(api, fileUrl(entry.path), { method: "GET", responseType: "arraybuffer", signal });
        const bytes = new Uint8Array(res2.body);
        onProgress?.(bytes.byteLength, bytes.byteLength);
        return bytes;
      }
      const res = await ncRequest(api, fileUrl(entry.path), { method: "GET", responseType: "stream", signal });
      const reader = res.body.getReader();
      const parts = [];
      let loaded = 0;
      try {
        for (; ; ) {
          const { done, value } = await reader.read();
          if (done) break;
          parts.push(value);
          loaded += value.byteLength;
          onProgress?.(loaded, size);
        }
      } catch (err) {
        throw errorFromException(err, signal);
      }
      const out = new Uint8Array(loaded);
      let offset = 0;
      for (const p of parts) {
        out.set(p, offset);
        offset += p.byteLength;
      }
      return out;
    },
    /** Upload in one request (small files). */
    async put(path, body, { contentType, onProgress, signal } = {}) {
      await ncRequest(api, fileUrl(path), {
        method: "PUT",
        headers: { "Content-Type": contentType || "application/octet-stream" },
        body,
        onProgress,
        signal
      });
    },
    async remove(path) {
      await ncRequest(api, fileUrl(path), { method: "DELETE" });
    },
    /**
     * A public, read-only share link. `password` and `expireDate`
     * (YYYY-MM-DD) are optional.
     */
    async share(path, { password, expireDate } = {}) {
      const form = new URLSearchParams();
      form.set("path", normalizePath(path));
      form.set("shareType", "3");
      form.set("permissions", "1");
      if (password) form.set("password", password);
      if (expireDate) form.set("expireDate", expireDate);
      const data = await ocs(api, origin, "/ocs/v2.php/apps/files_sharing/api/v1/shares", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: form.toString()
      }, { kind: "share" });
      const url = data?.url;
      if (typeof url !== "string" || !/^https?:\/\//.test(url)) throw new NcError("bad_answer");
      return { id: String(data.id ?? ""), url, password: password || "", expireDate: expireDate || "", name: baseName(path) };
    },
    /** A password that meets the server's password rules. */
    async generatePassword() {
      try {
        const data = await ocs(api, origin, "/ocs/v2.php/apps/password_policy/api/v1/generate");
        if (typeof data?.password === "string" && data.password) return data.password;
      } catch {
      }
      return localPassword();
    },
    /** Where to open a file in the Nextcloud web interface. */
    webUrl(entry) {
      if (entry.fileId) return `${origin}/f/${encodeURIComponent(entry.fileId)}`;
      const dir = entry.isFolder ? entry.path : parentPath(entry.path);
      return `${origin}/apps/files/?dir=${encodeURIComponent(dir)}`;
    },
    joinPath
  };
  async function runSearch({ query, recent, limit, signal }) {
    const res = await ncRequest(api, `${origin}/remote.php/dav/`, {
      method: "SEARCH",
      headers: { "Content-Type": "text/xml; charset=utf-8" },
      body: searchBody({ userId, query, recent, limit }),
      responseType: "text",
      signal
    });
    return parseMultistatus(res.body).map((r) => toEntry(r, userId)).filter((e) => e && e.path !== "/");
  }
  return client;
}
var ALPHABETS = ["ABCDEFGHJKLMNPQRSTUVWXYZ", "abcdefghijkmnopqrstuvwxyz", "23456789", "-_+!#"];
function localPassword(random = defaultRandom) {
  const all = ALPHABETS.join("");
  const chars = ALPHABETS.map((set) => set[random(set.length)]);
  while (chars.length < 20) chars.push(all[random(all.length)]);
  for (let i = chars.length - 1; i > 0; i--) {
    const j = random(i + 1);
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  return chars.join("");
}
function defaultRandom(n) {
  const buf = new Uint32Array(1);
  globalThis.crypto.getRandomValues(buf);
  return buf[0] % n;
}

// nextcloud/src/lib/connection.js
var POLL_INTERVAL_MS = 2e3;
var POLL_TIMEOUT_MS = 20 * 60 * 1e3;
async function adminServer(api) {
  try {
    const config = await api.admin.getAllConfig();
    return originOf(config?.serverUrl) ?? null;
  } catch {
    return null;
  }
}
async function storedAccount(api) {
  let list;
  try {
    list = await api.proxy.accounts();
  } catch {
    return null;
  }
  const account = Array.isArray(list) ? list.find((a) => a.credentialId === CREDENTIAL) : null;
  return account ?? null;
}
function userKey(origin, username) {
  return `user:${origin}:${username ?? ""}`;
}
async function getConnection(api, { fixedServer } = {}) {
  const account = await storedAccount(api);
  if (!account || !account.connected) return null;
  const fixed = fixedServer === void 0 ? await adminServer(api) : fixedServer;
  if (fixed && account.origin !== fixed) throw new NcError("wrong_server");
  const key = userKey(account.origin, account.username);
  const cached = await api.storage.get(key);
  if (cached && typeof cached.userId === "string" && cached.userId) {
    return { origin: account.origin, username: account.username ?? "", userId: cached.userId, displayName: cached.displayName ?? "" };
  }
  const data = await ocs(api, account.origin, "/ocs/v2.php/cloud/user");
  const userId = typeof data?.id === "string" && data.id ? data.id : account.username;
  if (!userId) throw new NcError("bad_answer");
  const displayName = typeof data?.displayname === "string" ? data.displayname : data?.["display-name"] ?? "";
  await api.storage.set(key, { userId, displayName });
  return { origin: account.origin, username: account.username ?? "", userId, displayName };
}
async function approveServer(api, { fixedServer, suggestedServer } = {}) {
  const server = fixedServer || suggestedServer || void 0;
  const result = await api.proxy.connect(CREDENTIAL, { mode: "signin", ...server ? { server } : {} });
  const origin = result?.origin ? originOf(result.origin) : null;
  if (!origin) return null;
  if (fixedServer && origin !== fixedServer) {
    await api.proxy.disconnect(CREDENTIAL).catch(() => {
    });
    throw new NcError("wrong_server");
  }
  return origin;
}
async function startLoginFlow(api, origin) {
  const res = await ncRequest(api, `${origin}/index.php/login/v2`, { method: "POST", responseType: "text" });
  let data;
  try {
    data = JSON.parse(String(res.body));
  } catch {
    throw new NcError("bad_answer", { detail: "login/v2" });
  }
  const loginUrl = data?.login;
  const endpoint = data?.poll?.endpoint;
  const token = data?.poll?.token;
  if (typeof loginUrl !== "string" || typeof endpoint !== "string" || typeof token !== "string" || !token) {
    throw new NcError("bad_answer", { detail: "login/v2" });
  }
  if (originOf(loginUrl) === null) throw new NcError("bad_answer", { detail: "login url" });
  if (originOf(endpoint) !== origin) throw new NcError("blocked", { detail: endpoint });
  return { loginUrl, endpoint, token };
}
var sleepFor = (ms, signal) => new Promise((resolve, reject) => {
  const timer = setTimeout(resolve, ms);
  signal?.addEventListener("abort", () => {
    clearTimeout(timer);
    reject(new NcError("cancelled"));
  }, { once: true });
});
async function pollLoginFlow(api, { endpoint, token }, { signal, intervalMs = POLL_INTERVAL_MS, timeoutMs = POLL_TIMEOUT_MS, sleep = sleepFor, now = Date.now } = {}) {
  const started = now();
  for (; ; ) {
    if (signal?.aborted) throw new NcError("cancelled");
    const res = await ncRequest(api, endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: `token=${encodeURIComponent(token)}`,
      responseType: "json",
      capture: { secret: "appPassword", username: "loginName" },
      signal
    }, { accept: [404] });
    if (res.status === 200) {
      if (res.body?.captured) return true;
      throw new NcError("bad_answer", { detail: "no app password" });
    }
    if (now() - started > timeoutMs) throw new NcError("login_expired");
    await sleep(intervalMs, signal);
  }
}
async function disconnect(api) {
  const account = await storedAccount(api);
  if (account?.connected) {
    await ocs(api, account.origin, "/ocs/v2.php/core/apppassword", { method: "DELETE" }).catch(() => {
    });
  }
  if (account) await api.storage.remove(userKey(account.origin, account.username)).catch(() => {
  });
  await api.proxy.disconnect(CREDENTIAL);
}

// nextcloud/src/lib/chunked.js
var CHUNK_SIZE = 10 * 1024 * 1024;
var UPLOADS_KEY = "uploads";
var RETRYABLE = /* @__PURE__ */ new Set(["unreachable", "timeout", "server", "maintenance", "rate_limited"]);
function resumeKey(destPath, file) {
  return `${destPath}|${file.size}|${file.lastModified ?? 0}|${file.name ?? ""}`;
}
function newUploadId() {
  return `bulwark-${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36)}`;
}
function chunkName(index) {
  return String(index + 1).padStart(5, "0");
}
async function listChunks(api, conn, uploadId) {
  let res;
  try {
    res = await ncRequest(api, davUploadsUrl(conn.origin, conn.userId, uploadId), {
      method: "PROPFIND",
      headers: { Depth: "1", "Content-Type": "application/xml; charset=utf-8" },
      body: '<?xml version="1.0"?><d:propfind xmlns:d="DAV:"><d:prop><d:getcontentlength/><d:resourcetype/></d:prop></d:propfind>',
      responseType: "text"
    });
  } catch (err) {
    if (err instanceof NcError && err.code === "not_found") return null;
    throw err;
  }
  const chunks = /* @__PURE__ */ new Map();
  for (const { href, props } of parseMultistatus(res.body)) {
    const name = decodeURIComponent(href.replace(/\/+$/, "").split("/").pop() ?? "");
    if (!/^\d{1,5}$/.test(name)) continue;
    chunks.set(name.padStart(5, "0"), Number(decodeXml(props.getcontentlength ?? "0")) || 0);
  }
  return chunks;
}
async function withRetry(fn, { retries, signal, wait }) {
  for (let attempt = 0; ; attempt++) {
    try {
      return await fn();
    } catch (err) {
      if (signal?.aborted) throw new NcError("cancelled");
      if (!(err instanceof NcError) || !RETRYABLE.has(err.code) || attempt >= retries) throw err;
      await wait(1e3 * (attempt + 1));
    }
  }
}
async function uploadFile(api, conn, file, destPath, {
  onProgress,
  signal,
  chunkSize = CHUNK_SIZE,
  retries = 2,
  wait = (ms) => new Promise((r) => setTimeout(r, ms))
} = {}) {
  const size = file.size;
  const destUrl = davFilesUrl(conn.origin, conn.userId, destPath);
  if (size <= chunkSize) {
    await withRetry(() => ncRequest(api, destUrl, {
      method: "PUT",
      headers: { "Content-Type": file.type || "application/octet-stream" },
      body: file,
      onProgress,
      signal
    }), { retries, signal, wait });
    onProgress?.(size, size);
    return { path: destPath, chunked: false, resumed: false };
  }
  const key = resumeKey(destPath, file);
  const saved = await api.storage.get(UPLOADS_KEY) ?? {};
  let record = saved[key] ?? null;
  let have = /* @__PURE__ */ new Map();
  if (record) {
    const listed = await listChunks(api, conn, record.id);
    if (listed) have = listed;
    else record = null;
  }
  const resumed = !!record;
  if (!record) {
    record = { id: newUploadId(), startedAt: Date.now() };
    await ncRequest(api, davUploadsUrl(conn.origin, conn.userId, record.id), {
      method: "MKCOL",
      headers: { Destination: destUrl },
      signal
    });
    await api.storage.set(UPLOADS_KEY, { ...saved, [key]: record });
  }
  const count = Math.ceil(size / chunkSize);
  let sent = 0;
  for (let i = 0; i < count; i++) {
    const start = i * chunkSize;
    const end = Math.min(size, start + chunkSize);
    if (have.get(chunkName(i)) === end - start) sent += end - start;
  }
  onProgress?.(sent, size);
  for (let i = 0; i < count; i++) {
    if (signal?.aborted) throw new NcError("cancelled");
    const start = i * chunkSize;
    const end = Math.min(size, start + chunkSize);
    const name = chunkName(i);
    if (have.get(name) === end - start) continue;
    const base = sent;
    await withRetry(() => ncRequest(api, davUploadsUrl(conn.origin, conn.userId, record.id, name), {
      method: "PUT",
      headers: { Destination: destUrl, "OC-Total-Length": String(size), "Content-Type": "application/octet-stream" },
      body: file.slice(start, end),
      onProgress: (loaded) => onProgress?.(base + loaded, size),
      signal
    }), { retries, signal, wait });
    sent += end - start;
    onProgress?.(sent, size);
  }
  await withRetry(() => ncRequest(api, davUploadsUrl(conn.origin, conn.userId, record.id, ".file"), {
    method: "MOVE",
    headers: { Destination: destUrl, "OC-Total-Length": String(size) },
    signal
  }), { retries, signal, wait });
  const after = await api.storage.get(UPLOADS_KEY) ?? {};
  delete after[key];
  await api.storage.set(UPLOADS_KEY, after);
  return { path: destPath, chunked: true, resumed };
}
async function discardUpload(api, conn, file, destPath) {
  const key = resumeKey(destPath, file);
  const saved = await api.storage.get(UPLOADS_KEY) ?? {};
  const record = saved[key];
  if (!record) return false;
  await ncRequest(api, davUploadsUrl(conn.origin, conn.userId, record.id), { method: "DELETE" }, { accept: [404] }).catch(() => {
  });
  delete saved[key];
  await api.storage.set(UPLOADS_KEY, saved);
  return true;
}

// nextcloud/src/lib/save.js
var SAVE_FOLDER_KEY = "saveFolder";
async function planUpload(client, folder, name) {
  await client.mkdirp(folder);
  const taken = await client.names(folder);
  return joinPath(folder, uniqueName(sanitizeFileName(name), taken));
}
function emlName(subject) {
  const base = sanitizeFileName(String(subject ?? "").replace(/\s+/g, " ").trim().slice(0, 120), "message");
  return `${base}.eml`;
}
async function saveAttachment(api, client, { emailId, blobId, name }, folder, { onProgress, signal } = {}) {
  const data = await api.email.getAttachment(emailId, blobId);
  const blob = new Blob([data.data], { type: data.type || "application/octet-stream" });
  const path = await planUpload(client, folder, name || data.name || "attachment");
  await uploadFile(api, client, Object.assign(blob, { name: data.name }), path, { onProgress, signal });
  return path;
}
async function saveMessage(api, client, { emailId, name }, folder, { onProgress, signal } = {}) {
  const raw = await api.email.getRaw(emailId);
  const blob = new Blob([raw], { type: "message/rfc822" });
  const path = await planUpload(client, folder, name || "message.eml");
  await uploadFile(api, client, blob, path, { onProgress, signal });
  return path;
}

// nextcloud/src/lib/format.js
var UNITS = ["B", "KB", "MB", "GB", "TB"];
function formatSize(bytes, locale) {
  let n = Number(bytes) || 0;
  let unit = 0;
  while (n >= 1024 && unit < UNITS.length - 1) {
    n /= 1024;
    unit++;
  }
  const digits = unit === 0 || n >= 100 ? 0 : 1;
  let text;
  try {
    text = new Intl.NumberFormat(locale || void 0, { maximumFractionDigits: digits }).format(n);
  } catch {
    text = n.toFixed(digits);
  }
  return `${text} ${UNITS[unit]}`;
}
function formatDate(ms, locale) {
  if (!ms) return "";
  try {
    return new Intl.DateTimeFormat(locale || void 0, { dateStyle: "medium" }).format(new Date(ms));
  } catch {
    return new Date(ms).toISOString().slice(0, 10);
  }
}
function dateInDays(days, now = /* @__PURE__ */ new Date()) {
  const n = Math.floor(Number(days) || 0);
  if (n <= 0) return "";
  const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() + n);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function hostOf(origin) {
  try {
    return new URL(origin).host;
  } catch {
    return String(origin ?? "");
  }
}

// nextcloud/src/lib/links.js
var PENDING_KEY = "pendingLinks";
var MAX_PENDING = 50;
function escapeHtml(s) {
  return String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
function safeUrl(url) {
  const s = String(url ?? "");
  return /^https?:\/\//i.test(s) ? s : "";
}
function details(t, link, locale) {
  const parts = [];
  if (link.size) parts.push(formatSize(link.size, locale));
  if (link.password && link.includePassword) parts.push(t("links.password", { password: link.password }));
  if (link.expireDate) parts.push(t("links.until", { date: link.expireDate }));
  return parts;
}
function linkBlock(t, links, locale) {
  const usable = (links ?? []).filter((l) => safeUrl(l.url));
  if (usable.length === 0) return { html: "", text: "" };
  const title = t("links.title");
  const items = usable.map((l) => {
    const extra = details(t, l, locale);
    return `<li><a href="${escapeHtml(safeUrl(l.url))}">${escapeHtml(l.name || l.url)}</a>${extra.length ? ` (${escapeHtml(extra.join(", "))})` : ""}</li>`;
  }).join("");
  const html = `<div class="nextcloud-links"><p><strong>${escapeHtml(title)}</strong></p><ul>${items}</ul></div>`;
  const lines = usable.map((l) => {
    const extra = details(t, l, locale);
    return `- ${l.name || l.url}: ${safeUrl(l.url)}${extra.length ? ` (${extra.join(", ")})` : ""}`;
  });
  return { html, text: `

${title}
${lines.join("\n")}
` };
}
function appendLinks(outgoing, block) {
  if (!block.html && !block.text) return outgoing;
  const next = { ...outgoing };
  if (outgoing.htmlBody) next.htmlBody = outgoing.htmlBody + block.html;
  if (outgoing.textBody || !outgoing.htmlBody) next.textBody = (outgoing.textBody || "") + block.text;
  return next;
}
async function getPending(storage) {
  const value = await storage.get(PENDING_KEY);
  return Array.isArray(value) ? value : [];
}
async function addPending(storage, links) {
  const current = await getPending(storage);
  const next = [...current, ...links].slice(-MAX_PENDING);
  await storage.set(PENDING_KEY, next);
  return next;
}
async function removePending(storage, id) {
  const next = (await getPending(storage)).filter((l) => l.id !== id);
  await storage.set(PENDING_KEY, next);
  return next;
}
async function clearPending(storage) {
  await storage.set(PENDING_KEY, []);
}

// nextcloud/src/ui/settings-section.js
var import_react2 = require("react");

// nextcloud/src/ui/styles.js
var CSS = `
.nc { font-size: 13px; color: var(--color-foreground); line-height: 1.4; }
.nc * { box-sizing: border-box; }
.nc-row { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.nc-col { display: flex; flex-direction: column; gap: 8px; }
.nc-grow { flex: 1 1 auto; min-width: 0; }
.nc-muted { color: var(--color-muted-foreground); }
.nc-small { font-size: 12px; }
.nc-error { color: var(--color-destructive); }
.nc-ok { color: var(--color-success, var(--color-foreground)); }
.nc-btn { font: inherit; display: inline-flex; align-items: center; justify-content: center; gap: 6px; padding: 6px 12px; min-height: 32px;
  border-radius: 6px; border: 1px solid var(--color-border); background: var(--color-background); color: var(--color-foreground); cursor: pointer; white-space: nowrap; }
.nc-btn:hover:not(:disabled) { background: var(--color-accent); color: var(--color-accent-foreground); }
.nc-btn:disabled { opacity: .55; cursor: default; }
.nc-btn:focus-visible, .nc-input:focus-visible, .nc-item:focus-visible, .nc-tab:focus-visible, .nc-crumb:focus-visible, .nc-check:focus-visible { outline: 2px solid var(--color-ring); outline-offset: 1px; }
.nc-primary { background: var(--color-primary); color: var(--color-primary-foreground); border-color: var(--color-primary); }
.nc-primary:hover:not(:disabled) { background: var(--color-primary); color: var(--color-primary-foreground); filter: brightness(1.08); }
.nc-danger { color: var(--color-destructive); }
.nc-link { font: inherit; background: none; border: 0; padding: 0; color: var(--color-primary); cursor: pointer; text-decoration: underline; }
.nc-input { font: inherit; padding: 6px 8px; min-height: 32px; border-radius: 6px; border: 1px solid var(--color-input); background: var(--color-background); color: var(--color-foreground); }
.nc-label { display: flex; flex-direction: column; gap: 4px; font-size: 12px; }
.nc-check { width: 16px; height: 16px; accent-color: var(--color-primary); margin: 0; }
.nc-tabs { display: flex; gap: 4px; border-bottom: 1px solid var(--color-border); }
.nc-tab { font: inherit; background: none; border: 0; border-bottom: 2px solid transparent; padding: 6px 10px; color: var(--color-muted-foreground); cursor: pointer; }
.nc-tab[aria-selected="true"] { color: var(--color-foreground); border-bottom-color: var(--color-primary); }
.nc-crumbs { display: flex; flex-wrap: wrap; align-items: center; gap: 2px; font-size: 12px; }
.nc-crumb { font: inherit; background: none; border: 0; padding: 2px 4px; border-radius: 4px; color: var(--color-muted-foreground); cursor: pointer; }
.nc-crumb:hover { background: var(--color-muted); color: var(--color-foreground); }
.nc-crumb[aria-current="page"] { color: var(--color-foreground); font-weight: 600; }
.nc-list { border: 1px solid var(--color-border); border-radius: 8px; overflow: auto; background: var(--color-background); }
.nc-item { display: flex; align-items: center; gap: 10px; width: 100%; padding: 8px 10px; border: 0; border-bottom: 1px solid var(--color-border);
  background: none; color: inherit; font: inherit; text-align: start; cursor: pointer; min-height: 40px; }
.nc-item:last-child { border-bottom: 0; }
.nc-item:hover { background: var(--color-muted); }
.nc-item[aria-selected="true"], .nc-item[data-checked="true"] { background: var(--color-selection, var(--color-accent)); color: var(--color-selection-foreground, var(--color-accent-foreground)); }
.nc-icon { width: 18px; height: 18px; flex: 0 0 18px; color: var(--color-muted-foreground); }
.nc-name { flex: 1 1 auto; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.nc-meta { flex: 0 0 auto; font-size: 12px; color: var(--color-muted-foreground); white-space: nowrap; }
.nc-empty { padding: 24px 12px; text-align: center; color: var(--color-muted-foreground); }
.nc-bar { height: 6px; border-radius: 3px; background: var(--color-muted); overflow: hidden; }
.nc-bar > span { display: block; height: 100%; background: var(--color-primary); transition: width .2s; }
.nc-card { border: 1px solid var(--color-border); border-radius: 8px; padding: 12px; background: var(--color-card, var(--color-background)); color: var(--color-card-foreground, var(--color-foreground)); }
.nc-chip { display: inline-flex; align-items: center; gap: 4px; max-width: 100%; padding: 2px 4px 2px 8px; border-radius: 999px; background: var(--color-muted); font-size: 12px; }
.nc-chip button { font: inherit; border: 0; background: none; color: inherit; cursor: pointer; padding: 2px 6px; border-radius: 999px; }
.nc-chip button:hover { background: var(--color-accent); }
.nc-sr { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; }
@media (max-width: 520px) {
  .nc-meta.nc-hide-narrow { display: none; }
  .nc-footer { flex-direction: column; align-items: stretch; }
  .nc-footer .nc-btn { width: 100%; }
}
`;
function ensureStyles() {
  if (typeof document === "undefined" || document.getElementById("nc-styles")) return;
  const el = document.createElement("style");
  el.id = "nc-styles";
  el.textContent = CSS;
  document.head.appendChild(el);
}

// nextcloud/src/ui/connection-ui.js
var import_react = require("react");
function useConnection(api) {
  const [state, setState] = (0, import_react.useState)({ status: "loading" });
  const flowRef = (0, import_react.useRef)(null);
  const mounted = (0, import_react.useRef)(true);
  const set = (next) => {
    if (mounted.current) setState(next);
  };
  const refresh = (0, import_react.useCallback)(async () => {
    let fixed = null;
    try {
      fixed = await adminServer(api);
      const conn = await getConnection(api, { fixedServer: fixed });
      set(conn ? { status: "connected", conn, fixed } : { status: "disconnected", fixed });
      return conn;
    } catch (err) {
      if (err instanceof NcError && err.code === "wrong_server") set({ status: "disconnected", fixed, error: err });
      else if (needsSignIn(err)) set({ status: "expired", fixed, error: err });
      else set({ status: "error", fixed, error: err });
      return null;
    }
  }, [api]);
  (0, import_react.useEffect)(() => {
    mounted.current = true;
    void refresh();
    return () => {
      mounted.current = false;
      flowRef.current?.abort();
    };
  }, [refresh]);
  const connect = (0, import_react.useCallback)(async () => {
    const fixed = await adminServer(api);
    set({ status: "approving", fixed });
    const controller = new AbortController();
    flowRef.current?.abort();
    flowRef.current = controller;
    try {
      const origin = await approveServer(api, { fixedServer: fixed, suggestedServer: state.conn?.origin });
      if (!origin) {
        await refresh();
        return null;
      }
      const flow = await startLoginFlow(api, origin);
      set({ status: "waiting", fixed, origin, loginUrl: flow.loginUrl });
      await api.ui.openExternalUrl(flow.loginUrl).catch(() => {
      });
      await pollLoginFlow(api, flow, { signal: controller.signal });
      const conn = await refresh();
      if (conn) api.toast.success(api.i18n.t("connect.done", { host: hostOf(conn.origin) }));
      return conn;
    } catch (err) {
      if (err instanceof NcError && err.code === "cancelled") {
        await refresh();
        return null;
      }
      set({ status: "error", fixed, error: err });
      return null;
    } finally {
      if (flowRef.current === controller) flowRef.current = null;
    }
  }, [api, refresh, state.conn]);
  const cancel = (0, import_react.useCallback)(() => {
    flowRef.current?.abort();
  }, []);
  const signOut = (0, import_react.useCallback)(async () => {
    try {
      await disconnect(api);
    } catch (err) {
      api.toast.error(errorText(api.i18n.t, err));
    }
    await refresh();
  }, [api, refresh]);
  const report = (0, import_react.useCallback)((err) => {
    if (needsSignIn(err)) set({ status: "expired", fixed: state.fixed, error: err });
  }, [state.fixed]);
  return { ...state, refresh, connect, cancel, signOut, report };
}
function ConnectionPanel({ api, connection, compact = false, intro }) {
  const t = api.i18n.t;
  const c = connection;
  const fixedHost = c.fixed ? hostOf(c.fixed) : "";
  if (c.status === "loading") {
    return (0, import_react.createElement)("p", { className: "nc-muted", role: "status" }, t("connect.checking"));
  }
  if (c.status === "connected") {
    const who = c.conn.displayName || c.conn.userId;
    return (0, import_react.createElement)(
      "div",
      { className: "nc-row" },
      (0, import_react.createElement)("span", { className: "nc-grow", role: "status" }, t("connect.connected", { host: hostOf(c.conn.origin), user: who })),
      compact ? null : (0, import_react.createElement)("button", { type: "button", className: "nc-btn", onClick: () => void c.signOut() }, t("connect.disconnect"))
    );
  }
  if (c.status === "approving") {
    return (0, import_react.createElement)("p", { className: "nc-muted", role: "status" }, t("connect.approving"));
  }
  if (c.status === "waiting") {
    return (0, import_react.createElement)(
      "div",
      { className: "nc-col", role: "status" },
      (0, import_react.createElement)("p", { style: { margin: 0 } }, t("connect.waiting", { host: hostOf(c.origin) })),
      (0, import_react.createElement)(
        "div",
        { className: "nc-row" },
        (0, import_react.createElement)("button", { type: "button", className: "nc-btn", onClick: () => void api.ui.openExternalUrl(c.loginUrl) }, t("connect.reopen")),
        (0, import_react.createElement)("button", { type: "button", className: "nc-btn", onClick: c.cancel }, t("common.cancel"))
      )
    );
  }
  const message = c.status === "expired" ? t("connect.expired") : c.status === "error" ? errorText(t, c.error) : c.error?.code === "wrong_server" ? t("error.wrong_server_host", { host: fixedHost }) : intro ?? t("connect.intro");
  return (0, import_react.createElement)(
    "div",
    { className: "nc-col" },
    (0, import_react.createElement)("p", { style: { margin: 0 }, className: c.status === "error" ? "nc-error" : void 0, role: c.status === "error" ? "alert" : void 0 }, message),
    fixedHost && c.status === "disconnected" ? (0, import_react.createElement)("p", { className: "nc-muted nc-small", style: { margin: 0 } }, t("connect.server", { host: fixedHost })) : null,
    (0, import_react.createElement)(
      "div",
      { className: "nc-row" },
      (0, import_react.createElement)(
        "button",
        { type: "button", className: "nc-btn nc-primary", onClick: () => void c.connect() },
        c.status === "expired" ? t("connect.again") : t("connect.button")
      )
    )
  );
}

// nextcloud/src/ui/settings-section.js
function SettingsSection() {
  ensureStyles();
  const api = getApi();
  const t = api.i18n.t;
  const connection = useConnection(api);
  return (0, import_react2.createElement)(
    "section",
    { className: "nc nc-col", "aria-label": t("settings.title") },
    (0, import_react2.createElement)("h3", { style: { margin: 0, fontSize: "14px" } }, t("settings.title")),
    (0, import_react2.createElement)(ConnectionPanel, { api, connection }),
    (0, import_react2.createElement)("p", { className: "nc-muted nc-small", style: { margin: 0 } }, t("settings.privacy")),
    (0, import_react2.createElement)("p", { className: "nc-muted nc-small", style: { margin: 0 } }, t("settings.migration"))
  );
}

// nextcloud/src/ui/composer-source.js
var import_react4 = require("react");

// nextcloud/src/ui/icons.js
var import_react3 = require("react");
var PATHS = {
  folder: "M5 4h4l3 3h7a2 2 0 0 1 2 2v8a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-11a2 2 0 0 1 2 -2",
  file: "M14 3v4a1 1 0 0 0 1 1h4 M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2z",
  cloud: "M6.657 18c-2.572 0 -4.657 -2.007 -4.657 -4.483c0 -2.475 2.085 -4.482 4.657 -4.482c.393 -1.762 1.794 -3.2 3.675 -3.773c1.88 -.572 3.956 -.193 5.444 1c1.488 1.19 2.162 3.007 1.77 4.769h.99c1.913 0 3.464 1.56 3.464 3.486c0 1.927 -1.551 3.487 -3.465 3.487h-11.878",
  up: "M12 5l0 14 M18 11l-6 -6 M6 11l6 -6",
  x: "M18 6l-12 12 M6 6l12 12"
};
function Icon({ name, size = 18, className = "nc-icon", label }) {
  return (0, import_react3.createElement)("svg", {
    className,
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    ...label ? { role: "img", "aria-label": label } : { "aria-hidden": "true" }
  }, (0, import_react3.createElement)("path", { d: PATHS[name] ?? PATHS.file }));
}

// nextcloud/src/ui/composer-source.js
async function applyPickerResult(api, result, onAttach) {
  const t = api.i18n.t;
  if (!result || typeof result !== "object") return { attached: 0, links: 0 };
  if (result.action === "attach") {
    let attached = 0;
    for (const blob of result.blobs ?? []) {
      const ok = typeof onAttach === "function" ? await onAttach(blob) : false;
      if (ok === false) {
        api.toast.error(t("error.attach_refused_name", { name: blob.name }));
        break;
      }
      attached++;
    }
    if (attached) api.toast.success(t("composer.attached", { count: attached }));
    return { attached, links: 0 };
  }
  if (result.action === "links" && Array.isArray(result.links) && result.links.length) {
    await addPending(api.storage, result.links);
    api.toast.success(t("composer.linksAdded", { count: result.links.length }));
    return { attached: 0, links: result.links.length };
  }
  return { attached: 0, links: 0 };
}
function ComposerSource(props) {
  ensureStyles();
  const api = getApi();
  const t = api.i18n.t;
  const connection = useConnection(api);
  const [pending, setPending] = (0, import_react4.useState)([]);
  const [busy, setBusy] = (0, import_react4.useState)(false);
  const reload = (0, import_react4.useCallback)(() => getPending(api.storage).then(setPending).catch(() => {
  }), []);
  (0, import_react4.useEffect)(() => {
    void reload();
  }, [reload]);
  const open = async () => {
    if (busy) return;
    if (connection.status !== "connected") {
      await connection.connect();
      return;
    }
    setBusy(true);
    try {
      const result = await api.ui.openDialog({ title: t("picker.title"), slot: "plugin-dialog", extraProps: { view: "picker" }, width: 760 });
      await applyPickerResult(api, result, props.onAttach);
      await reload();
    } catch (err) {
      api.toast.error(errorText(t, err));
    } finally {
      setBusy(false);
    }
  };
  const waiting = connection.status === "waiting" || connection.status === "approving";
  const label = connection.status === "connected" || connection.status === "loading" ? t("composer.button") : t("connect.button");
  return (0, import_react4.createElement)(
    "div",
    { className: "nc nc-row", style: { gap: 6 } },
    (0, import_react4.createElement)("button", {
      type: "button",
      className: "nc-btn",
      onClick: () => void open(),
      disabled: busy || waiting || connection.status === "loading",
      title: connection.status === "expired" ? t("connect.expired") : t("composer.title")
    }, (0, import_react4.createElement)(Icon, { name: "cloud", size: 16, className: "" }), waiting ? t("composer.waiting") : label),
    waiting ? (0, import_react4.createElement)("button", { type: "button", className: "nc-link nc-small", onClick: connection.cancel }, t("common.cancel")) : null,
    pending.length ? (0, import_react4.createElement)(
      "div",
      { className: "nc-row", style: { gap: 4 }, "aria-label": t("composer.pending"), role: "list" },
      (0, import_react4.createElement)("span", { className: "nc-muted nc-small", title: t("composer.pendingHint") }, t("composer.pendingCount", { count: pending.length })),
      ...pending.map((link) => (0, import_react4.createElement)(
        "span",
        { key: link.id, className: "nc-chip", role: "listitem", title: link.url },
        (0, import_react4.createElement)("span", { className: "nc-name", style: { maxWidth: 140 } }, link.name),
        (0, import_react4.createElement)("button", {
          type: "button",
          "aria-label": t("composer.removeLink", { name: link.name }),
          onClick: () => void removePending(api.storage, link.id).then(setPending)
        }, "×")
      ))
    ) : null
  );
}

// nextcloud/src/ui/dialog.js
var import_react9 = require("react");

// nextcloud/src/ui/picker-dialog.js
var import_react6 = require("react");

// nextcloud/src/lib/attach.js
function randomId() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}
async function attachEntries(api, client, entries, { onAttach, onProgress, signal } = {}) {
  const attached = [];
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (signal?.aborted) throw new NcError("cancelled");
    const report = (loaded, total) => onProgress?.({ index: i, count: entries.length, name: entry.name, loaded, total: total || entry.size || 0 });
    report(0, entry.size);
    const bytes = await client.download(entry, { signal, onProgress: report });
    if (signal?.aborted) throw new NcError("cancelled");
    const type = entry.type || "application/octet-stream";
    let blob;
    try {
      blob = await api.jmap.uploadBlob(bytes, entry.name, type);
    } catch (err) {
      throw errorFromException(err, signal);
    }
    const ok = await onAttach({ blobId: blob.blobId, name: entry.name, type: blob.type || type, size: blob.size ?? bytes.byteLength });
    if (ok === false) throw new NcError("attach_refused", { detail: entry.name });
    attached.push(entry.name);
  }
  return attached;
}
async function shareEntries(client, entries, { password = "", expireDate = "", includePassword = false } = {}) {
  const links = [];
  for (const entry of entries) {
    const share = await client.share(entry.path, { password, expireDate });
    links.push({
      id: randomId(),
      name: entry.name,
      size: entry.isFolder ? 0 : entry.size,
      url: share.url,
      password: password || "",
      includePassword: !!(password && includePassword),
      expireDate: expireDate || ""
    });
  }
  return links;
}

// nextcloud/src/ui/browser.js
var import_react5 = require("react");
function FileBrowser({
  api,
  client,
  mode,
  path,
  onNavigate,
  selected,
  onToggle,
  reloadKey = 0,
  onError,
  listHeight = 320,
  toolbar
}) {
  const t = api.i18n.t;
  const locale = api.i18n.getLocale();
  const [view, setView] = (0, import_react5.useState)("files");
  const [query, setQuery] = (0, import_react5.useState)("");
  const [searched, setSearched] = (0, import_react5.useState)("");
  const [state, setState] = (0, import_react5.useState)({ loading: true, entries: [], error: null });
  const seq = (0, import_react5.useRef)(0);
  (0, import_react5.useEffect)(() => {
    const mine = ++seq.current;
    setState((s) => ({ ...s, loading: true, error: null }));
    const load = view === "recent" ? client.recent({ limit: 50 }) : view === "search" ? client.search(searched, { limit: 100 }) : client.list(path, locale);
    load.then(
      (entries) => {
        if (seq.current === mine) setState({ loading: false, entries, error: null });
      },
      (error) => {
        if (seq.current !== mine) return;
        setState({ loading: false, entries: [], error });
        onError?.(error);
      }
    );
  }, [client, view, path, searched, reloadKey]);
  const runSearch = (e) => {
    e?.preventDefault?.();
    const q = query.trim();
    if (!q) {
      setView("files");
      return;
    }
    setSearched(q);
    setView("search");
  };
  const shown = mode === "folder" && view !== "files" ? state.entries.filter((e) => e.isFolder) : state.entries;
  const flat = view !== "files";
  const open = (entry) => {
    if (entry.isFolder) {
      setView("files");
      onNavigate(entry.path);
      return;
    }
    if (mode !== "folder") onToggle?.(entry);
  };
  const tab = (id, label) => (0, import_react5.createElement)("button", {
    type: "button",
    role: "tab",
    className: "nc-tab",
    "aria-selected": view === id ? "true" : "false",
    onClick: () => {
      setView(id);
      if (id !== "search") setQuery("");
    }
  }, label);
  const crumbs = breadcrumb(path);
  return (0, import_react5.createElement)(
    "div",
    { className: "nc-col" },
    // No <form>: the sandboxed iframe may not submit forms.
    (0, import_react5.createElement)(
      "div",
      { className: "nc-row", role: "search" },
      (0, import_react5.createElement)("label", { className: "nc-sr", htmlFor: "nc-search" }, t("browser.search")),
      (0, import_react5.createElement)("input", {
        id: "nc-search",
        className: "nc-input nc-grow",
        type: "search",
        value: query,
        placeholder: t("browser.searchPlaceholder"),
        onChange: (e) => setQuery(e.target.value),
        onKeyDown: (e) => {
          if (e.key === "Enter") runSearch(e);
        }
      }),
      (0, import_react5.createElement)("button", { type: "button", className: "nc-btn", onClick: runSearch }, t("browser.search"))
    ),
    (0, import_react5.createElement)(
      "div",
      { className: "nc-tabs", role: "tablist" },
      tab("files", t("browser.allFiles")),
      tab("recent", t("browser.recent")),
      view === "search" ? tab("search", t("browser.results", { query: searched })) : null
    ),
    view === "files" ? (0, import_react5.createElement)(
      "nav",
      { className: "nc-crumbs", "aria-label": t("browser.location") },
      path !== "/" ? (0, import_react5.createElement)("button", {
        type: "button",
        className: "nc-crumb",
        onClick: () => onNavigate(parentPath(path)),
        "aria-label": t("browser.up"),
        title: t("browser.up")
      }, (0, import_react5.createElement)(Icon, { name: "up", size: 14, className: "" })) : null,
      ...crumbs.map((c, i) => [
        i > 0 ? (0, import_react5.createElement)("span", { key: `s${i}`, className: "nc-muted", "aria-hidden": "true" }, "/") : null,
        (0, import_react5.createElement)("button", {
          key: c.path,
          type: "button",
          className: "nc-crumb",
          onClick: () => onNavigate(c.path),
          "aria-current": i === crumbs.length - 1 ? "page" : void 0
        }, c.name || t("browser.home"))
      ]).flat().filter(Boolean)
    ) : null,
    toolbar ?? null,
    (0, import_react5.createElement)(
      "div",
      { className: "nc-list", style: { maxHeight: listHeight, minHeight: Math.min(listHeight, 160) }, "aria-busy": state.loading ? "true" : "false" },
      state.loading ? (0, import_react5.createElement)("div", { className: "nc-empty", role: "status" }, t("browser.loading")) : state.error ? (0, import_react5.createElement)("div", { className: "nc-empty nc-error", role: "alert" }, errorText(t, state.error)) : shown.length === 0 ? (0, import_react5.createElement)("div", { className: "nc-empty" }, view === "search" ? t("browser.noResults") : view === "recent" ? t("browser.noRecent") : t("browser.empty")) : shown.map((entry) => {
        const isSelected = selected?.has(entry.path) ?? false;
        const pickable = entry.isFolder || mode !== "folder";
        const meta = entry.isFolder ? flat ? parentPath(entry.path) : "" : [flat ? parentPath(entry.path) : "", formatSize(entry.size, locale), formatDate(entry.modified, locale)].filter(Boolean).join(" · ");
        return (0, import_react5.createElement)(
          "button",
          {
            key: entry.path,
            type: "button",
            className: "nc-item",
            disabled: !pickable,
            "data-checked": isSelected ? "true" : "false",
            "aria-pressed": !entry.isFolder && mode !== "folder" ? isSelected ? "true" : "false" : void 0,
            "data-path": entry.path,
            onClick: () => open(entry),
            style: pickable ? void 0 : { opacity: 0.5, cursor: "default" }
          },
          mode === "files" && !entry.isFolder ? (0, import_react5.createElement)("input", { type: "checkbox", className: "nc-check", checked: isSelected, readOnly: true, tabIndex: -1, "aria-hidden": "true" }) : null,
          (0, import_react5.createElement)(Icon, { name: entry.isFolder ? "folder" : "file" }),
          (0, import_react5.createElement)("span", { className: "nc-name", title: entry.name }, entry.name),
          meta ? (0, import_react5.createElement)("span", { className: "nc-meta nc-hide-narrow" }, meta) : null
        );
      })
    )
  );
}

// nextcloud/src/ui/picker-dialog.js
var LAST_PATH_KEY = "pickerPath";
function ShareOptions({ api, client, value, onChange, idPrefix = "nc" }) {
  const t = api.i18n.t;
  const set = (patch) => onChange({ ...value, ...patch });
  const latest = (0, import_react6.useRef)(value);
  latest.current = value;
  (0, import_react6.useEffect)(() => {
    if (!value.usePassword || value.password) return;
    let live = true;
    client.generatePassword().then((password) => {
      if (live && latest.current.usePassword && !latest.current.password) onChange({ ...latest.current, password });
    });
    return () => {
      live = false;
    };
  }, [value.usePassword]);
  const togglePassword = (on) => set({ usePassword: on });
  return (0, import_react6.createElement)(
    "fieldset",
    { className: "nc-col nc-card", style: { margin: 0 } },
    (0, import_react6.createElement)("legend", { className: "nc-small", style: { padding: "0 4px" } }, t("share.options")),
    (0, import_react6.createElement)(
      "label",
      { className: "nc-row" },
      (0, import_react6.createElement)("input", { type: "checkbox", className: "nc-check", checked: value.usePassword, onChange: (e) => togglePassword(e.target.checked) }),
      t("share.usePassword")
    ),
    value.usePassword ? (0, import_react6.createElement)(
      "div",
      { className: "nc-col", style: { paddingInlineStart: 24 } },
      (0, import_react6.createElement)(
        "label",
        { className: "nc-label", htmlFor: `${idPrefix}-password` },
        t("share.password"),
        (0, import_react6.createElement)("input", {
          id: `${idPrefix}-password`,
          className: "nc-input",
          type: "text",
          autoComplete: "off",
          spellCheck: false,
          value: value.password,
          onChange: (e) => set({ password: e.target.value })
        })
      ),
      (0, import_react6.createElement)(
        "label",
        { className: "nc-row nc-small" },
        (0, import_react6.createElement)("input", { type: "checkbox", className: "nc-check", checked: value.includePassword, onChange: (e) => set({ includePassword: e.target.checked }) }),
        t("share.includePassword")
      ),
      !value.includePassword ? (0, import_react6.createElement)("p", { className: "nc-muted nc-small", style: { margin: 0 } }, t("share.sendSeparately")) : null
    ) : null,
    (0, import_react6.createElement)(
      "label",
      { className: "nc-label", htmlFor: `${idPrefix}-expiry` },
      t("share.expiry"),
      (0, import_react6.createElement)("input", {
        id: `${idPrefix}-expiry`,
        className: "nc-input",
        type: "date",
        value: value.expireDate,
        min: dateInDays(1),
        onChange: (e) => set({ expireDate: e.target.value }),
        style: { maxWidth: 200 }
      })
    ),
    (0, import_react6.createElement)("p", { className: "nc-muted nc-small", style: { margin: 0 } }, value.expireDate ? t("share.expiryHint") : t("share.noExpiry"))
  );
}
function defaultShareOptions(settings) {
  return {
    usePassword: settings?.passwordProtect === true,
    password: "",
    includePassword: false,
    expireDate: dateInDays(Number(settings?.expiryDays ?? 14))
  };
}
function PickerDialog({ api, client, onResult, report }) {
  const t = api.i18n.t;
  const locale = api.i18n.getLocale();
  const [path, setPath] = (0, import_react6.useState)("/");
  const [selected, setSelected] = (0, import_react6.useState)(() => /* @__PURE__ */ new Map());
  const [share, setShare] = (0, import_react6.useState)(() => defaultShareOptions(api.plugin.settings));
  const [showShare, setShowShare] = (0, import_react6.useState)(false);
  const [busy, setBusy] = (0, import_react6.useState)(null);
  const [error, setError] = (0, import_react6.useState)(null);
  const abortRef = (0, import_react6.useRef)(null);
  (0, import_react6.useEffect)(() => {
    api.storage.get(LAST_PATH_KEY).then((p) => {
      if (typeof p === "string" && p) setPath(p);
    }).catch(() => {
    });
    return () => abortRef.current?.abort();
  }, []);
  const navigate = (p) => {
    setPath(p);
    void api.storage.set(LAST_PATH_KEY, p).catch(() => {
    });
  };
  const toggle = (entry) => setSelected((prev) => {
    const next = new Map(prev);
    if (next.has(entry.path)) next.delete(entry.path);
    else next.set(entry.path, entry);
    return next;
  });
  const entries = (0, import_react6.useMemo)(() => [...selected.values()], [selected]);
  const total = entries.reduce((n, e) => n + (e.size || 0), 0);
  const fail = (err) => {
    if (err instanceof NcError && err.code === "cancelled") {
      setBusy(null);
      return;
    }
    report?.(err);
    setError(err);
    setBusy(null);
  };
  const attach = async () => {
    setError(null);
    const controller = new AbortController();
    abortRef.current = controller;
    const blobs = [];
    setBusy({ kind: "attach", index: 0, count: entries.length, loaded: 0, total: entries[0]?.size || 0, name: entries[0]?.name });
    try {
      await attachEntries(api, client, entries, {
        signal: controller.signal,
        onProgress: (p) => setBusy({ kind: "attach", ...p }),
        onAttach: async (blob) => {
          blobs.push(blob);
          return true;
        }
      });
      onResult({ action: "attach", blobs });
    } catch (err) {
      fail(err);
    }
  };
  const shareLinks = async () => {
    if (!showShare) {
      setShowShare(true);
      return;
    }
    setError(null);
    setBusy({ kind: "share" });
    try {
      const links = await shareEntries(client, entries, {
        password: share.usePassword ? share.password.trim() : "",
        includePassword: share.includePassword,
        expireDate: share.expireDate
      });
      onResult({ action: "links", links });
    } catch (err) {
      fail(err);
    }
  };
  const percent = busy?.kind === "attach" && busy.total ? Math.round(busy.loaded / busy.total * 100) : 0;
  return (0, import_react6.createElement)(
    "div",
    { className: "nc nc-col" },
    (0, import_react6.createElement)(FileBrowser, { api, client, mode: "files", path, onNavigate: navigate, selected, onToggle: toggle, onError: report, listHeight: 340 }),
    showShare ? (0, import_react6.createElement)(ShareOptions, { api, client, value: share, onChange: setShare, idPrefix: "nc-pick" }) : null,
    error ? (0, import_react6.createElement)("p", { className: "nc-error", role: "alert", style: { margin: 0 } }, errorText(t, error)) : null,
    busy?.kind === "attach" ? (0, import_react6.createElement)(
      "div",
      { className: "nc-col", role: "status" },
      (0, import_react6.createElement)("span", { className: "nc-small" }, t("picker.downloading", { name: busy.name ?? "", index: (busy.index ?? 0) + 1, count: busy.count ?? 1 })),
      (0, import_react6.createElement)(
        "div",
        { className: "nc-bar", role: "progressbar", "aria-valuemin": 0, "aria-valuemax": 100, "aria-valuenow": percent, "aria-label": t("picker.progress") },
        (0, import_react6.createElement)("span", { style: { width: `${percent}%` } })
      )
    ) : null,
    busy?.kind === "share" ? (0, import_react6.createElement)("p", { className: "nc-muted", role: "status", style: { margin: 0 } }, t("picker.sharing")) : null,
    (0, import_react6.createElement)(
      "div",
      { className: "nc-row nc-footer" },
      (0, import_react6.createElement)(
        "span",
        { className: "nc-grow nc-muted nc-small", "aria-live": "polite" },
        entries.length ? t("picker.selected", { count: entries.length, size: formatSize(total, locale) }) : t("picker.hint")
      ),
      busy?.kind === "attach" ? (0, import_react6.createElement)("button", { type: "button", className: "nc-btn", onClick: () => abortRef.current?.abort() }, t("common.cancel")) : null,
      (0, import_react6.createElement)(
        "button",
        { type: "button", className: "nc-btn", disabled: !entries.length || !!busy, onClick: () => void shareLinks() },
        showShare ? t("picker.createLinks") : t("picker.shareLinks")
      ),
      (0, import_react6.createElement)(
        "button",
        { type: "button", className: "nc-btn nc-primary", disabled: !entries.length || !!busy, onClick: () => void attach() },
        t("picker.attach")
      )
    )
  );
}

// nextcloud/src/ui/offload-dialog.js
var import_react7 = require("react");
async function offloadFile(api, client, file, { share, onProgress, signal, folder }) {
  const settings = api.plugin.settings ?? {};
  const target = folder ?? uploadFolder(settings.uploadFolder, settings.folderLayout);
  const path = await planUpload(client, target, file.name);
  await uploadFile(api, client, file, path, { onProgress, signal });
  const password = share.usePassword ? share.password.trim() : "";
  const created = await client.share(path, { password, expireDate: share.expireDate });
  const link = {
    id: path,
    name: file.name,
    size: file.size,
    url: created.url,
    password,
    includePassword: !!(password && share.includePassword),
    expireDate: share.expireDate
  };
  const block = linkBlock(api.i18n.t, [link], api.i18n.getLocale());
  return { externalAttachment: true, html: block.html, text: block.text, path, url: created.url };
}
function OffloadDialog({ api, client, onResult, report, fileId, name, size }) {
  const t = api.i18n.t;
  const locale = api.i18n.getLocale();
  const [share, setShare] = (0, import_react7.useState)(() => defaultShareOptions(api.plugin.settings));
  const [state, setState] = (0, import_react7.useState)({ phase: "ask" });
  const abortRef = (0, import_react7.useRef)(null);
  const settings = api.plugin.settings ?? {};
  const folder = uploadFolder(settings.uploadFolder, settings.folderLayout);
  (0, import_react7.useEffect)(() => () => abortRef.current?.abort(), []);
  const start = async () => {
    const controller = new AbortController();
    abortRef.current = controller;
    setState({ phase: "upload", loaded: 0, total: size });
    try {
      const file = await api.upfiles.get(fileId);
      if (!file) throw new NcError("not_found");
      const result = await offloadFile(api, client, file, {
        share,
        folder,
        signal: controller.signal,
        onProgress: (loaded, total) => setState({ phase: "upload", loaded, total })
      });
      onResult(result);
    } catch (err) {
      if (err instanceof NcError && err.code === "cancelled") {
        setState({ phase: "paused" });
        return;
      }
      report?.(err);
      setState({ phase: "error", error: err });
    }
  };
  const percent = state.phase === "upload" && state.total ? Math.round(state.loaded / state.total * 100) : 0;
  return (0, import_react7.createElement)(
    "div",
    { className: "nc nc-col" },
    (0, import_react7.createElement)("p", { style: { margin: 0 } }, t("offload.intro", { name, size: formatSize(size, locale) })),
    (0, import_react7.createElement)("p", { className: "nc-muted nc-small", style: { margin: 0 } }, t("offload.folder", { folder })),
    state.phase === "ask" || state.phase === "error" || state.phase === "paused" ? (0, import_react7.createElement)(ShareOptions, { api, client, value: share, onChange: setShare, idPrefix: "nc-off" }) : null,
    state.phase === "upload" ? (0, import_react7.createElement)(
      "div",
      { className: "nc-col", role: "status" },
      (0, import_react7.createElement)("span", { className: "nc-small" }, t("offload.uploading", { loaded: formatSize(state.loaded, locale), total: formatSize(state.total, locale) })),
      (0, import_react7.createElement)(
        "div",
        { className: "nc-bar", role: "progressbar", "aria-valuemin": 0, "aria-valuemax": 100, "aria-valuenow": percent, "aria-label": t("picker.progress") },
        (0, import_react7.createElement)("span", { style: { width: `${percent}%` } })
      )
    ) : null,
    state.phase === "paused" ? (0, import_react7.createElement)("p", { className: "nc-muted", role: "status", style: { margin: 0 } }, t("offload.paused")) : null,
    state.phase === "error" ? (0, import_react7.createElement)("p", { className: "nc-error", role: "alert", style: { margin: 0 } }, errorText(t, state.error)) : null,
    (0, import_react7.createElement)(
      "div",
      { className: "nc-row nc-footer", style: { justifyContent: "flex-end" } },
      state.phase === "upload" ? (0, import_react7.createElement)("button", { type: "button", className: "nc-btn", onClick: () => abortRef.current?.abort() }, t("common.cancel")) : (0, import_react7.createElement)("button", { type: "button", className: "nc-btn", onClick: () => onResult({ action: "attach" }) }, t("offload.attachNormally")),
      state.phase !== "upload" ? (0, import_react7.createElement)(
        "button",
        { type: "button", className: "nc-btn nc-primary", onClick: () => void start() },
        state.phase === "paused" || state.phase === "error" ? t("offload.resume") : t("offload.upload")
      ) : null
    )
  );
}

// nextcloud/src/ui/save-dialog.js
var import_react8 = require("react");
function NewFolder({ api, client, path, onCreated, onError }) {
  const t = api.i18n.t;
  const [open, setOpen] = (0, import_react8.useState)(false);
  const [name, setName] = (0, import_react8.useState)("");
  const create = async () => {
    const clean = sanitizeFileName(name, "");
    if (!clean) return;
    try {
      const target = joinPath(path, clean);
      await client.mkdir(target);
      setOpen(false);
      setName("");
      onCreated(target);
    } catch (err) {
      onError(err);
    }
  };
  if (!open) return (0, import_react8.createElement)("button", { type: "button", className: "nc-btn", onClick: () => setOpen(true) }, t("save.newFolder"));
  return (0, import_react8.createElement)(
    "div",
    { className: "nc-row" },
    (0, import_react8.createElement)("label", { className: "nc-sr", htmlFor: "nc-new-folder" }, t("save.folderName")),
    (0, import_react8.createElement)("input", {
      id: "nc-new-folder",
      className: "nc-input",
      value: name,
      placeholder: t("save.folderName"),
      autoFocus: true,
      onChange: (e) => setName(e.target.value),
      onKeyDown: (e) => {
        if (e.key === "Enter") void create();
        if (e.key === "Escape") setOpen(false);
      }
    }),
    (0, import_react8.createElement)("button", { type: "button", className: "nc-btn", disabled: !name.trim(), onClick: () => void create() }, t("save.create")),
    (0, import_react8.createElement)("button", { type: "button", className: "nc-btn", onClick: () => setOpen(false) }, t("common.cancel"))
  );
}
function SaveDialog({ api, client, onResult, report, kind, emailId, blobId, name, size }) {
  const t = api.i18n.t;
  const locale = api.i18n.getLocale();
  const [path, setPath] = (0, import_react8.useState)("/");
  const [reloadKey, setReloadKey] = (0, import_react8.useState)(0);
  const [state, setState] = (0, import_react8.useState)({ phase: "pick" });
  const abortRef = (0, import_react8.useRef)(null);
  (0, import_react8.useEffect)(() => {
    api.storage.get(SAVE_FOLDER_KEY).then((p) => {
      if (typeof p === "string" && p) setPath(p);
    }).catch(() => {
    });
    return () => abortRef.current?.abort();
  }, []);
  const fail = (err) => {
    if (err instanceof NcError && err.code === "cancelled") {
      setState({ phase: "pick" });
      return;
    }
    report?.(err);
    setState({ phase: "error", error: err });
  };
  const save = async () => {
    const controller = new AbortController();
    abortRef.current = controller;
    setState({ phase: "saving", loaded: 0, total: size || 0 });
    const opts = { signal: controller.signal, onProgress: (loaded, total) => setState({ phase: "saving", loaded, total }) };
    try {
      const saved = kind === "message" ? await saveMessage(api, client, { emailId, name }, path, opts) : await saveAttachment(api, client, { emailId, blobId, name }, path, opts);
      await api.storage.set(SAVE_FOLDER_KEY, path).catch(() => {
      });
      onResult({ path: saved });
    } catch (err) {
      fail(err);
    }
  };
  const percent = state.phase === "saving" && state.total ? Math.round(state.loaded / state.total * 100) : 0;
  return (0, import_react8.createElement)(
    "div",
    { className: "nc nc-col" },
    (0, import_react8.createElement)("p", { style: { margin: 0 } }, t("save.choose", { name: size ? `${name} (${formatSize(size, locale)})` : name })),
    (0, import_react8.createElement)(FileBrowser, {
      api,
      client,
      mode: "folder",
      path,
      onNavigate: setPath,
      reloadKey,
      onError: report,
      listHeight: 300,
      toolbar: (0, import_react8.createElement)(
        "div",
        { className: "nc-row" },
        (0, import_react8.createElement)(NewFolder, { api, client, path, onCreated: (p) => {
          setPath(p);
          setReloadKey((k) => k + 1);
        }, onError: fail })
      )
    }),
    state.phase === "saving" ? (0, import_react8.createElement)(
      "div",
      { className: "nc-col", role: "status" },
      (0, import_react8.createElement)("span", { className: "nc-small" }, t("save.saving")),
      (0, import_react8.createElement)(
        "div",
        { className: "nc-bar", role: "progressbar", "aria-valuemin": 0, "aria-valuemax": 100, "aria-valuenow": percent, "aria-label": t("picker.progress") },
        (0, import_react8.createElement)("span", { style: { width: `${percent}%` } })
      )
    ) : null,
    state.phase === "error" ? (0, import_react8.createElement)("p", { className: "nc-error", role: "alert", style: { margin: 0 } }, errorText(t, state.error)) : null,
    (0, import_react8.createElement)(
      "div",
      { className: "nc-row nc-footer", style: { justifyContent: "flex-end" } },
      state.phase === "saving" ? (0, import_react8.createElement)("button", { type: "button", className: "nc-btn", onClick: () => abortRef.current?.abort() }, t("common.cancel")) : (0, import_react8.createElement)("button", { type: "button", className: "nc-btn", onClick: () => onResult(null) }, t("common.cancel")),
      (0, import_react8.createElement)("button", { type: "button", className: "nc-btn nc-primary", disabled: state.phase === "saving", onClick: () => void save() }, t("save.here"))
    )
  );
}

// nextcloud/src/ui/dialog.js
var VIEWS = {
  picker: PickerDialog,
  offload: OffloadDialog,
  save: SaveDialog
};
function PluginDialog(props) {
  ensureStyles();
  const api = getApi();
  const connection = useConnection(api);
  const client = (0, import_react9.useMemo)(() => connection.conn ? createClient(api, connection.conn) : null, [connection.conn]);
  const View = VIEWS[props.view];
  if (!View) return null;
  if (connection.status !== "connected" || !client) {
    return (0, import_react9.createElement)("div", { className: "nc" }, (0, import_react9.createElement)(ConnectionPanel, { api, connection }));
  }
  return (0, import_react9.createElement)(View, { ...props, api, client, report: connection.report });
}

// nextcloud/src/ui/files-page.js
var import_react10 = require("react");

// nextcloud/src/lib/files.js
var BLOCKED_EXT = /* @__PURE__ */ new Set([
  "exe",
  "msi",
  "bat",
  "cmd",
  "com",
  "scr",
  "ps1",
  "vbs",
  "vbe",
  "js",
  "jse",
  "wsf",
  "hta",
  "jar",
  "lnk",
  "app",
  "dmg",
  "pkg",
  "sh",
  "command",
  "html",
  "htm",
  "xhtml",
  "shtml",
  "svg",
  "mhtml",
  "xml"
]);
var BLOCKED_TYPE = /^(text\/html|application\/xhtml|image\/svg|application\/(x-)?javascript|text\/javascript|application\/x-msdownload|application\/xml|text\/xml)/i;
function canDownload(entry) {
  const name = String(entry?.name ?? "");
  const ext = name.includes(".") ? name.slice(name.lastIndexOf(".") + 1).toLowerCase() : "";
  return !BLOCKED_EXT.has(ext) && !BLOCKED_TYPE.test(entry?.type ?? "");
}
async function downloadToComputer(api, client, entry, { onProgress, signal } = {}) {
  if (!canDownload(entry)) throw new NcError("forbidden", { detail: "file type" });
  const bytes = await client.download(entry, { onProgress, signal });
  try {
    await api.ui.downloadFile({ content: bytes, filename: entry.name, contentType: entry.type || "application/octet-stream" });
  } catch (err) {
    throw errorFromException(err, signal);
  }
}
async function attachToNewMessage(api, client, entry, { onProgress, signal } = {}) {
  const bytes = await client.download(entry, { onProgress, signal });
  const type = entry.type || "application/octet-stream";
  let blob;
  try {
    blob = await api.jmap.uploadBlob(bytes, entry.name, type);
  } catch (err) {
    throw errorFromException(err, signal);
  }
  return api.compose.open({
    attachments: [{ blobId: blob.blobId, name: entry.name, type: blob.type || type, size: blob.size ?? bytes.byteLength }]
  });
}

// nextcloud/src/ui/files-page.js
function Uploads({ api, jobs, onResume, onCancel, onDiscard }) {
  const t = api.i18n.t;
  const locale = api.i18n.getLocale();
  if (!jobs.length) return null;
  return (0, import_react10.createElement)(
    "ul",
    { className: "nc-col", style: { listStyle: "none", margin: 0, padding: 0 }, "aria-label": t("files.upload") },
    jobs.map((job) => {
      const percent = job.total ? Math.round(job.loaded / job.total * 100) : 0;
      return (0, import_react10.createElement)(
        "li",
        { key: job.id, className: "nc-card nc-col", style: { padding: 8, gap: 6 } },
        (0, import_react10.createElement)(
          "div",
          { className: "nc-row" },
          (0, import_react10.createElement)(
            "span",
            { className: "nc-grow nc-small", role: "status" },
            job.state === "running" ? t("files.uploading", { name: job.file.name, loaded: formatSize(job.loaded, locale), total: formatSize(job.total, locale) }) : job.state === "paused" ? t("files.paused", { name: job.file.name }) : job.state === "done" ? t("files.uploaded", { name: job.file.name }) : `${job.file.name}: ${errorText(t, job.error)}`
          ),
          job.state === "running" ? (0, import_react10.createElement)("button", { type: "button", className: "nc-btn", onClick: () => onCancel(job) }, t("common.cancel")) : null,
          job.state === "paused" || job.state === "error" ? (0, import_react10.createElement)("button", { type: "button", className: "nc-btn", onClick: () => onResume(job) }, t("files.resume")) : null,
          job.state === "paused" || job.state === "error" ? (0, import_react10.createElement)("button", { type: "button", className: "nc-btn", onClick: () => onDiscard(job) }, t("files.discard")) : null
        ),
        job.state === "running" ? (0, import_react10.createElement)(
          "div",
          { className: "nc-bar", role: "progressbar", "aria-valuemin": 0, "aria-valuemax": 100, "aria-valuenow": percent, "aria-label": job.file.name },
          (0, import_react10.createElement)("span", { style: { width: `${percent}%` } })
        ) : null
      );
    })
  );
}
function Details({ api, client, entry, onError }) {
  const t = api.i18n.t;
  const locale = api.i18n.getLocale();
  const [busy, setBusy] = (0, import_react10.useState)(null);
  const [share, setShare] = (0, import_react10.useState)(null);
  const [link, setLink] = (0, import_react10.useState)("");
  const run = async (kind, fn) => {
    setBusy(kind);
    try {
      await fn();
    } catch (err) {
      onError(err);
    } finally {
      setBusy(null);
    }
  };
  if (!entry) return (0, import_react10.createElement)("p", { className: "nc-muted nc-small", style: { margin: 0 } }, t("files.selectHint"));
  return (0, import_react10.createElement)(
    "div",
    { className: "nc-card nc-col", "aria-label": entry.name },
    (0, import_react10.createElement)(
      "div",
      { className: "nc-row" },
      (0, import_react10.createElement)("strong", { className: "nc-name nc-grow" }, entry.name),
      (0, import_react10.createElement)("span", { className: "nc-meta" }, formatSize(entry.size, locale))
    ),
    (0, import_react10.createElement)(
      "div",
      { className: "nc-row" },
      canDownload(entry) ? (0, import_react10.createElement)("button", { type: "button", className: "nc-btn", disabled: !!busy, onClick: () => void run("download", () => downloadToComputer(api, client, entry)) }, t("files.download")) : null,
      (0, import_react10.createElement)("button", { type: "button", className: "nc-btn", disabled: !!busy, onClick: () => {
        setShare(defaultShareOptions(api.plugin.settings));
        setLink("");
      } }, t("files.share")),
      (0, import_react10.createElement)("button", { type: "button", className: "nc-btn", disabled: !!busy, onClick: () => void run("attach", () => attachToNewMessage(api, client, entry)) }, t("files.attachNew")),
      (0, import_react10.createElement)("button", { type: "button", className: "nc-btn", onClick: () => void api.ui.openExternalUrl(client.webUrl(entry)) }, t("files.open"))
    ),
    !canDownload(entry) ? (0, import_react10.createElement)("p", { className: "nc-muted nc-small", style: { margin: 0 } }, t("files.cantDownload")) : null,
    busy ? (0, import_react10.createElement)("p", { className: "nc-muted nc-small", role: "status", style: { margin: 0 } }, t("files.preparing", { name: entry.name })) : null,
    share && !link ? (0, import_react10.createElement)(
      "div",
      { className: "nc-col" },
      (0, import_react10.createElement)(ShareOptions, { api, client, value: share, onChange: setShare, idPrefix: "nc-page" }),
      (0, import_react10.createElement)(
        "div",
        { className: "nc-row" },
        (0, import_react10.createElement)("button", {
          type: "button",
          className: "nc-btn nc-primary",
          disabled: !!busy,
          onClick: () => void run("share", async () => {
            const created = await client.share(entry.path, { password: share.usePassword ? share.password.trim() : "", expireDate: share.expireDate });
            setLink(created.url);
          })
        }, t("files.createLink")),
        (0, import_react10.createElement)("button", { type: "button", className: "nc-btn", onClick: () => setShare(null) }, t("common.cancel"))
      )
    ) : null,
    link ? (0, import_react10.createElement)(
      "label",
      { className: "nc-label" },
      t("files.linkReady"),
      (0, import_react10.createElement)("input", { className: "nc-input", readOnly: true, value: link, onFocus: (e) => e.target.select(), "aria-label": t("files.linkLabel") })
    ) : null
  );
}
function FilesPage() {
  ensureStyles();
  const api = getApi();
  const t = api.i18n.t;
  const connection = useConnection(api);
  const client = (0, import_react10.useMemo)(() => connection.conn ? createClient(api, connection.conn) : null, [connection.conn]);
  const [path, setPath] = (0, import_react10.useState)("/");
  const [selected, setSelected] = (0, import_react10.useState)(() => /* @__PURE__ */ new Map());
  const [reloadKey, setReloadKey] = (0, import_react10.useState)(0);
  const [jobs, setJobs] = (0, import_react10.useState)([]);
  const [error, setError] = (0, import_react10.useState)(null);
  const [dragging, setDragging] = (0, import_react10.useState)(false);
  const inputRef = (0, import_react10.useRef)(null);
  const controllers = (0, import_react10.useRef)(/* @__PURE__ */ new Map());
  const report = (err) => {
    connection.report(err);
    setError(err);
  };
  const update = (id, patch) => setJobs((list) => list.map((j) => j.id === id ? { ...j, ...patch } : j));
  const runJob = async (job) => {
    const controller = new AbortController();
    controllers.current.set(job.id, controller);
    update(job.id, { state: "running", error: null });
    try {
      const target = job.target ?? await planUpload(client, job.folder, job.file.name);
      update(job.id, { target });
      await uploadFile(api, client, job.file, target, {
        signal: controller.signal,
        onProgress: (loaded, total) => update(job.id, { loaded, total })
      });
      update(job.id, { state: "done", loaded: job.file.size });
      setReloadKey((k) => k + 1);
    } catch (err) {
      if (err instanceof NcError && err.code === "cancelled") update(job.id, { state: "paused" });
      else {
        connection.report(err);
        update(job.id, { state: "error", error: err });
      }
    } finally {
      controllers.current.delete(job.id);
    }
  };
  const addFiles = (files) => {
    setError(null);
    const added = [...files].map((file) => ({ id: `${Date.now()}-${Math.random()}`, file, folder: path, state: "running", loaded: 0, total: file.size }));
    setJobs((list) => [...list.filter((j) => j.state !== "done"), ...added]);
    for (const job of added) void runJob(job);
  };
  if (connection.status !== "connected" || !client) {
    return (0, import_react10.createElement)(
      "div",
      { className: "nc", style: { padding: 16, maxWidth: 720 } },
      (0, import_react10.createElement)("h1", { style: { fontSize: 18, margin: "0 0 12px" } }, t("page.title")),
      (0, import_react10.createElement)(ConnectionPanel, { api, connection })
    );
  }
  const current = [...selected.values()][0] ?? null;
  return (0, import_react10.createElement)(
    "div",
    {
      className: "nc nc-col",
      style: { padding: 16, maxWidth: 960, outline: dragging ? "2px dashed var(--color-primary)" : "none" },
      onDragOver: (e) => {
        if (e.dataTransfer?.types?.includes("Files")) {
          e.preventDefault();
          setDragging(true);
        }
      },
      onDragLeave: () => setDragging(false),
      onDrop: (e) => {
        e.preventDefault();
        setDragging(false);
        if (e.dataTransfer?.files?.length) addFiles(e.dataTransfer.files);
      }
    },
    (0, import_react10.createElement)(
      "div",
      { className: "nc-row" },
      (0, import_react10.createElement)("h1", { className: "nc-grow", style: { fontSize: 18, margin: 0 } }, t("page.title")),
      (0, import_react10.createElement)(ConnectionPanel, { api, connection, compact: true })
    ),
    (0, import_react10.createElement)(FileBrowser, {
      api,
      client,
      mode: "manage",
      path,
      reloadKey,
      listHeight: 460,
      onNavigate: (p) => {
        setPath(p);
        setSelected(/* @__PURE__ */ new Map());
      },
      selected,
      onToggle: (entry) => setSelected((prev) => prev.has(entry.path) ? /* @__PURE__ */ new Map() : /* @__PURE__ */ new Map([[entry.path, entry]])),
      onError: report,
      toolbar: (0, import_react10.createElement)(
        "div",
        { className: "nc-row" },
        (0, import_react10.createElement)("input", {
          ref: inputRef,
          type: "file",
          multiple: true,
          style: { display: "none" },
          "aria-hidden": "true",
          tabIndex: -1,
          "data-testid": "nc-upload-input",
          onChange: (e) => {
            if (e.target.files?.length) addFiles(e.target.files);
            e.target.value = "";
          }
        }),
        (0, import_react10.createElement)("button", { type: "button", className: "nc-btn nc-primary", onClick: () => inputRef.current?.click() }, t("files.upload")),
        (0, import_react10.createElement)(NewFolder, { api, client, path, onCreated: (p) => {
          setPath(p);
          setReloadKey((k) => k + 1);
        }, onError: report }),
        (0, import_react10.createElement)("span", { className: "nc-muted nc-small nc-hide-narrow" }, t("files.uploadHint"))
      )
    }),
    (0, import_react10.createElement)(Uploads, {
      api,
      jobs,
      onCancel: (job) => controllers.current.get(job.id)?.abort(),
      onResume: (job) => void runJob(jobs.find((j) => j.id === job.id) ?? job),
      onDiscard: async (job) => {
        const latest = jobs.find((j) => j.id === job.id) ?? job;
        if (latest.target) await discardUpload(api, client, latest.file, latest.target).catch(() => {
        });
        setJobs((list) => list.filter((j) => j.id !== job.id));
      }
    }),
    error ? (0, import_react10.createElement)("p", { className: "nc-error", role: "alert", style: { margin: 0 } }, errorText(t, error)) : null,
    (0, import_react10.createElement)(Details, { api, client, entry: current && !current.isFolder ? current : null, onError: report })
  );
}

// nextcloud/src/index.js
var FIRST_RUN_KEY = "firstRunOffered";
async function offerFirstRun(api) {
  if (await api.storage.get(FIRST_RUN_KEY)) return false;
  const account = await storedAccount(api);
  await api.storage.set(FIRST_RUN_KEY, true);
  if (account?.connected) return false;
  api.toast.info(api.i18n.t("firstrun.offer"));
  return true;
}
var bg = null;
async function registerActions(api) {
  const t = api.i18n.t;
  await api.ui.setActions("attachment-menu", [{ id: "save-attachment", label: t("save.attachmentAction"), icon: "cloud-upload" }]);
  await api.ui.setActions("reader-actions", [{ id: "save-message", label: t("save.messageAction"), icon: "cloud-upload", order: 200 }]);
  await api.ui.setPages([{ id: "files", title: t("page.title"), icon: "cloud" }]);
}
async function activate(api) {
  bg = api;
  setApi(api);
  await registerActions(api).catch((err) => api.log.warn("setActions failed", err));
  api.i18n.onLocaleChange(() => {
    void registerActions(api).catch(() => {
    });
  });
  await offerFirstRun(api).catch(() => {
  });
}
async function onAction(api, { surface, actionId, context } = {}) {
  const t = api.i18n.t;
  let props;
  if (surface === "attachment-menu" && actionId === "save-attachment") {
    if (!context?.emailId || !context?.blobId) return;
    props = { kind: "attachment", emailId: context.emailId, blobId: context.blobId, name: context.name || "attachment", size: Number(context.size) || 0 };
  } else if (surface === "reader-actions" && actionId === "save-message") {
    if (!context?.emailId) return;
    const email = await api.email.get(context.emailId).catch(() => null);
    props = { kind: "message", emailId: context.emailId, name: emlName(email?.subject), size: 0 };
  } else {
    return;
  }
  const title = props.kind === "message" ? t("save.titleMessage") : t("save.titleAttachment", { name: props.name });
  const result = await api.ui.openDialog({ title, slot: "plugin-dialog", extraProps: { view: "save", ...props }, width: 640 });
  if (result && typeof result.path === "string") api.toast.success(t("save.saved", { path: result.path }));
}
async function addLinksToMessage(api, outgoing) {
  const links = await getPending(api.storage);
  if (!links.length) return void 0;
  const next = appendLinks(outgoing, linkBlock(api.i18n.t, links, api.i18n.getLocale()));
  await clearPending(api.storage);
  return next;
}
var MB = 1024 * 1024;
async function offerLargeUpload(api, payload) {
  const fileId = typeof payload === "string" ? payload : payload?.fileId;
  if (typeof fileId !== "string" || !fileId) return void 0;
  const settings = api.plugin.settings ?? {};
  if (settings.offerLargeUpload === false) return void 0;
  const account = await storedAccount(api);
  if (!account?.connected) return void 0;
  const file = await api.upfiles.get(fileId);
  if (!file) return void 0;
  const threshold = Math.max(1, Number(settings.largeFileMb) || 10) * MB;
  if (file.size < threshold) return void 0;
  const result = await api.ui.openDialog({
    title: api.i18n.t("offload.title"),
    slot: "plugin-dialog",
    extraProps: { view: "offload", fileId, name: file.name, size: file.size },
    width: 560
  });
  if (result && result.externalAttachment === true && typeof result.html === "string" && typeof result.text === "string") {
    return { externalAttachment: true, html: result.html, text: result.text, fileId };
  }
  return void 0;
}
var hooks = {
  onAction: (payload) => bg ? onAction(bg, payload) : void 0,
  onBeforeBlobUpload: (payload) => bg ? offerLargeUpload(bg, payload) : void 0,
  onTransformOutgoingEmail: (outgoing) => bg ? addLinksToMessage(bg, outgoing) : void 0,
  // Links picked for a message that was then discarded don't carry over to the next one.
  onComposerClose: () => bg ? clearPending(bg.storage) : void 0
};
var slots = {
  "settings-section": { component: SettingsSection },
  "composer-attachment-source": { component: ComposerSource, order: 50 },
  "plugin-dialog": { component: PluginDialog },
  "app-page": { component: FilesPage }
};
