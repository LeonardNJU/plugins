var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// nextcloud/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  addLinksToMessage: () => addLinksToMessage,
  attachFromNextcloud: () => attachFromNextcloud,
  hooks: () => hooks,
  offerFirstRun: () => offerFirstRun,
  offerLargeUpload: () => offerLargeUpload,
  onAction: () => onAction,
  registerActions: () => registerActions,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);

// nextcloud/src/lib/host.js
var hostApi = null;
function getApi() {
  if (!hostApi && typeof require === "function") {
    hostApi = require("@plugin-host");
  }
  return hostApi;
}
function setApi(api) {
  hostApi = api;
}

// nextcloud/src/lib/errors.js
var NcError = class extends Error {
  /**
   * @param {string} code one of ERROR_CODES
   * @param {{ status?: number, detail?: string }} [info]
   */
  constructor(code, info = {}) {
    super(info.detail ? `${code}: ${info.detail}` : code);
    this.name = "NcError";
    this.code = code;
    this.status = info.status ?? 0;
    this.detail = info.detail ?? "";
  }
};
var ERROR_CODES = [
  "not_connected",
  "auth",
  "forbidden",
  "share_forbidden",
  "not_found",
  "exists",
  "quota",
  "too_large",
  "locked",
  "rate_limited",
  "timeout",
  "unreachable",
  "blocked",
  "maintenance",
  "server",
  "cancelled",
  "wrong_server",
  "login_expired",
  "bad_answer",
  "rejected",
  "attach_refused",
  "mail_rate_limited",
  "mail_upload",
  "unknown"
];
var PROXY_CODES = {
  no_credential: "not_connected",
  rate_limited: "rate_limited",
  timeout: "timeout",
  unreachable: "unreachable",
  blocked_address: "blocked",
  wrong_origin: "blocked",
  redirect_off_origin: "blocked",
  too_large: "too_large"
};
function ocsMessage(body) {
  let data = body;
  if (typeof data === "string") {
    try {
      data = JSON.parse(data);
    } catch {
      return "";
    }
  }
  const message = data?.ocs?.meta?.message;
  return typeof message === "string" && message !== "OK" ? message : "";
}
function davMessage(body) {
  if (typeof body !== "string") return "";
  const m = /<(?:[\w.-]+:)?message>([^<]{1,300})<\//.exec(body);
  return m ? m[1].trim() : "";
}
function errorFromResponse(res, { kind } = {}) {
  if (!res || typeof res !== "object") return new NcError("unknown");
  if (res.proxyError) {
    return new NcError(PROXY_CODES[res.proxyError] ?? "unknown", { status: res.status, detail: typeof res.body === "string" ? res.body : "" });
  }
  if (res.ok) return null;
  const status = Number(res.status) || 0;
  const detail = ocsMessage(res.body) || davMessage(res.body);
  const info = { status, detail };
  if (status === 400 && detail) return new NcError("rejected", info);
  if (status === 401) return new NcError("auth", info);
  if (status === 403) return new NcError(kind === "share" ? "share_forbidden" : "forbidden", info);
  if (status === 404) return new NcError("not_found", info);
  if (status === 405 || status === 412) return new NcError("exists", info);
  if (status === 413) return new NcError("too_large", info);
  if (status === 423) return new NcError("locked", info);
  if (status === 429) return new NcError("rate_limited", info);
  if (status === 503) return new NcError("maintenance", info);
  if (status === 507) return new NcError("quota", info);
  if (status === 504 || status === 408) return new NcError("timeout", info);
  if (status >= 500) return new NcError("server", info);
  return new NcError("unknown", info);
}
function errorFromException(err, signal) {
  if (err instanceof NcError) return err;
  if (signal?.aborted) return new NcError("cancelled");
  const message = String(err?.message ?? err ?? "");
  if (/cancel|abort/i.test(message)) return new NcError("cancelled");
  if (/timed out/i.test(message)) return new NcError("timeout");
  if (/larger than/i.test(message)) return new NcError("too_large");
  if (/at most \d+ proxy requests|rate.?limit|too many requests/i.test(message)) return new NcError("rate_limited");
  if (/network/i.test(message)) return new NcError("unreachable");
  return new NcError("unknown", { detail: message.slice(0, 200) });
}
function mailError(err, signal) {
  if (signal?.aborted) return new NcError("cancelled");
  const message = String(err?.message ?? err ?? "");
  if (/rate.?limit|too many requests|429/i.test(message)) return new NcError("mail_rate_limited");
  if (/larger than|too large|413/i.test(message)) return new NcError("too_large");
  return new NcError("mail_upload", { detail: message.slice(0, 200) });
}
function needsSignIn(err) {
  return err instanceof NcError && (err.code === "auth" || err.code === "not_connected" || err.code === "wrong_server");
}
function errorText(t, err) {
  const e = err instanceof NcError ? err : errorFromException(err);
  const text = t(`error.${ERROR_CODES.includes(e.code) ? e.code : "unknown"}`);
  const withDetail = ["forbidden", "share_forbidden", "rejected", "unknown", "bad_answer", "mail_upload"].includes(e.code) && e.detail;
  return withDetail ? `${text} (${e.detail})` : text;
}

// nextcloud/src/lib/paths.js
function normalizePath(path) {
  const out = [];
  for (const part of String(path ?? "").split("/")) {
    if (!part || part === ".") continue;
    if (part === "..") {
      out.pop();
      continue;
    }
    out.push(part);
  }
  return "/" + out.join("/");
}
function joinPath(...parts) {
  return normalizePath(parts.map((p) => String(p ?? "")).join("/"));
}
function parentPath(path) {
  const p = normalizePath(path);
  if (p === "/") return "/";
  return p.slice(0, p.lastIndexOf("/")) || "/";
}
function baseName(path) {
  const p = normalizePath(path);
  return p === "/" ? "" : p.slice(p.lastIndexOf("/") + 1);
}
function breadcrumb(path) {
  const p = normalizePath(path);
  const crumbs = [{ name: "", path: "/" }];
  if (p === "/") return crumbs;
  let acc = "";
  for (const part of p.slice(1).split("/")) {
    acc += "/" + part;
    crumbs.push({ name: part, path: acc });
  }
  return crumbs;
}
function encodePath(path) {
  return normalizePath(path).split("/").map((s) => encodeURIComponent(s)).join("/");
}
function davFilesUrl(origin, userId, path) {
  const p = normalizePath(path);
  return `${origin}/remote.php/dav/files/${encodeURIComponent(userId)}${p === "/" ? "/" : encodePath(p)}`;
}
function davUploadsUrl(origin, userId, uploadId, chunk) {
  const base = `${origin}/remote.php/dav/uploads/${encodeURIComponent(userId)}/${encodeURIComponent(uploadId)}`;
  return chunk === void 0 ? base : `${base}/${encodeURIComponent(chunk)}`;
}
function hrefToPath(href, userId) {
  let pathname = String(href ?? "");
  try {
    pathname = new URL(pathname, "http://x").pathname;
  } catch {
    return null;
  }
  const marker = `/remote.php/dav/files/${encodeURIComponent(userId)}`;
  let i = pathname.indexOf(marker);
  let rest;
  if (i >= 0) rest = pathname.slice(i + marker.length);
  else {
    const plain = `/remote.php/dav/files/${userId}`;
    i = pathname.indexOf(plain);
    if (i < 0) return null;
    rest = pathname.slice(i + plain.length);
  }
  if (rest && !rest.startsWith("/")) return null;
  try {
    return normalizePath(rest.split("/").map((s) => decodeURIComponent(s)).join("/"));
  } catch {
    return null;
  }
}
function sanitizeFileName(name, fallback = "file") {
  const cleaned = String(name ?? "").replace(/[\u0000-\u001f\u007f]/g, "").replace(/[\\/]/g, "_").replace(/[:*?"<>|]/g, "_").trim().replace(/^\.+/, "").slice(0, 200).trim();
  return cleaned || fallback;
}
function uniqueName(name, taken) {
  const used = new Set([...taken ?? []].map((n) => String(n).toLowerCase()));
  if (!used.has(name.toLowerCase())) return name;
  const dot = name.lastIndexOf(".");
  const stem = dot > 0 ? name.slice(0, dot) : name;
  const ext = dot > 0 ? name.slice(dot) : "";
  for (let n = 2; n < 1e4; n++) {
    const candidate = `${stem} (${n})${ext}`;
    if (!used.has(candidate.toLowerCase())) return candidate;
  }
  return `${stem} (${Date.now()})${ext}`;
}
function uploadFolder(base, layout, date = /* @__PURE__ */ new Date()) {
  const root = normalizePath(base || "Mail attachments");
  if (layout !== "date") return root;
  const day = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  return joinPath(root, day);
}
function originOf(value) {
  const raw = String(value ?? "").trim();
  if (!raw) return null;
  const withScheme = /^[a-z][a-z0-9+.-]*:\/\//i.test(raw) ? raw : `https://${raw}`;
  try {
    const url = new URL(withScheme);
    if (url.protocol !== "https:" && url.protocol !== "http:") return null;
    return url.origin;
  } catch {
    return null;
  }
}

// nextcloud/src/lib/webdav.js
var PROPS = `<d:prop>
  <d:displayname/><d:getcontentlength/><d:getcontenttype/><d:getlastmodified/><d:resourcetype/><d:getetag/>
  <oc:fileid/><oc:size/><oc:permissions/>
</d:prop>`;
var NS = 'xmlns:d="DAV:" xmlns:oc="http://owncloud.org/ns" xmlns:nc="http://nextcloud.org/ns"';
var PROPFIND_BODY = `<?xml version="1.0" encoding="UTF-8"?>
<d:propfind ${NS}>${PROPS}</d:propfind>`;
function xmlEscape(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function likePattern(text) {
  return `%${String(text).replace(/[\\%_]/g, (c) => `\\${c}`)}%`;
}
function searchBody({ userId, query = "", recent = false, limit = 50 }) {
  const where = recent ? "<d:not><d:is-collection/></d:not>" : `<d:like><d:prop><d:displayname/></d:prop><d:literal>${xmlEscape(likePattern(query))}</d:literal></d:like>`;
  return `<?xml version="1.0" encoding="UTF-8"?>
<d:searchrequest ${NS}>
<d:basicsearch>
<d:select>${PROPS}</d:select>
<d:from><d:scope><d:href>/files/${xmlEscape(userId)}</d:href><d:depth>infinity</d:depth></d:scope></d:from>
<d:where>${where}</d:where>
<d:orderby><d:order><d:prop><d:getlastmodified/></d:prop><d:descending/></d:order></d:orderby>
<d:limit><d:nresults>${Math.max(1, Math.min(200, Number(limit) || 50))}</d:nresults></d:limit>
</d:basicsearch>
</d:searchrequest>`;
}
var ENTITIES = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'" };
function decodeXml(s) {
  return String(s).replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1").replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e) => {
    if (e[0] === "#") {
      const code = e[1] === "x" || e[1] === "X" ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      return Number.isFinite(code) ? String.fromCodePoint(code) : m;
    }
    return ENTITIES[e.toLowerCase()] ?? m;
  });
}
function blocks(xml, local) {
  const re = new RegExp(`<([A-Za-z][\\w.-]*:)?${local}\\b[^>]*>([\\s\\S]*?)</\\1${local}>`, "g");
  const out = [];
  let m;
  while (m = re.exec(xml)) out.push(m[2]);
  return out;
}
function first(xml, local) {
  return blocks(xml, local)[0];
}
function parseProps(xml) {
  const props = {};
  const re = /<(?:[A-Za-z][\w.-]*:)?([A-Za-z][\w.-]*)\b[^>]*?(?:\/>|>([\s\S]*?)<\/(?:[A-Za-z][\w.-]*:)?\1>)/g;
  let m;
  while (m = re.exec(xml)) {
    const [, name, inner] = m;
    props[name] = inner === void 0 ? "" : inner;
  }
  return props;
}
function parseMultistatus(xml) {
  const out = [];
  for (const response of blocks(String(xml ?? ""), "response")) {
    const href = decodeXml((first(response, "href") ?? "").trim());
    const props = {};
    for (const propstat of blocks(response, "propstat")) {
      const status = first(propstat, "status") ?? "";
      if (!/\s2\d\d\b/.test(status)) continue;
      const prop = first(propstat, "prop");
      if (prop !== void 0) Object.assign(props, parseProps(prop));
    }
    out.push({ href, props });
  }
  return out;
}
function toEntry({ href, props }, userId) {
  const path = hrefToPath(href, userId);
  if (path === null) return null;
  const isFolder = /<(?:[\w.-]+:)?collection\b/.test(props.resourcetype ?? "");
  const sizeRaw = props.size ?? props.getcontentlength;
  const size = Number(sizeRaw);
  const modified = Date.parse(decodeXml(props.getlastmodified ?? ""));
  const displayName = decodeXml(props.displayname ?? "").trim();
  return {
    path,
    name: baseName(path) || displayName || "",
    isFolder,
    size: Number.isFinite(size) && sizeRaw !== "" ? size : 0,
    type: isFolder ? "" : decodeXml(props.getcontenttype ?? "") || "application/octet-stream",
    modified: Number.isFinite(modified) ? modified : 0,
    fileId: props.fileid ? decodeXml(props.fileid) : "",
    permissions: props.permissions ? decodeXml(props.permissions) : "",
    etag: props.getetag ? decodeXml(props.getetag).replace(/"/g, "") : ""
  };
}
function sortEntries(entries, locale) {
  const collator = new Intl.Collator(locale || void 0, { numeric: true, sensitivity: "base" });
  return [...entries].sort((a, b) => a.isFolder === b.isFolder ? collator.compare(a.name, b.name) : a.isFolder ? -1 : 1);
}

// nextcloud/src/lib/client.js
var CREDENTIAL = "nextcloud";
var BUFFERED_LIMIT = 24 * 1024 * 1024;
var OCS_HEADERS = { "OCS-APIRequest": "true", Accept: "application/json" };
async function ncRequest(api, url, init = {}, { kind, accept = [] } = {}) {
  let res;
  try {
    res = await api.proxy.fetch(CREDENTIAL, url, init);
  } catch (err2) {
    throw errorFromException(err2, init.signal);
  }
  if (init.signal?.aborted) throw new NcError("cancelled");
  if (res && accept.includes(res.status) && !res.proxyError) return res;
  const err = errorFromResponse(res, { kind });
  if (err) throw err;
  return res;
}
function parseJson(body) {
  if (body && typeof body === "object") return body;
  try {
    return JSON.parse(String(body ?? ""));
  } catch {
    throw new NcError("bad_answer");
  }
}
async function ocs(api, origin, path, init = {}, opts = {}) {
  const sep = path.includes("?") ? "&" : "?";
  const res = await ncRequest(api, `${origin}${path}${sep}format=json`, {
    ...init,
    headers: { ...OCS_HEADERS, ...init.headers ?? {} },
    responseType: "text"
  }, opts);
  return parseJson(res.body)?.ocs?.data;
}
function createClient(api, conn) {
  const { origin, userId } = conn;
  const fileUrl = (path) => davFilesUrl(origin, userId, path);
  async function propfind(path, depth = 1) {
    const res = await ncRequest(api, fileUrl(path), {
      method: "PROPFIND",
      headers: { Depth: String(depth), "Content-Type": "application/xml; charset=utf-8" },
      body: PROPFIND_BODY,
      responseType: "text"
    });
    return parseMultistatus(res.body).map((r) => toEntry(r, userId)).filter(Boolean);
  }
  const client = {
    origin,
    userId,
    /** The files and folders in `path`, folders first. */
    async list(path, locale) {
      const self = normalizePath(path);
      const entries = await propfind(self, 1);
      return sortEntries(entries.filter((e) => e.path !== self), locale);
    },
    /** One file or folder, or null when there is none. */
    async stat(path) {
      try {
        const [entry] = await propfind(path, 0);
        return entry ?? null;
      } catch (err) {
        if (err instanceof NcError && err.code === "not_found") return null;
        throw err;
      }
    },
    async search(query, { limit = 50, signal } = {}) {
      const q = String(query ?? "").trim();
      if (!q) return [];
      return runSearch({ query: q, limit, signal });
    },
    async recent({ limit = 50, signal } = {}) {
      return runSearch({ recent: true, limit, signal });
    },
    /** Create a folder; an existing one is fine. */
    async mkdir(path) {
      await ncRequest(api, fileUrl(path), { method: "MKCOL" }, { accept: [405] });
    },
    /** Create a folder and its parents. */
    async mkdirp(path) {
      const p = normalizePath(path);
      if (p === "/") return;
      if (await client.stat(p)) return;
      await client.mkdirp(parentPath(p));
      await client.mkdir(p);
    },
    /** Names taken in a folder (for picking a free name). */
    async names(path) {
      try {
        return (await client.list(path)).map((e) => e.name);
      } catch (err) {
        if (err instanceof NcError && err.code === "not_found") return [];
        throw err;
      }
    },
    /** The bytes of a file. Large files come in as a stream. */
    async download(entry, { onProgress, signal } = {}) {
      const size = Number(entry.size) || 0;
      if (size <= BUFFERED_LIMIT) {
        const res2 = await ncRequest(api, fileUrl(entry.path), { method: "GET", responseType: "arraybuffer", signal });
        const bytes = new Uint8Array(res2.body);
        onProgress?.(bytes.byteLength, bytes.byteLength);
        return bytes;
      }
      const res = await ncRequest(api, fileUrl(entry.path), { method: "GET", responseType: "stream", signal });
      const reader = res.body.getReader();
      const parts = [];
      let loaded = 0;
      try {
        for (; ; ) {
          const { done, value } = await reader.read();
          if (done) break;
          parts.push(value);
          loaded += value.byteLength;
          onProgress?.(loaded, size);
        }
      } catch (err) {
        throw errorFromException(err, signal);
      }
      const out = new Uint8Array(loaded);
      let offset = 0;
      for (const p of parts) {
        out.set(p, offset);
        offset += p.byteLength;
      }
      return out;
    },
    /** Upload in one request (small files). */
    async put(path, body, { contentType, onProgress, signal } = {}) {
      await ncRequest(api, fileUrl(path), {
        method: "PUT",
        headers: { "Content-Type": contentType || "application/octet-stream" },
        body,
        onProgress,
        signal
      });
    },
    async remove(path) {
      await ncRequest(api, fileUrl(path), { method: "DELETE" });
    },
    /**
     * A public, read-only share link. `password` and `expireDate`
     * (YYYY-MM-DD) are optional.
     */
    async share(path, { password, expireDate } = {}) {
      const form = new URLSearchParams();
      form.set("path", normalizePath(path));
      form.set("shareType", "3");
      form.set("permissions", "1");
      if (password) form.set("password", password);
      if (expireDate) form.set("expireDate", expireDate);
      const data = await ocs(api, origin, "/ocs/v2.php/apps/files_sharing/api/v1/shares", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: form.toString()
      }, { kind: "share" });
      const url = data?.url;
      if (typeof url !== "string" || !/^https?:\/\//.test(url)) throw new NcError("bad_answer");
      return { id: String(data.id ?? ""), url, password: password || "", expireDate: expireDate || "", name: baseName(path) };
    },
    /** A password that meets the server's password rules. */
    async generatePassword() {
      try {
        const data = await ocs(api, origin, "/ocs/v2.php/apps/password_policy/api/v1/generate");
        if (typeof data?.password === "string" && data.password) return data.password;
      } catch {
      }
      return localPassword();
    },
    /** Where to open a file in the Nextcloud web interface. */
    webUrl(entry) {
      if (entry.fileId) return `${origin}/f/${encodeURIComponent(entry.fileId)}`;
      const dir = entry.isFolder ? entry.path : parentPath(entry.path);
      return `${origin}/apps/files/?dir=${encodeURIComponent(dir)}`;
    },
    joinPath
  };
  async function runSearch({ query, recent, limit, signal }) {
    const res = await ncRequest(api, `${origin}/remote.php/dav/`, {
      method: "SEARCH",
      headers: { "Content-Type": "text/xml; charset=utf-8" },
      body: searchBody({ userId, query, recent, limit }),
      responseType: "text",
      signal
    });
    return parseMultistatus(res.body).map((r) => toEntry(r, userId)).filter((e) => e && e.path !== "/");
  }
  return client;
}
var ALPHABETS = ["ABCDEFGHJKLMNPQRSTUVWXYZ", "abcdefghijkmnopqrstuvwxyz", "23456789", "-_+!#"];
function localPassword(random = defaultRandom) {
  const all = ALPHABETS.join("");
  const chars = ALPHABETS.map((set) => set[random(set.length)]);
  while (chars.length < 20) chars.push(all[random(all.length)]);
  for (let i = chars.length - 1; i > 0; i--) {
    const j = random(i + 1);
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  return chars.join("");
}
function defaultRandom(n) {
  const buf = new Uint32Array(1);
  globalThis.crypto.getRandomValues(buf);
  return buf[0] % n;
}

// nextcloud/src/lib/connection.js
var POLL_INTERVAL_MS = 2e3;
var POLL_TIMEOUT_MS = 20 * 60 * 1e3;
async function adminServer(api) {
  try {
    const config = await api.config.get();
    return originOf(config?.serverUrl) ?? null;
  } catch {
    return null;
  }
}
async function storedAccount(api) {
  let list;
  try {
    list = await api.proxy.accounts();
  } catch {
    return null;
  }
  const account = Array.isArray(list) ? list.find((a) => a.credentialId === CREDENTIAL) : null;
  return account ?? null;
}
function userKey(origin, username) {
  return `user:${origin}:${username ?? ""}`;
}
async function getConnection(api, { fixedServer } = {}) {
  const account = await storedAccount(api);
  if (!account || !account.connected) return null;
  const fixed = fixedServer === void 0 ? await adminServer(api) : fixedServer;
  if (fixed && account.origin !== fixed) throw new NcError("wrong_server");
  const key = userKey(account.origin, account.username);
  const cached = await api.storage.get(key);
  if (cached && typeof cached.userId === "string" && cached.userId) {
    return { origin: account.origin, username: account.username ?? "", userId: cached.userId, displayName: cached.displayName ?? "" };
  }
  const data = await ocs(api, account.origin, "/ocs/v2.php/cloud/user");
  const userId = typeof data?.id === "string" && data.id ? data.id : account.username;
  if (!userId) throw new NcError("bad_answer");
  const displayName = typeof data?.displayname === "string" ? data.displayname : data?.["display-name"] ?? "";
  await api.storage.set(key, { userId, displayName });
  return { origin: account.origin, username: account.username ?? "", userId, displayName };
}
async function approveServer(api, { fixedServer, suggestedServer } = {}) {
  const server = fixedServer || suggestedServer || void 0;
  const result = await api.proxy.connect(CREDENTIAL, { mode: "signin", ...server ? { server } : {} });
  const origin = result?.origin ? originOf(result.origin) : null;
  if (!origin) return null;
  if (fixedServer && origin !== fixedServer) {
    await api.proxy.disconnect(CREDENTIAL).catch(() => {
    });
    throw new NcError("wrong_server");
  }
  return origin;
}
async function startLoginFlow(api, origin) {
  const res = await ncRequest(api, `${origin}/index.php/login/v2`, { method: "POST", responseType: "text" });
  let data;
  try {
    data = JSON.parse(String(res.body));
  } catch {
    throw new NcError("bad_answer", { detail: "login/v2" });
  }
  const loginUrl = data?.login;
  const endpoint = data?.poll?.endpoint;
  const token = data?.poll?.token;
  if (typeof loginUrl !== "string" || typeof endpoint !== "string" || typeof token !== "string" || !token) {
    throw new NcError("bad_answer", { detail: "login/v2" });
  }
  if (originOf(loginUrl) === null) throw new NcError("bad_answer", { detail: "login url" });
  if (originOf(endpoint) !== origin) throw new NcError("blocked", { detail: endpoint });
  return { loginUrl, endpoint, token };
}
var sleepFor = (ms, signal) => new Promise((resolve, reject) => {
  const timer = setTimeout(resolve, ms);
  signal?.addEventListener("abort", () => {
    clearTimeout(timer);
    reject(new NcError("cancelled"));
  }, { once: true });
});
async function pollLoginFlow(api, { endpoint, token }, { signal, intervalMs = POLL_INTERVAL_MS, timeoutMs = POLL_TIMEOUT_MS, sleep = sleepFor, now = Date.now } = {}) {
  const started = now();
  for (; ; ) {
    if (signal?.aborted) throw new NcError("cancelled");
    const res = await ncRequest(api, endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: `token=${encodeURIComponent(token)}`,
      responseType: "json",
      capture: { secret: "appPassword", username: "loginName" },
      signal
    }, { accept: [404] });
    if (res.status === 200) {
      if (res.body?.captured) return true;
      throw new NcError("bad_answer", { detail: "no app password" });
    }
    if (now() - started > timeoutMs) throw new NcError("login_expired");
    await sleep(intervalMs, signal);
  }
}
async function disconnect(api) {
  const account = await storedAccount(api);
  if (account?.connected) {
    await ocs(api, account.origin, "/ocs/v2.php/core/apppassword", { method: "DELETE" }).catch(() => {
    });
  }
  if (account) await api.storage.remove(userKey(account.origin, account.username)).catch(() => {
  });
  await api.proxy.disconnect(CREDENTIAL);
}

// nextcloud/src/lib/chunked.js
var CHUNK_SIZE = 10 * 1024 * 1024;
var UPLOADS_KEY = "uploads";
var RETRYABLE = /* @__PURE__ */ new Set(["unreachable", "timeout", "server", "maintenance", "rate_limited"]);
function resumeKey(destPath, file) {
  return `${destPath}|${file.size}|${file.lastModified ?? 0}|${file.name ?? ""}`;
}
function newUploadId() {
  return `bulwark-${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36)}`;
}
function chunkName(index) {
  return String(index + 1).padStart(5, "0");
}
async function listChunks(api, conn, uploadId) {
  let res;
  try {
    res = await ncRequest(api, davUploadsUrl(conn.origin, conn.userId, uploadId), {
      method: "PROPFIND",
      headers: { Depth: "1", "Content-Type": "application/xml; charset=utf-8" },
      body: '<?xml version="1.0"?><d:propfind xmlns:d="DAV:"><d:prop><d:getcontentlength/><d:resourcetype/></d:prop></d:propfind>',
      responseType: "text"
    });
  } catch (err) {
    if (err instanceof NcError && err.code === "not_found") return null;
    throw err;
  }
  const chunks = /* @__PURE__ */ new Map();
  for (const { href, props } of parseMultistatus(res.body)) {
    const name = decodeURIComponent(href.replace(/\/+$/, "").split("/").pop() ?? "");
    if (!/^\d{1,5}$/.test(name)) continue;
    chunks.set(name.padStart(5, "0"), Number(decodeXml(props.getcontentlength ?? "0")) || 0);
  }
  return chunks;
}
async function withRetry(fn, { retries, signal, wait }) {
  for (let attempt = 0; ; attempt++) {
    try {
      return await fn();
    } catch (err) {
      if (signal?.aborted) throw new NcError("cancelled");
      if (!(err instanceof NcError) || !RETRYABLE.has(err.code) || attempt >= retries) throw err;
      await wait(1e3 * (attempt + 1));
    }
  }
}
async function uploadFile(api, conn, file, destPath, {
  onProgress,
  signal,
  chunkSize = CHUNK_SIZE,
  retries = 2,
  wait = (ms) => new Promise((r) => setTimeout(r, ms))
} = {}) {
  const size = file.size;
  const destUrl = davFilesUrl(conn.origin, conn.userId, destPath);
  if (size <= chunkSize) {
    await withRetry(() => ncRequest(api, destUrl, {
      method: "PUT",
      headers: { "Content-Type": file.type || "application/octet-stream" },
      body: file,
      onProgress,
      signal
    }), { retries, signal, wait });
    onProgress?.(size, size);
    return { path: destPath, chunked: false, resumed: false };
  }
  const key = resumeKey(destPath, file);
  const saved = await api.storage.get(UPLOADS_KEY) ?? {};
  let record = saved[key] ?? null;
  let have = /* @__PURE__ */ new Map();
  if (record) {
    const listed = await listChunks(api, conn, record.id);
    if (listed) have = listed;
    else record = null;
  }
  const resumed = !!record;
  if (!record) {
    record = { id: newUploadId(), startedAt: Date.now() };
    await ncRequest(api, davUploadsUrl(conn.origin, conn.userId, record.id), {
      method: "MKCOL",
      headers: { Destination: destUrl },
      signal
    });
    await api.storage.set(UPLOADS_KEY, { ...saved, [key]: record });
  }
  const count = Math.ceil(size / chunkSize);
  let sent = 0;
  for (let i = 0; i < count; i++) {
    const start = i * chunkSize;
    const end = Math.min(size, start + chunkSize);
    if (have.get(chunkName(i)) === end - start) sent += end - start;
  }
  onProgress?.(sent, size);
  for (let i = 0; i < count; i++) {
    if (signal?.aborted) throw new NcError("cancelled");
    const start = i * chunkSize;
    const end = Math.min(size, start + chunkSize);
    const name = chunkName(i);
    if (have.get(name) === end - start) continue;
    const base = sent;
    await withRetry(() => ncRequest(api, davUploadsUrl(conn.origin, conn.userId, record.id, name), {
      method: "PUT",
      headers: { Destination: destUrl, "OC-Total-Length": String(size), "Content-Type": "application/octet-stream" },
      body: file.slice(start, end),
      onProgress: (loaded) => onProgress?.(base + loaded, size),
      signal
    }), { retries, signal, wait });
    sent += end - start;
    onProgress?.(sent, size);
  }
  await withRetry(() => ncRequest(api, davUploadsUrl(conn.origin, conn.userId, record.id, ".file"), {
    method: "MOVE",
    headers: { Destination: destUrl, "OC-Total-Length": String(size) },
    signal
  }), { retries, signal, wait });
  const after = await api.storage.get(UPLOADS_KEY) ?? {};
  delete after[key];
  await api.storage.set(UPLOADS_KEY, after);
  return { path: destPath, chunked: true, resumed };
}
async function discardUpload(api, conn, file, destPath) {
  const key = resumeKey(destPath, file);
  const saved = await api.storage.get(UPLOADS_KEY) ?? {};
  const record = saved[key];
  if (!record) return false;
  await ncRequest(api, davUploadsUrl(conn.origin, conn.userId, record.id), { method: "DELETE" }, { accept: [404] }).catch(() => {
  });
  delete saved[key];
  await api.storage.set(UPLOADS_KEY, saved);
  return true;
}

// nextcloud/src/lib/save.js
var SAVE_FOLDER_KEY = "saveFolder";
async function planUpload(client, folder, name) {
  await client.mkdirp(folder);
  const taken = await client.names(folder);
  return joinPath(folder, uniqueName(sanitizeFileName(name), taken));
}
function emlName(subject) {
  const base = sanitizeFileName(String(subject ?? "").replace(/\s+/g, " ").trim().slice(0, 120), "message");
  return `${base}.eml`;
}
async function saveAttachment(api, client, { emailId, blobId, name }, folder, { onProgress, signal } = {}) {
  const data = await api.email.getAttachment(emailId, blobId);
  const blob = new Blob([data.data], { type: data.type || "application/octet-stream" });
  const path = await planUpload(client, folder, name || data.name || "attachment");
  await uploadFile(api, client, Object.assign(blob, { name: data.name }), path, { onProgress, signal });
  return path;
}
async function saveMessage(api, client, { emailId, name }, folder, { onProgress, signal } = {}) {
  const raw = await api.email.getRaw(emailId);
  const blob = new Blob([raw], { type: "message/rfc822" });
  const path = await planUpload(client, folder, name || "message.eml");
  await uploadFile(api, client, blob, path, { onProgress, signal });
  return path;
}

// nextcloud/src/lib/format.js
var UNITS = ["B", "KB", "MB", "GB", "TB"];
function formatSize(bytes, locale) {
  let n = Number(bytes) || 0;
  let unit = 0;
  while (n >= 1024 && unit < UNITS.length - 1) {
    n /= 1024;
    unit++;
  }
  const digits = unit === 0 || n >= 100 ? 0 : 1;
  let text;
  try {
    text = new Intl.NumberFormat(locale || void 0, { maximumFractionDigits: digits }).format(n);
  } catch {
    text = n.toFixed(digits);
  }
  return `${text} ${UNITS[unit]}`;
}
function formatDate(ms, locale) {
  if (!ms) return "";
  try {
    return new Intl.DateTimeFormat(locale || void 0, { dateStyle: "medium" }).format(new Date(ms));
  } catch {
    return new Date(ms).toISOString().slice(0, 10);
  }
}
function dateInDays(days, now = /* @__PURE__ */ new Date()) {
  const n = Math.floor(Number(days) || 0);
  if (n <= 0) return "";
  const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() + n);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function hostOf(origin) {
  try {
    return new URL(origin).host;
  } catch {
    return String(origin ?? "");
  }
}

// nextcloud/src/lib/links.js
var PENDING_KEY = "pendingLinks";
var MAX_PENDING = 50;
function escapeHtml(s) {
  return String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
function safeUrl(url) {
  const s = String(url ?? "");
  return /^https?:\/\//i.test(s) ? s : "";
}
function details(t, link, locale) {
  const parts = [];
  if (link.size) parts.push(formatSize(link.size, locale));
  if (link.password && link.includePassword) parts.push(t("links.password", { password: link.password }));
  if (link.expireDate) parts.push(t("links.until", { date: link.expireDate }));
  return parts;
}
function linkBlock(t, links, locale) {
  const usable = (links ?? []).filter((l) => safeUrl(l.url));
  if (usable.length === 0) return { html: "", text: "" };
  const title = t("links.title");
  const items = usable.map((l) => {
    const extra = details(t, l, locale);
    return `<li><a href="${escapeHtml(safeUrl(l.url))}">${escapeHtml(l.name || l.url)}</a>${extra.length ? ` (${escapeHtml(extra.join(", "))})` : ""}</li>`;
  }).join("");
  const html = `<div class="nextcloud-links"><p><strong>${escapeHtml(title)}</strong></p><ul>${items}</ul></div>`;
  const lines = usable.map((l) => {
    const extra = details(t, l, locale);
    return `- ${l.name || l.url}: ${safeUrl(l.url)}${extra.length ? ` (${extra.join(", ")})` : ""}`;
  });
  return { html, text: `

${title}
${lines.join("\n")}
` };
}
function appendLinks(outgoing, block) {
  if (!block.html && !block.text) return outgoing;
  const next = { ...outgoing };
  if (outgoing.htmlBody) next.htmlBody = outgoing.htmlBody + block.html;
  if (outgoing.textBody || !outgoing.htmlBody) next.textBody = (outgoing.textBody || "") + block.text;
  return next;
}
async function getPending(storage) {
  const value = await storage.get(PENDING_KEY);
  return Array.isArray(value) ? value : [];
}
async function addPending(storage, links) {
  const current = await getPending(storage);
  const next = [...current, ...links].slice(-MAX_PENDING);
  await storage.set(PENDING_KEY, next);
  return next;
}
async function clearPending(storage) {
  await storage.set(PENDING_KEY, []);
}

// nextcloud/src/lib/picker-result.js
async function applyPickerResult(api, result) {
  const t = api.i18n.t;
  if (!result || typeof result !== "object") return { attached: 0, links: 0 };
  if (result.action === "attach") {
    const attached = Number(result.attached) || 0;
    if (attached) api.toast.success(t("composer.attached", { count: attached }));
    return { attached, links: 0 };
  }
  if (result.action === "links" && Array.isArray(result.links) && result.links.length) {
    await addPending(api.storage, result.links);
    api.toast.success(t("composer.linksAdded", { count: result.links.length }));
    return { attached: 0, links: result.links.length };
  }
  return { attached: 0, links: 0 };
}

// nextcloud/src/ui/settings-section.js
var import_react2 = require("react");

// nextcloud/src/ui/connection-ui.js
var import_react = require("react");
var import_ui = require("@plugin-host/ui");

// nextcloud/src/lib/account.js
function accountName(conn) {
  const name = String(conn?.displayName ?? "").trim();
  const login = String(conn?.userId ?? "").trim() || String(conn?.username ?? "").trim();
  if (name && login && name.toLowerCase() !== login.toLowerCase()) return `${name} (${login})`;
  return name || login;
}
function connectedText(t, conn) {
  return t("connect.account", { host: hostOf(conn?.origin), user: accountName(conn) });
}

// nextcloud/src/ui/connection-ui.js
function useConnection(api) {
  const [state, setState] = (0, import_react.useState)({ status: "loading" });
  const flowRef = (0, import_react.useRef)(null);
  const mounted = (0, import_react.useRef)(true);
  const set = (next) => {
    if (mounted.current) setState(next);
  };
  const refresh = (0, import_react.useCallback)(async () => {
    let fixed = null;
    try {
      fixed = await adminServer(api);
      const conn = await getConnection(api, { fixedServer: fixed });
      set(conn ? { status: "connected", conn, fixed } : { status: "disconnected", fixed });
      return conn;
    } catch (err) {
      if (err instanceof NcError && err.code === "wrong_server") set({ status: "disconnected", fixed, error: err });
      else if (needsSignIn(err)) set({ status: "expired", fixed, error: err });
      else set({ status: "error", fixed, error: err });
      return null;
    }
  }, [api]);
  (0, import_react.useEffect)(() => {
    mounted.current = true;
    void refresh();
    return () => {
      mounted.current = false;
      flowRef.current?.abort();
    };
  }, [refresh]);
  const connect = (0, import_react.useCallback)(async ({ suggestedServer } = {}) => {
    const fixed = await adminServer(api);
    set({ status: "approving", fixed });
    const controller = new AbortController();
    flowRef.current?.abort();
    flowRef.current = controller;
    try {
      const origin = await approveServer(api, { fixedServer: fixed, suggestedServer: suggestedServer ?? state.conn?.origin });
      if (!origin) {
        await refresh();
        return null;
      }
      const flow = await startLoginFlow(api, origin);
      set({ status: "waiting", fixed, origin, loginUrl: flow.loginUrl });
      await api.ui.openExternalUrl(flow.loginUrl).catch(() => {
      });
      await pollLoginFlow(api, flow, { signal: controller.signal });
      const conn = await refresh();
      if (conn) api.toast.success(api.i18n.t("connect.done", { host: hostOf(conn.origin) }));
      return conn;
    } catch (err) {
      if (err instanceof NcError && err.code === "cancelled") {
        await refresh();
        return null;
      }
      set({ status: "error", fixed, error: err });
      return null;
    } finally {
      if (flowRef.current === controller) flowRef.current = null;
    }
  }, [api, refresh, state.conn]);
  const cancel = (0, import_react.useCallback)(() => {
    flowRef.current?.abort();
  }, []);
  const signOut = (0, import_react.useCallback)(async () => {
    try {
      await disconnect(api);
    } catch (err) {
      api.toast.error(errorText(api.i18n.t, err));
    }
    await refresh();
  }, [api, refresh]);
  const switchAccount = (0, import_react.useCallback)(async () => {
    const origin = state.conn?.origin;
    try {
      await disconnect(api);
    } catch (err) {
      api.toast.error(errorText(api.i18n.t, err));
      return null;
    }
    return connect({ suggestedServer: origin });
  }, [api, connect, state.conn]);
  const report = (0, import_react.useCallback)((err) => {
    if (needsSignIn(err)) set({ status: "expired", fixed: state.fixed, error: err });
  }, [state.fixed]);
  return { ...state, refresh, connect, cancel, signOut, switchAccount, report };
}
function connectionMessage(t, c) {
  const fixedHost = c.fixed ? hostOf(c.fixed) : "";
  if (c.status === "loading") return { icon: "cloud", title: t("connect.checking") };
  if (c.status === "approving") return { icon: "cloud", title: t("connect.approving") };
  if (c.status === "waiting") return { icon: "external-link", title: t("composer.waiting"), text: t("connect.waiting", { host: hostOf(c.origin) }) };
  if (c.status === "expired") return { icon: "lock", title: t("connect.expiredTitle"), text: t("connect.expired") };
  if (c.status === "error") return { icon: "alert-triangle", title: t("error.unknown"), text: errorText(t, c.error) };
  const intro = c.error?.code === "wrong_server" ? t("error.wrong_server_host", { host: fixedHost }) : t("connect.intro");
  return { icon: "cloud", title: t("connect.title"), text: fixedHost ? `${intro} ${t("connect.server", { host: fixedHost })}` : intro };
}
function connectLabel(t, c) {
  if (c.status === "disconnected" || c.status === "error") return t("connect.button");
  if (c.status === "expired") return t("connect.again");
  return null;
}
function ConnectionEmpty({ api, connection, actions = true, compact = false }) {
  const t = api.i18n.t;
  const c = connection;
  if (c.status === "loading") return (0, import_react.createElement)(import_ui.Loading, { label: t("connect.checking") });
  const m = connectionMessage(t, c);
  let buttons = null;
  if (actions && c.status === "waiting") {
    buttons = [
      (0, import_react.createElement)(import_ui.Button, { key: "reopen", variant: "secondary", icon: "external-link", onClick: () => void api.ui.openExternalUrl(c.loginUrl) }, t("connect.reopen")),
      (0, import_react.createElement)(import_ui.Button, { key: "cancel", variant: "ghost", onClick: c.cancel }, t("common.cancel"))
    ];
  } else if (actions && connectLabel(t, c)) {
    buttons = (0, import_react.createElement)(import_ui.Button, { icon: "cloud", onClick: () => void c.connect() }, connectLabel(t, c));
  }
  return (0, import_react.createElement)(import_ui.EmptyState, { icon: m.icon, title: m.title, description: m.text, actions: buttons, compact });
}
function ConnectionSettings({ api, connection }) {
  const t = api.i18n.t;
  const c = connection;
  let row;
  if (c.status === "connected") {
    row = (0, import_react.createElement)(
      import_ui.SettingRow,
      { label: connectedText(t, c.conn), description: t("connect.accountHint") },
      (0, import_react.createElement)(
        import_ui.Row,
        { gap: 2 },
        (0, import_react.createElement)(import_ui.Button, { variant: "secondary", onClick: () => void c.switchAccount() }, t("connect.switch")),
        (0, import_react.createElement)(import_ui.Button, { variant: "secondary", onClick: () => void c.signOut() }, t("connect.disconnect"))
      )
    );
  } else if (c.status === "loading" || c.status === "approving") {
    row = (0, import_react.createElement)(import_ui.SettingRow, { label: connectionMessage(t, c).title }, (0, import_react.createElement)(import_ui.Spinner, {}));
  } else if (c.status === "waiting") {
    const m = connectionMessage(t, c);
    row = (0, import_react.createElement)(
      import_ui.SettingRow,
      { label: m.title, description: m.text },
      (0, import_react.createElement)(
        import_ui.Row,
        { gap: 2 },
        (0, import_react.createElement)(import_ui.Button, { variant: "secondary", onClick: () => void api.ui.openExternalUrl(c.loginUrl) }, t("connect.reopen")),
        (0, import_react.createElement)(import_ui.Button, { variant: "ghost", onClick: c.cancel }, t("common.cancel"))
      )
    );
  } else {
    const m = connectionMessage(t, c);
    row = (0, import_react.createElement)(
      import_ui.SettingRow,
      { label: m.title, description: m.text },
      (0, import_react.createElement)(import_ui.Button, { onClick: () => void c.connect() }, connectLabel(t, c))
    );
  }
  return (0, import_react.createElement)(
    import_ui.Stack,
    { gap: 4 },
    (0, import_react.createElement)(import_ui.Section, { title: t("settings.title"), description: t("settings.privacy") }, row),
    (0, import_react.createElement)(import_ui.Text, { tone: "muted", size: "xs" }, t("settings.migration"))
  );
}

// nextcloud/src/ui/settings-section.js
function SettingsSection() {
  const api = getApi();
  const connection = useConnection(api);
  return (0, import_react2.createElement)(ConnectionSettings, { api, connection });
}

// nextcloud/src/ui/dialog.js
var import_react10 = require("react");

// nextcloud/src/ui/account-dialog.js
var import_react3 = require("react");
var import_ui2 = require("@plugin-host/ui");
function AccountDialog({ api, connection, onResult }) {
  const t = api.i18n.t;
  const c = connection;
  const close = { id: "close", label: t("common.close"), variant: "secondary" };
  if (c.status === "connected") {
    return (0, import_react3.createElement)(
      import_ui2.Stack,
      { gap: 3 },
      (0, import_react3.createElement)(import_ui2.Text, { weight: "medium" }, connectedText(t, c.conn)),
      (0, import_react3.createElement)(import_ui2.Text, { tone: "muted" }, t("connect.accountHint")),
      (0, import_react3.createElement)(import_ui2.Text, { tone: "muted", size: "xs" }, t("settings.privacy")),
      (0, import_react3.createElement)(import_ui2.DialogButtons, {
        buttons: [
          close,
          { id: "disconnect", label: t("connect.disconnect"), variant: "secondary" },
          { id: "switch", label: t("connect.switch"), variant: "primary" }
        ],
        onClick: (id) => {
          if (id === "close") onResult({ changed: false });
          else if (id === "disconnect") void c.signOut().then(() => onResult({ changed: true }));
          else if (id === "switch") void c.switchAccount();
        }
      })
    );
  }
  return (0, import_react3.createElement)(ConnectionDialogBody, { api, connection: c, onCancel: () => onResult({ changed: true }) });
}
function ConnectionDialogBody({ api, connection, onCancel }) {
  const t = api.i18n.t;
  const c = connection;
  const cancel = { id: "cancel", label: t("common.cancel"), variant: "secondary" };
  let buttons = [cancel];
  if (c.status === "waiting") buttons = [cancel, { id: "reopen", label: t("connect.reopen"), variant: "primary" }];
  else if (c.status === "approving") buttons = [cancel, { id: "connect", label: t("connect.button"), variant: "primary", busy: true }];
  else if (connectLabel(t, c)) buttons = [cancel, { id: "connect", label: connectLabel(t, c), variant: "primary" }];
  return (0, import_react3.createElement)(
    import_ui2.Stack,
    { gap: 0 },
    (0, import_react3.createElement)(ConnectionEmpty, { api, connection: c, actions: false, compact: true }),
    (0, import_react3.createElement)(import_ui2.DialogButtons, {
      buttons,
      onClick: (id) => {
        if (id === "cancel") {
          if (c.status === "waiting") c.cancel();
          else onCancel();
        } else if (id === "reopen") void api.ui.openExternalUrl(c.loginUrl);
        else if (id === "connect") void c.connect();
      }
    })
  );
}

// nextcloud/src/ui/picker-dialog.js
var import_react6 = require("react");
var import_ui5 = require("@plugin-host/ui");

// nextcloud/src/lib/attach.js
function randomId() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}
async function attachEntries(api, client, entries, { onAttach, onProgress, signal } = {}) {
  const attached = [];
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (signal?.aborted) throw new NcError("cancelled");
    const report = (loaded, total) => onProgress?.({ index: i, count: entries.length, name: entry.name, loaded, total: total || entry.size || 0 });
    report(0, entry.size);
    const bytes = await client.download(entry, { signal, onProgress: report });
    if (signal?.aborted) throw new NcError("cancelled");
    const type = entry.type || "application/octet-stream";
    let blob;
    try {
      blob = await api.jmap.uploadBlob(bytes, entry.name, type);
    } catch (err) {
      throw mailError(err, signal);
    }
    const ok = await onAttach({ blobId: blob.blobId, name: entry.name, type: blob.type || type, size: blob.size ?? bytes.byteLength });
    if (ok === false) throw new NcError("attach_refused", { detail: entry.name });
    attached.push(entry.name);
  }
  return attached;
}
async function shareEntries(client, entries, { password = "", expireDate = "", includePassword = false } = {}) {
  const links = [];
  for (const entry of entries) {
    const share = await client.share(entry.path, { password, expireDate });
    links.push({
      id: randomId(),
      name: entry.name,
      size: entry.isFolder ? 0 : entry.size,
      url: share.url,
      password: password || "",
      includePassword: !!(password && includePassword),
      expireDate: expireDate || ""
    });
  }
  return links;
}

// nextcloud/src/ui/browser.js
var import_react4 = require("react");
var import_ui3 = require("@plugin-host/ui");
var SEARCH_DELAY_MS = 350;
function useBrowser({ api, client, path, reloadKey = 0, onError }) {
  const locale = api.i18n.getLocale();
  const [view, setView] = (0, import_react4.useState)("files");
  const [query, setQuery] = (0, import_react4.useState)("");
  const [searched, setSearched] = (0, import_react4.useState)("");
  const [state, setState] = (0, import_react4.useState)({ loading: true, entries: [], error: null });
  const [retry, setRetry] = (0, import_react4.useState)(0);
  const seq = (0, import_react4.useRef)(0);
  const onErrorRef = (0, import_react4.useRef)(onError);
  onErrorRef.current = onError;
  (0, import_react4.useEffect)(() => {
    const q = query.trim();
    if (!q) {
      setView((v) => v === "search" ? "files" : v);
      return void 0;
    }
    const timer = setTimeout(() => {
      setSearched(q);
      setView("search");
    }, SEARCH_DELAY_MS);
    return () => clearTimeout(timer);
  }, [query]);
  (0, import_react4.useEffect)(() => {
    const mine = ++seq.current;
    setState((s) => ({ ...s, loading: true, error: null }));
    const load = view === "recent" ? client.recent({ limit: 50 }) : view === "search" ? client.search(searched, { limit: 100 }) : client.list(path, locale);
    load.then(
      (entries) => {
        if (seq.current === mine) setState({ loading: false, entries, error: null });
      },
      (error) => {
        if (seq.current !== mine) return;
        setState({ loading: false, entries: [], error });
        onErrorRef.current?.(error);
      }
    );
  }, [client, view, path, searched, reloadKey, retry]);
  const showView = (0, import_react4.useCallback)((next) => {
    setView(next);
    if (next !== "search") setQuery("");
  }, []);
  return {
    view,
    query,
    searched,
    ...state,
    setQuery,
    showView,
    reload: () => setRetry((n) => n + 1)
  };
}
function crumbItems(t, browser, path) {
  if (browser.view === "recent") return [{ id: "#files", label: t("browser.allFiles") }, { id: "#recent", label: t("browser.recent") }];
  if (browser.view === "search") return [{ id: "#files", label: t("browser.allFiles") }, { id: "#search", label: t("browser.results", { query: browser.searched }) }];
  return breadcrumb(path).map((c) => ({ id: c.path, label: c.name || t("browser.home") }));
}
function browserBar({ api, browser, path, onNavigate, compact = false, search = true }) {
  const t = api.i18n.t;
  const select = (id) => {
    if (id === "#files") {
      browser.showView("files");
      return;
    }
    if (id.startsWith("#")) return;
    browser.showView("files");
    onNavigate(id);
  };
  return [
    (0, import_react4.createElement)(import_ui3.Breadcrumbs, { key: "crumbs", items: crumbItems(t, browser, path), onSelect: select, label: t("browser.location") }),
    search ? (0, import_react4.createElement)(import_ui3.SearchInput, {
      key: "search",
      value: browser.query,
      onChange: browser.setQuery,
      placeholder: t("browser.searchPlaceholder"),
      label: t("browser.search")
    }) : null,
    (0, import_react4.createElement)(import_ui3.ToolbarButton, {
      key: "recent",
      icon: "clock",
      label: t("browser.recent"),
      compact,
      active: browser.view === "recent",
      onClick: () => browser.showView(browser.view === "recent" ? "files" : "recent")
    })
  ];
}
function BrowserList({ api, browser, mode, selected, onNavigate, onToggle, columns = false, before = null, empty = null }) {
  const t = api.i18n.t;
  const locale = api.i18n.getLocale();
  const flat = browser.view !== "files";
  const shown = mode === "folder" && flat ? browser.entries.filter((e) => e.isFolder) : browser.entries;
  let body;
  if (browser.loading) {
    body = (0, import_react4.createElement)(import_ui3.Loading, { label: t("browser.loading") });
  } else if (browser.error) {
    body = (0, import_react4.createElement)(import_ui3.EmptyState, {
      icon: "alert-triangle",
      compact: !columns,
      title: errorText(t, browser.error),
      actions: (0, import_react4.createElement)(import_ui3.Button, { variant: "secondary", size: "sm", onClick: browser.reload }, t("browser.retry"))
    });
  } else if (shown.length === 0) {
    body = browser.view === "search" ? (0, import_react4.createElement)(import_ui3.EmptyState, { icon: "search", compact: !columns, title: t("browser.noResults") }) : browser.view === "recent" ? (0, import_react4.createElement)(import_ui3.EmptyState, { icon: "clock", compact: !columns, title: t("browser.noRecent") }) : empty ?? (0, import_react4.createElement)(import_ui3.EmptyState, { icon: "folder-open", compact: !columns, title: t("browser.empty") });
  } else {
    body = shown.map((entry) => {
      const isSelected = selected?.has(entry.path) ?? false;
      const pickable = entry.isFolder || mode !== "folder";
      const size = entry.isFolder ? "—" : formatSize(entry.size, locale);
      const meta = columns ? [size, formatDate(entry.modified, locale)] : entry.isFolder ? void 0 : [size];
      const parent = parentPath(entry.path);
      const where = flat ? parent === "/" ? t("browser.home") : parent : void 0;
      const tickable = mode === "files" && !entry.isFolder;
      return (0, import_react4.createElement)(import_ui3.ListRow, {
        key: entry.path,
        title: entry.name,
        subtitle: where,
        icon: entry.isFolder ? "folder" : entry.name,
        folder: entry.isFolder,
        meta,
        selected: isSelected,
        disabled: !pickable,
        checked: tickable ? isSelected : void 0,
        onCheck: tickable ? () => onToggle?.(entry) : void 0,
        onClick: () => {
          if (entry.isFolder) {
            browser.showView("files");
            onNavigate(entry.path);
            return;
          }
          if (mode !== "folder") onToggle?.(entry);
        }
      });
    });
  }
  const hasRows = !browser.loading && !browser.error && shown.length > 0;
  const cols = columns && (hasRows || before) ? [
    { label: t("files.name") },
    { label: t("files.size"), align: "end" },
    { label: t("files.modified"), align: "end", hideNarrow: true }
  ] : void 0;
  return (0, import_react4.createElement)(import_ui3.List, { label: t("browser.location"), columns: cols }, before, body);
}

// nextcloud/src/ui/share-options.js
var import_react5 = require("react");
var import_ui4 = require("@plugin-host/ui");
function ShareOptions({ api, client, value, onChange }) {
  const t = api.i18n.t;
  const set = (patch) => onChange({ ...value, ...patch });
  const latest = (0, import_react5.useRef)(value);
  latest.current = value;
  (0, import_react5.useEffect)(() => {
    if (!value.usePassword || value.password) return void 0;
    let live = true;
    client.generatePassword().then((password) => {
      if (live && latest.current.usePassword && !latest.current.password) onChange({ ...latest.current, password });
    });
    return () => {
      live = false;
    };
  }, [value.usePassword]);
  return (0, import_react5.createElement)(
    import_ui4.Stack,
    { gap: 4 },
    (0, import_react5.createElement)(import_ui4.Checkbox, { checked: value.usePassword, onChange: (on) => set({ usePassword: on }), label: t("share.usePassword") }),
    value.usePassword ? (0, import_react5.createElement)(
      import_ui4.Field,
      { label: t("share.password") },
      (0, import_react5.createElement)(import_ui4.Input, { type: "text", autoComplete: "off", spellCheck: false, value: value.password, onChange: (e) => set({ password: e.target.value }) })
    ) : null,
    value.usePassword ? (0, import_react5.createElement)(import_ui4.Checkbox, {
      checked: value.includePassword,
      onChange: (on) => set({ includePassword: on }),
      label: t("share.includePassword"),
      hint: value.includePassword ? void 0 : t("share.sendSeparately")
    }) : null,
    (0, import_react5.createElement)(
      import_ui4.Field,
      { label: t("share.expiry"), hint: value.expireDate ? t("share.expiryHint") : t("share.noExpiry") },
      (0, import_react5.createElement)(import_ui4.Input, { type: "date", value: value.expireDate, min: dateInDays(1), onChange: (e) => set({ expireDate: e.target.value }) })
    )
  );
}
function defaultShareOptions(settings) {
  return {
    usePassword: settings?.passwordProtect === true,
    password: "",
    includePassword: false,
    expireDate: dateInDays(Number(settings?.expiryDays ?? 14))
  };
}

// nextcloud/src/ui/picker-dialog.js
var LAST_PATH_KEY = "pickerPath";
function PickerDialog({ api, client, onResult, report, composerId }) {
  const t = api.i18n.t;
  const locale = api.i18n.getLocale();
  const [path, setPath] = (0, import_react6.useState)("/");
  const [selected, setSelected] = (0, import_react6.useState)(() => /* @__PURE__ */ new Map());
  const [share, setShare] = (0, import_react6.useState)(() => defaultShareOptions(api.plugin.settings));
  const [showShare, setShowShare] = (0, import_react6.useState)(false);
  const [busy, setBusy] = (0, import_react6.useState)(null);
  const [error, setError] = (0, import_react6.useState)(null);
  const abortRef = (0, import_react6.useRef)(null);
  const browser = useBrowser({ api, client, path, onError: report });
  (0, import_react6.useEffect)(() => {
    api.storage.get(LAST_PATH_KEY).then((p) => {
      if (typeof p === "string" && p) setPath(p);
    }).catch(() => {
    });
    return () => abortRef.current?.abort();
  }, []);
  const navigate = (p) => {
    setPath(p);
    void api.storage.set(LAST_PATH_KEY, p).catch(() => {
    });
  };
  const toggle = (entry) => setSelected((prev) => {
    const next = new Map(prev);
    if (next.has(entry.path)) next.delete(entry.path);
    else next.set(entry.path, entry);
    return next;
  });
  const entries = (0, import_react6.useMemo)(() => [...selected.values()], [selected]);
  const total = entries.reduce((n, e) => n + (e.size || 0), 0);
  const fail = (err) => {
    setBusy(null);
    if (err instanceof NcError && err.code === "cancelled") return;
    report?.(err);
    setError(err);
  };
  const attach = async () => {
    setError(null);
    const controller = new AbortController();
    abortRef.current = controller;
    let attached = 0;
    setBusy({ kind: "attach", index: 0, count: entries.length, loaded: 0, total: entries[0]?.size || 0, name: entries[0]?.name });
    try {
      if (!composerId) throw new NcError("attach_refused");
      await attachEntries(api, client, entries, {
        signal: controller.signal,
        onProgress: (p) => setBusy({ kind: "attach", ...p }),
        onAttach: async (blob) => {
          const ok = await api.composer.attach(composerId, blob);
          if (ok !== false) attached++;
          return ok;
        }
      });
      onResult({ action: "attach", attached });
    } catch (err) {
      if (attached) {
        const done = new Set(entries.slice(0, attached).map((e) => e.path));
        setSelected((prev) => new Map([...prev].filter(([p]) => !done.has(p))));
        api.toast.success(t("composer.attached", { count: attached }));
      }
      fail(err);
    }
  };
  const shareLinks = async () => {
    if (!showShare) {
      setShowShare(true);
      return;
    }
    setError(null);
    setBusy({ kind: "share" });
    try {
      const links = await shareEntries(client, entries, {
        password: share.usePassword ? share.password.trim() : "",
        includePassword: share.includePassword,
        expireDate: share.expireDate
      });
      onResult({ action: "links", links });
    } catch (err) {
      fail(err);
    }
  };
  const none = !entries.length;
  const attachButton = { id: "attach", label: t("picker.attach"), variant: showShare ? "secondary" : "primary", disabled: none || !!busy, busy: busy?.kind === "attach" };
  const linksButton = { id: "links", label: showShare ? t("picker.createLinks") : t("picker.shareLinks"), variant: showShare ? "primary" : "secondary", disabled: none || !!busy, busy: busy?.kind === "share" };
  const buttons = [
    { id: "cancel", label: t("common.cancel"), variant: "secondary" },
    ...showShare ? [attachButton, linksButton] : [linksButton, attachButton]
  ];
  const click = (id) => {
    if (id === "cancel") {
      if (busy?.kind === "attach") abortRef.current?.abort();
      else onResult(null);
    } else if (id === "attach") void attach();
    else if (id === "links") void shareLinks();
  };
  const fraction = busy?.kind === "attach" && busy.total ? busy.loaded / busy.total : null;
  return (0, import_react6.createElement)(
    import_ui5.Stack,
    { gap: 3 },
    (0, import_react6.createElement)(import_ui5.Row, { gap: 2, wrap: false }, ...browserBar({ api, browser, path, onNavigate: navigate, compact: true })),
    (0, import_react6.createElement)(BrowserList, { api, browser, mode: "files", selected, onNavigate: navigate, onToggle: toggle }),
    (0, import_react6.createElement)(
      import_ui5.Text,
      { tone: "muted", size: "xs" },
      entries.length ? t("picker.selected", { count: entries.length, size: formatSize(total, locale) }) : t("picker.hint")
    ),
    showShare ? (0, import_react6.createElement)(import_ui5.Stack, { gap: 3 }, (0, import_react6.createElement)(import_ui5.Heading, { level: 4 }, t("share.options")), (0, import_react6.createElement)(ShareOptions, { api, client, value: share, onChange: setShare })) : null,
    busy?.kind === "attach" ? (0, import_react6.createElement)(
      import_ui5.Stack,
      { gap: 2 },
      (0, import_react6.createElement)(import_ui5.Text, { size: "xs" }, t("picker.downloading", { name: busy.name ?? "", index: (busy.index ?? 0) + 1, count: busy.count ?? 1 })),
      (0, import_react6.createElement)(import_ui5.ProgressBar, { value: fraction, label: t("picker.progress") })
    ) : null,
    busy?.kind === "share" ? (0, import_react6.createElement)(import_ui5.Spinner, { label: t("picker.sharing") }) : null,
    error ? (0, import_react6.createElement)(import_ui5.Alert, { tone: "danger", icon: "alert-triangle" }, error.code === "attach_refused" && error.detail ? t("error.attach_refused_name", { name: error.detail }) : errorText(t, error)) : null,
    (0, import_react6.createElement)(import_ui5.DialogButtons, { buttons, onClick: click })
  );
}

// nextcloud/src/ui/offload-dialog.js
var import_react7 = require("react");
var import_ui6 = require("@plugin-host/ui");
async function offloadFile(api, client, file, { share, onProgress, signal, folder }) {
  const settings = api.plugin.settings ?? {};
  const target = folder ?? uploadFolder(settings.uploadFolder, settings.folderLayout);
  const path = await planUpload(client, target, file.name);
  await uploadFile(api, client, file, path, { onProgress, signal });
  const password = share.usePassword ? share.password.trim() : "";
  const created = await client.share(path, { password, expireDate: share.expireDate });
  const link = {
    id: path,
    name: file.name,
    size: file.size,
    url: created.url,
    password,
    includePassword: !!(password && share.includePassword),
    expireDate: share.expireDate
  };
  const block = linkBlock(api.i18n.t, [link], api.i18n.getLocale());
  return { externalAttachment: true, html: block.html, text: block.text, path, url: created.url };
}
function OffloadDialog({ api, client, onResult, report, fileId, name, size }) {
  const t = api.i18n.t;
  const locale = api.i18n.getLocale();
  const [share, setShare] = (0, import_react7.useState)(() => defaultShareOptions(api.plugin.settings));
  const [state, setState] = (0, import_react7.useState)({ phase: "ask" });
  const abortRef = (0, import_react7.useRef)(null);
  const settings = api.plugin.settings ?? {};
  const folder = uploadFolder(settings.uploadFolder, settings.folderLayout);
  (0, import_react7.useEffect)(() => () => abortRef.current?.abort(), []);
  const start = async () => {
    const controller = new AbortController();
    abortRef.current = controller;
    setState({ phase: "upload", loaded: 0, total: size });
    try {
      const file = await api.upfiles.get(fileId);
      if (!file) throw new NcError("not_found");
      const result = await offloadFile(api, client, file, {
        share,
        folder,
        signal: controller.signal,
        onProgress: (loaded, total) => setState({ phase: "upload", loaded, total })
      });
      onResult(result);
    } catch (err) {
      if (err instanceof NcError && err.code === "cancelled") {
        setState({ phase: "paused" });
        return;
      }
      report?.(err);
      setState({ phase: "error", error: err });
    }
  };
  const uploading = state.phase === "upload";
  const again = state.phase === "paused" || state.phase === "error";
  const buttons = uploading ? [
    { id: "stop", label: t("common.cancel"), variant: "secondary" },
    { id: "upload", label: t("offload.upload"), variant: "primary", busy: true }
  ] : [
    { id: "normal", label: t("offload.attachNormally"), variant: "secondary" },
    { id: "upload", label: again ? t("offload.resume") : t("offload.upload"), variant: "primary" }
  ];
  const click = (id) => {
    if (id === "stop") abortRef.current?.abort();
    else if (id === "normal") onResult({ action: "attach" });
    else if (id === "upload" && !uploading) void start();
  };
  return (0, import_react7.createElement)(
    import_ui6.Stack,
    { gap: 4 },
    (0, import_react7.createElement)(
      import_ui6.Stack,
      { gap: 1 },
      (0, import_react7.createElement)(import_ui6.Text, null, t("offload.intro", { name, size: formatSize(size, locale) })),
      (0, import_react7.createElement)(import_ui6.Text, { tone: "muted", size: "xs" }, t("offload.folder", { folder }))
    ),
    uploading ? null : (0, import_react7.createElement)(import_ui6.Stack, { gap: 3 }, (0, import_react7.createElement)(import_ui6.Heading, { level: 4 }, t("share.options")), (0, import_react7.createElement)(ShareOptions, { api, client, value: share, onChange: setShare })),
    uploading ? (0, import_react7.createElement)(
      import_ui6.Stack,
      { gap: 2 },
      (0, import_react7.createElement)(import_ui6.Text, { size: "xs" }, t("offload.uploading", { loaded: formatSize(state.loaded, locale), total: formatSize(state.total, locale) })),
      (0, import_react7.createElement)(import_ui6.ProgressBar, { value: state.total ? state.loaded / state.total : null, label: t("picker.progress") })
    ) : null,
    state.phase === "paused" ? (0, import_react7.createElement)(import_ui6.Alert, { tone: "info", icon: "player-pause" }, t("offload.paused")) : null,
    state.phase === "error" ? (0, import_react7.createElement)(import_ui6.Alert, { tone: "danger", icon: "alert-triangle" }, errorText(t, state.error)) : null,
    (0, import_react7.createElement)(import_ui6.DialogButtons, { buttons, onClick: click })
  );
}

// nextcloud/src/ui/save-dialog.js
var import_react8 = require("react");
var import_ui7 = require("@plugin-host/ui");

// nextcloud/src/lib/files.js
var BLOCKED_EXT = /* @__PURE__ */ new Set([
  "exe",
  "msi",
  "bat",
  "cmd",
  "com",
  "scr",
  "ps1",
  "vbs",
  "vbe",
  "js",
  "jse",
  "wsf",
  "hta",
  "jar",
  "lnk",
  "app",
  "dmg",
  "pkg",
  "sh",
  "command",
  "html",
  "htm",
  "xhtml",
  "shtml",
  "svg",
  "mhtml",
  "xml"
]);
var BLOCKED_TYPE = /^(text\/html|application\/xhtml|image\/svg|application\/(x-)?javascript|text\/javascript|application\/x-msdownload|application\/xml|text\/xml)/i;
function canDownload(entry) {
  const name = String(entry?.name ?? "");
  const ext = name.includes(".") ? name.slice(name.lastIndexOf(".") + 1).toLowerCase() : "";
  return !BLOCKED_EXT.has(ext) && !BLOCKED_TYPE.test(entry?.type ?? "");
}
async function downloadToComputer(api, client, entry, { onProgress, signal } = {}) {
  if (!canDownload(entry)) throw new NcError("forbidden", { detail: "file type" });
  const bytes = await client.download(entry, { onProgress, signal });
  try {
    await api.ui.downloadFile({ content: bytes, filename: entry.name, contentType: entry.type || "application/octet-stream" });
  } catch (err) {
    throw errorFromException(err, signal);
  }
}
async function attachToNewMessage(api, client, entry, { onProgress, signal } = {}) {
  const bytes = await client.download(entry, { onProgress, signal });
  const type = entry.type || "application/octet-stream";
  let blob;
  try {
    blob = await api.jmap.uploadBlob(bytes, entry.name, type);
  } catch (err) {
    throw mailError(err, signal);
  }
  return api.compose.open({
    attachments: [{ blobId: blob.blobId, name: entry.name, type: blob.type || type, size: blob.size ?? bytes.byteLength }]
  });
}
async function createFolder(api, client, path) {
  const t = api.i18n.t;
  const answer = await api.ui.prompt({
    title: t("save.newFolder"),
    confirmLabel: t("save.create"),
    cancelLabel: t("common.cancel"),
    fields: [{ name: "name", label: t("save.folderName"), placeholder: t("save.folderName"), required: true }]
  });
  const clean = sanitizeFileName(answer?.name ?? "", "");
  if (!clean) return null;
  const target = joinPath(path, clean);
  await client.mkdir(target);
  return target;
}

// nextcloud/src/ui/save-dialog.js
function SaveDialog({ api, client, onResult, report, kind, emailId, blobId, name, size }) {
  const t = api.i18n.t;
  const locale = api.i18n.getLocale();
  const [path, setPath] = (0, import_react8.useState)("/");
  const [reloadKey, setReloadKey] = (0, import_react8.useState)(0);
  const [state, setState] = (0, import_react8.useState)({ phase: "pick" });
  const abortRef = (0, import_react8.useRef)(null);
  const browser = useBrowser({ api, client, path, reloadKey, onError: report });
  (0, import_react8.useEffect)(() => {
    api.storage.get(SAVE_FOLDER_KEY).then((p) => {
      if (typeof p === "string" && p) setPath(p);
    }).catch(() => {
    });
    return () => abortRef.current?.abort();
  }, []);
  const fail = (err) => {
    if (err instanceof NcError && err.code === "cancelled") {
      setState({ phase: "pick" });
      return;
    }
    report?.(err);
    setState({ phase: "error", error: err });
  };
  const newFolder = async () => {
    try {
      const created = await createFolder(api, client, path);
      if (created) {
        browser.showView("files");
        setPath(created);
        setReloadKey((k) => k + 1);
      }
    } catch (err) {
      fail(err);
    }
  };
  const save = async () => {
    const controller = new AbortController();
    abortRef.current = controller;
    setState({ phase: "saving", loaded: 0, total: size || 0 });
    const opts = { signal: controller.signal, onProgress: (loaded, total) => setState({ phase: "saving", loaded, total }) };
    try {
      const saved = kind === "message" ? await saveMessage(api, client, { emailId, name }, path, opts) : await saveAttachment(api, client, { emailId, blobId, name }, path, opts);
      await api.storage.set(SAVE_FOLDER_KEY, path).catch(() => {
      });
      onResult({ path: saved });
    } catch (err) {
      fail(err);
    }
  };
  const saving = state.phase === "saving";
  const click = (id) => {
    if (id === "cancel") {
      if (saving) abortRef.current?.abort();
      else onResult(null);
    }
    if (id === "save") void save();
  };
  return (0, import_react8.createElement)(
    import_ui7.Stack,
    { gap: 3 },
    (0, import_react8.createElement)(import_ui7.Text, null, t("save.choose", { name: size ? `${name} (${formatSize(size, locale)})` : name })),
    (0, import_react8.createElement)(
      import_ui7.Row,
      { gap: 2, wrap: false },
      ...browserBar({ api, browser, path, onNavigate: setPath, compact: true }),
      (0, import_react8.createElement)(import_ui7.ToolbarButton, { icon: "folder-plus", label: t("save.newFolder"), compact: true, disabled: saving || browser.view !== "files", onClick: () => void newFolder() })
    ),
    (0, import_react8.createElement)(BrowserList, { api, browser, mode: "folder", onNavigate: setPath }),
    saving ? (0, import_react8.createElement)(
      import_ui7.Stack,
      { gap: 2 },
      (0, import_react8.createElement)(import_ui7.Text, { size: "xs" }, t("save.saving")),
      (0, import_react8.createElement)(import_ui7.ProgressBar, { value: state.total ? state.loaded / state.total : null, label: t("picker.progress") })
    ) : null,
    state.phase === "error" ? (0, import_react8.createElement)(import_ui7.Alert, { tone: "danger", icon: "alert-triangle" }, errorText(t, state.error)) : null,
    (0, import_react8.createElement)(import_ui7.DialogButtons, {
      buttons: [
        { id: "cancel", label: t("common.cancel"), variant: "secondary" },
        { id: "save", label: t("save.here"), variant: "primary", busy: saving, disabled: browser.view !== "files" }
      ],
      onClick: click
    })
  );
}

// nextcloud/src/ui/share-dialog.js
var import_react9 = require("react");
var import_ui8 = require("@plugin-host/ui");
function ShareDialog({ api, client, onResult, report, path }) {
  const t = api.i18n.t;
  const [share, setShare] = (0, import_react9.useState)(() => defaultShareOptions(api.plugin.settings));
  const [busy, setBusy] = (0, import_react9.useState)(false);
  const [error, setError] = (0, import_react9.useState)(null);
  const [link, setLink] = (0, import_react9.useState)("");
  const create = async () => {
    setBusy(true);
    setError(null);
    try {
      const created = await client.share(path, { password: share.usePassword ? share.password.trim() : "", expireDate: share.expireDate });
      setLink(created.url);
    } catch (err) {
      report?.(err);
      setError(err);
    } finally {
      setBusy(false);
    }
  };
  if (link) {
    return (0, import_react9.createElement)(
      import_ui8.Stack,
      { gap: 4 },
      (0, import_react9.createElement)(
        import_ui8.Field,
        { label: t("files.linkLabel"), hint: t("files.linkReady") },
        (0, import_react9.createElement)(import_ui8.Input, { readOnly: true, value: link, onFocus: (e) => e.target.select() })
      ),
      (0, import_react9.createElement)(import_ui8.DialogButtons, { buttons: [{ id: "close", label: t("common.close"), variant: "primary" }], onClick: () => onResult({ url: link }) })
    );
  }
  return (0, import_react9.createElement)(
    import_ui8.Stack,
    { gap: 4 },
    (0, import_react9.createElement)(ShareOptions, { api, client, value: share, onChange: setShare }),
    error ? (0, import_react9.createElement)(import_ui8.Alert, { tone: "danger", icon: "alert-triangle" }, errorText(t, error)) : null,
    (0, import_react9.createElement)(import_ui8.DialogButtons, {
      buttons: [
        { id: "cancel", label: t("common.cancel"), variant: "secondary" },
        { id: "create", label: t("files.createLink"), variant: "primary", busy }
      ],
      onClick: (id) => {
        if (id === "cancel") onResult(null);
        else if (!busy) void create();
      }
    })
  );
}

// nextcloud/src/ui/dialog.js
var VIEWS = {
  picker: PickerDialog,
  offload: OffloadDialog,
  save: SaveDialog,
  share: ShareDialog
};
function PluginDialog(props) {
  const api = getApi();
  const connection = useConnection(api);
  const client = (0, import_react10.useMemo)(() => connection.conn ? createClient(api, connection.conn) : null, [connection.conn]);
  if (props.view === "account") return (0, import_react10.createElement)(AccountDialog, { api, connection, onResult: props.onResult });
  const View = VIEWS[props.view];
  if (!View) return null;
  if (connection.status !== "connected" || !client) {
    return (0, import_react10.createElement)(ConnectionDialogBody, { api, connection, onCancel: () => props.onResult?.(null) });
  }
  return (0, import_react10.createElement)(View, { ...props, api, client, report: connection.report });
}

// nextcloud/src/ui/files-page.js
var import_react11 = require("react");
var import_ui9 = require("@plugin-host/ui");
var NARROW = "(max-width: 640px)";
function useNarrow() {
  const query = typeof window !== "undefined" && typeof window.matchMedia === "function" ? window.matchMedia(NARROW) : null;
  const [narrow, setNarrow] = (0, import_react11.useState)(() => query?.matches ?? false);
  (0, import_react11.useEffect)(() => {
    if (!query) return void 0;
    const on = () => setNarrow(query.matches);
    query.addEventListener?.("change", on);
    return () => query.removeEventListener?.("change", on);
  }, []);
  return narrow;
}
function UploadRow({ api, job, onResume, onCancel, onDiscard }) {
  const t = api.i18n.t;
  const locale = api.i18n.getLocale();
  const status = job.state === "running" ? (0, import_react11.createElement)(
    import_ui9.Stack,
    { gap: 1 },
    t("files.statusProgress", { loaded: formatSize(job.loaded, locale), total: formatSize(job.total, locale) }),
    (0, import_react11.createElement)(import_ui9.ProgressBar, { value: job.total ? job.loaded / job.total : null, label: job.file.name })
  ) : job.state === "paused" ? t("files.statusPaused") : job.state === "done" ? t("files.statusDone") : errorText(t, job.error);
  const actions = job.state === "running" ? (0, import_react11.createElement)(import_ui9.RowAction, { icon: "x", label: t("common.cancel"), onClick: () => onCancel(job) }) : job.state === "done" ? (0, import_react11.createElement)(import_ui9.RowAction, { icon: "x", label: t("files.discard"), onClick: () => onDiscard(job) }) : [
    (0, import_react11.createElement)(import_ui9.RowAction, { key: "resume", icon: "player-play", label: t("files.resume"), onClick: () => onResume(job) }),
    (0, import_react11.createElement)(import_ui9.RowAction, { key: "discard", icon: "trash", label: t("files.discard"), danger: true, onClick: () => onDiscard(job) })
  ];
  return (0, import_react11.createElement)(import_ui9.ListRow, { title: job.file.name, icon: job.file.name, subtitle: status, actions });
}
function FilesPage() {
  const api = getApi();
  const connection = useConnection(api);
  const client = (0, import_react11.useMemo)(() => connection.conn ? createClient(api, connection.conn) : null, [connection.conn]);
  if (connection.status !== "connected" || !client) {
    return (0, import_react11.createElement)(import_ui9.Page, { flush: true }, (0, import_react11.createElement)(ConnectionEmpty, { api, connection }));
  }
  return (0, import_react11.createElement)(FilesBrowser, { api, client, connection });
}
function FilesBrowser({ api, client, connection }) {
  const t = api.i18n.t;
  const narrow = useNarrow();
  const [path, setPath] = (0, import_react11.useState)("/");
  const [selected, setSelected] = (0, import_react11.useState)(() => /* @__PURE__ */ new Map());
  const [reloadKey, setReloadKey] = (0, import_react11.useState)(0);
  const [jobs, setJobs] = (0, import_react11.useState)([]);
  const [busy, setBusy] = (0, import_react11.useState)(null);
  const [dragging, setDragging] = (0, import_react11.useState)(false);
  const [searchOpen, setSearchOpen] = (0, import_react11.useState)(false);
  const inputRef = (0, import_react11.useRef)(null);
  const controllers = (0, import_react11.useRef)(/* @__PURE__ */ new Map());
  const browser = useBrowser({ api, client, path, reloadKey, onError: connection.report });
  const fail = (err) => {
    if (err instanceof NcError && err.code === "cancelled") return;
    connection.report(err);
    api.toast.error(errorText(t, err));
  };
  const navigate = (p) => {
    setPath(p);
    setSelected(/* @__PURE__ */ new Map());
  };
  const update = (id, patch) => setJobs((list) => list.map((j) => j.id === id ? { ...j, ...patch } : j));
  const runJob = async (job) => {
    const controller = new AbortController();
    controllers.current.set(job.id, controller);
    update(job.id, { state: "running", error: null });
    try {
      const target = job.target ?? await planUpload(client, job.folder, job.file.name);
      update(job.id, { target });
      await uploadFile(api, client, job.file, target, {
        signal: controller.signal,
        onProgress: (loaded, total) => update(job.id, { loaded, total })
      });
      update(job.id, { state: "done", loaded: job.file.size });
      setReloadKey((k) => k + 1);
    } catch (err) {
      if (err instanceof NcError && err.code === "cancelled") update(job.id, { state: "paused" });
      else {
        connection.report(err);
        update(job.id, { state: "error", error: err });
      }
    } finally {
      controllers.current.delete(job.id);
    }
  };
  const addFiles = (files) => {
    const added = [...files].map((file2) => ({ id: `${Date.now()}-${Math.random()}`, file: file2, folder: path, state: "running", loaded: 0, total: file2.size }));
    setJobs((list) => [...list.filter((j) => j.state !== "done"), ...added]);
    for (const job of added) void runJob(job);
  };
  const run = async (kind, fn) => {
    setBusy(kind);
    try {
      await fn();
    } catch (err) {
      fail(err);
    } finally {
      setBusy(null);
    }
  };
  const newFolder = () => run("folder", async () => {
    const created = await createFolder(api, client, path);
    if (created) {
      browser.showView("files");
      navigate(created);
      setReloadKey((k) => k + 1);
    }
  });
  const share = async (entry) => {
    await api.ui.openDialog({ title: t("share.title", { name: entry.name }), slot: "plugin-dialog", extraProps: { view: "share", path: entry.path, name: entry.name }, width: 520 });
  };
  const showAccount = async () => {
    await api.ui.openDialog({ title: t("settings.title"), slot: "plugin-dialog", extraProps: { view: "account" }, width: 520 });
    await connection.refresh();
  };
  const current = [...selected.values()][0] ?? null;
  const file = current && !current.isFolder ? current : null;
  let toolbar;
  if (file) {
    toolbar = (0, import_react11.createElement)(
      import_ui9.Toolbar,
      null,
      (0, import_react11.createElement)(import_ui9.ToolbarButton, { icon: "x", label: t("files.clearSelection"), compact: true, onClick: () => setSelected(/* @__PURE__ */ new Map()) }),
      (0, import_react11.createElement)(import_ui9.Text, { weight: "medium", truncate: true }, file.name),
      canDownload(file) ? (0, import_react11.createElement)(import_ui9.ToolbarButton, { icon: "download", label: t("files.download"), compact: narrow, busy: busy === "download", disabled: !!busy, onClick: () => void run("download", () => downloadToComputer(api, client, file)) }) : null,
      (0, import_react11.createElement)(import_ui9.ToolbarButton, { icon: "share-2", label: t("files.share"), compact: narrow, disabled: !!busy, onClick: () => void share(file) }),
      (0, import_react11.createElement)(import_ui9.ToolbarButton, { icon: "paperclip", label: t("files.attachNew"), compact: narrow, busy: busy === "attach", disabled: !!busy, onClick: () => void run("attach", () => attachToNewMessage(api, client, file)) }),
      (0, import_react11.createElement)(import_ui9.ToolbarButton, { icon: "external-link", label: t("files.open"), compact: true, onClick: () => void api.ui.openExternalUrl(client.webUrl(file)) }),
      (0, import_react11.createElement)(import_ui9.ToolbarSpacer, null)
    );
  } else if (narrow && searchOpen) {
    toolbar = (0, import_react11.createElement)(
      import_ui9.Toolbar,
      null,
      ...browserBar({ api, browser, path, onNavigate: navigate, compact: true }).slice(1, 2),
      (0, import_react11.createElement)(import_ui9.ToolbarButton, { icon: "x", label: t("common.close"), compact: true, onClick: () => {
        browser.setQuery("");
        setSearchOpen(false);
      } })
    );
  } else {
    const [crumbs, search, recent] = browserBar({ api, browser, path, onNavigate: navigate, compact: true });
    toolbar = (0, import_react11.createElement)(
      import_ui9.Toolbar,
      null,
      crumbs,
      narrow ? (0, import_react11.createElement)(import_ui9.ToolbarButton, { key: "search", icon: "search", label: t("browser.search"), compact: true, onClick: () => setSearchOpen(true) }) : search,
      recent,
      (0, import_react11.createElement)(import_ui9.ToolbarButton, { icon: "upload", label: t("files.upload"), compact: narrow, onClick: () => inputRef.current?.click() }),
      (0, import_react11.createElement)(import_ui9.ToolbarButton, { icon: "folder-plus", label: t("save.newFolder"), compact: true, busy: busy === "folder", onClick: () => void newFolder() }),
      narrow ? null : (0, import_react11.createElement)(import_ui9.ToolbarButton, { icon: "refresh", label: t("files.refresh"), compact: true, busy: browser.loading, onClick: browser.reload }),
      (0, import_react11.createElement)(import_ui9.ToolbarButton, { icon: "user-circle", label: accountName(connection.conn), compact: narrow, onClick: () => void showAccount() })
    );
  }
  const uploads = jobs.map((job) => (0, import_react11.createElement)(UploadRow, {
    key: job.id,
    api,
    job,
    onCancel: (j) => controllers.current.get(j.id)?.abort(),
    onResume: (j) => void runJob(jobs.find((x) => x.id === j.id) ?? j),
    onDiscard: async (j) => {
      const latest = jobs.find((x) => x.id === j.id) ?? j;
      if (latest.state !== "done" && latest.target) await discardUpload(api, client, latest.file, latest.target).catch(() => {
      });
      setJobs((list) => list.filter((x) => x.id !== j.id));
    }
  }));
  const empty = (0, import_react11.createElement)(import_ui9.EmptyState, {
    icon: path === "/" ? "upload" : "folder-open",
    title: t("browser.empty"),
    description: t("files.uploadHint"),
    actions: [
      (0, import_react11.createElement)(import_ui9.Button, { key: "upload", size: "sm", icon: "upload", onClick: () => inputRef.current?.click() }, t("files.upload")),
      (0, import_react11.createElement)(import_ui9.Button, { key: "folder", size: "sm", variant: "secondary", icon: "folder-plus", onClick: () => void newFolder() }, t("save.newFolder"))
    ]
  });
  return (0, import_react11.createElement)(
    "div",
    {
      onDragOver: (e) => {
        if (e.dataTransfer?.types?.includes("Files")) {
          e.preventDefault();
          setDragging(true);
        }
      },
      onDragLeave: () => setDragging(false),
      onDrop: (e) => {
        e.preventDefault();
        setDragging(false);
        if (e.dataTransfer?.files?.length) addFiles(e.dataTransfer.files);
      }
    },
    (0, import_react11.createElement)(
      import_ui9.Page,
      { flush: true },
      (0, import_react11.createElement)("input", {
        ref: inputRef,
        type: "file",
        multiple: true,
        hidden: true,
        "aria-hidden": "true",
        tabIndex: -1,
        "data-testid": "nc-upload-input",
        onChange: (e) => {
          if (e.target.files?.length) addFiles(e.target.files);
          e.target.value = "";
        }
      }),
      toolbar,
      dragging ? (0, import_react11.createElement)(import_ui9.Alert, { tone: "info", icon: "upload" }, t("files.uploadHint")) : null,
      (0, import_react11.createElement)(BrowserList, {
        api,
        browser,
        mode: "manage",
        selected,
        columns: true,
        empty,
        before: uploads.length ? uploads : null,
        onNavigate: navigate,
        onToggle: (entry) => setSelected((prev) => prev.has(entry.path) ? /* @__PURE__ */ new Map() : /* @__PURE__ */ new Map([[entry.path, entry]]))
      })
    )
  );
}

// nextcloud/src/index.js
var FIRST_RUN_KEY = "firstRunOffered";
async function offerFirstRun(api) {
  if (await api.storage.get(FIRST_RUN_KEY)) return false;
  const account = await storedAccount(api);
  await api.storage.set(FIRST_RUN_KEY, true);
  if (account?.connected) return false;
  api.toast.info(api.i18n.t("firstrun.offer"));
  return true;
}
var bg = null;
async function registerActions(api) {
  const t = api.i18n.t;
  await api.ui.setActions("attachment-menu", [{ id: "save-attachment", label: t("save.attachmentAction"), icon: "cloud-upload" }]);
  await api.ui.setActions("reader-actions", [{ id: "save-message", label: t("save.messageAction"), icon: "cloud-upload", order: 200 }]);
  await api.ui.setActions("composer-attach-menu", [{ id: "from-nextcloud", label: t("composer.attachMenu"), icon: "cloud" }]);
  await api.ui.setPages([{ id: "files", title: t("page.title"), icon: "cloud" }]);
}
async function activate(api) {
  bg = api;
  setApi(api);
  await registerActions(api).catch((err) => api.log.warn("setActions failed", err));
  api.i18n.onLocaleChange(() => {
    void registerActions(api).catch(() => {
    });
  });
  await offerFirstRun(api).catch(() => {
  });
}
async function attachFromNextcloud(api, composerId) {
  if (typeof composerId !== "string" || !composerId) return { attached: 0, links: 0 };
  const result = await api.ui.openDialog({
    title: api.i18n.t("picker.title"),
    slot: "plugin-dialog",
    extraProps: { view: "picker", composerId },
    width: 760
  });
  return applyPickerResult(api, result);
}
async function onAction(api, { surface, actionId, context } = {}) {
  const t = api.i18n.t;
  if (surface === "composer-attach-menu" && actionId === "from-nextcloud") {
    await attachFromNextcloud(api, context?.composerId);
    return;
  }
  let props;
  if (surface === "attachment-menu" && actionId === "save-attachment") {
    if (!context?.emailId || !context?.blobId) return;
    props = { kind: "attachment", emailId: context.emailId, blobId: context.blobId, name: context.name || "attachment", size: Number(context.size) || 0 };
  } else if (surface === "reader-actions" && actionId === "save-message") {
    if (!context?.emailId) return;
    const email = await api.email.get(context.emailId).catch(() => null);
    props = { kind: "message", emailId: context.emailId, name: emlName(email?.subject), size: 0 };
  } else {
    return;
  }
  const title = props.kind === "message" ? t("save.titleMessage") : t("save.titleAttachment", { name: props.name });
  const result = await api.ui.openDialog({ title, slot: "plugin-dialog", extraProps: { view: "save", ...props }, width: 640 });
  if (result && typeof result.path === "string") api.toast.success(t("save.saved", { path: result.path }));
}
async function addLinksToMessage(api, outgoing) {
  const links = await getPending(api.storage);
  if (!links.length) return void 0;
  const next = appendLinks(outgoing, linkBlock(api.i18n.t, links, api.i18n.getLocale()));
  await clearPending(api.storage);
  return next;
}
var MB = 1024 * 1024;
async function offerLargeUpload(api, payload) {
  const fileId = typeof payload === "string" ? payload : payload?.fileId;
  if (typeof fileId !== "string" || !fileId) return void 0;
  const settings = api.plugin.settings ?? {};
  if (settings.offerLargeUpload === false) return void 0;
  const account = await storedAccount(api);
  if (!account?.connected) return void 0;
  const file = await api.upfiles.get(fileId);
  if (!file) return void 0;
  const threshold = Math.max(1, Number(settings.largeFileMb) || 10) * MB;
  if (file.size < threshold) return void 0;
  const result = await api.ui.openDialog({
    title: api.i18n.t("offload.title"),
    slot: "plugin-dialog",
    extraProps: { view: "offload", fileId, name: file.name, size: file.size },
    width: 560
  });
  if (result && result.externalAttachment === true && typeof result.html === "string" && typeof result.text === "string") {
    return { externalAttachment: true, html: result.html, text: result.text, fileId };
  }
  return void 0;
}
var hooks = {
  onAction: (payload) => bg ? onAction(bg, payload) : void 0,
  onBeforeBlobUpload: (payload) => bg ? offerLargeUpload(bg, payload) : void 0,
  onTransformOutgoingEmail: (outgoing) => bg ? addLinksToMessage(bg, outgoing) : void 0,
  // Links picked for a message that was then discarded don't carry over to the next one.
  onComposerClose: () => bg ? clearPending(bg.storage) : void 0
};
var slots = {
  "settings-section": { component: SettingsSection },
  "plugin-dialog": { component: PluginDialog },
  "app-page": { component: FilesPage }
};
