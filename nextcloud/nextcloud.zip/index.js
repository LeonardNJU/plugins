var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// nextcloud/src/index.js
var index_exports = {};
__export(index_exports, {
  activate: () => activate,
  hooks: () => hooks,
  offerFirstRun: () => offerFirstRun,
  slots: () => slots
});
module.exports = __toCommonJS(index_exports);

// nextcloud/src/lib/host.js
var hostApi = null;
function getApi() {
  if (!hostApi && typeof require === "function") {
    hostApi = require("@plugin-host");
  }
  return hostApi;
}
function setApi(api) {
  hostApi = api;
}

// nextcloud/src/lib/errors.js
var NcError = class extends Error {
  /**
   * @param {string} code one of ERROR_CODES
   * @param {{ status?: number, detail?: string }} [info]
   */
  constructor(code, info = {}) {
    super(info.detail ? `${code}: ${info.detail}` : code);
    this.name = "NcError";
    this.code = code;
    this.status = info.status ?? 0;
    this.detail = info.detail ?? "";
  }
};
var ERROR_CODES = [
  "not_connected",
  "auth",
  "forbidden",
  "share_forbidden",
  "not_found",
  "exists",
  "quota",
  "too_large",
  "locked",
  "rate_limited",
  "timeout",
  "unreachable",
  "blocked",
  "maintenance",
  "server",
  "cancelled",
  "wrong_server",
  "login_expired",
  "bad_answer",
  "rejected",
  "unknown"
];
var PROXY_CODES = {
  no_credential: "not_connected",
  rate_limited: "rate_limited",
  timeout: "timeout",
  unreachable: "unreachable",
  blocked_address: "blocked",
  wrong_origin: "blocked",
  redirect_off_origin: "blocked",
  too_large: "too_large"
};
function ocsMessage(body) {
  let data = body;
  if (typeof data === "string") {
    try {
      data = JSON.parse(data);
    } catch {
      return "";
    }
  }
  const message = data?.ocs?.meta?.message;
  return typeof message === "string" && message !== "OK" ? message : "";
}
function davMessage(body) {
  if (typeof body !== "string") return "";
  const m = /<(?:[\w.-]+:)?message>([^<]{1,300})<\//.exec(body);
  return m ? m[1].trim() : "";
}
function errorFromResponse(res, { kind } = {}) {
  if (!res || typeof res !== "object") return new NcError("unknown");
  if (res.proxyError) {
    return new NcError(PROXY_CODES[res.proxyError] ?? "unknown", { status: res.status, detail: typeof res.body === "string" ? res.body : "" });
  }
  if (res.ok) return null;
  const status = Number(res.status) || 0;
  const detail = ocsMessage(res.body) || davMessage(res.body);
  const info = { status, detail };
  if (status === 400 && detail) return new NcError("rejected", info);
  if (status === 401) return new NcError("auth", info);
  if (status === 403) return new NcError(kind === "share" ? "share_forbidden" : "forbidden", info);
  if (status === 404) return new NcError("not_found", info);
  if (status === 405 || status === 412) return new NcError("exists", info);
  if (status === 413) return new NcError("too_large", info);
  if (status === 423) return new NcError("locked", info);
  if (status === 429) return new NcError("rate_limited", info);
  if (status === 503) return new NcError("maintenance", info);
  if (status === 507) return new NcError("quota", info);
  if (status === 504 || status === 408) return new NcError("timeout", info);
  if (status >= 500) return new NcError("server", info);
  return new NcError("unknown", info);
}
function errorFromException(err, signal) {
  if (err instanceof NcError) return err;
  if (signal?.aborted) return new NcError("cancelled");
  const message = String(err?.message ?? err ?? "");
  if (/cancel|abort/i.test(message)) return new NcError("cancelled");
  if (/timed out/i.test(message)) return new NcError("timeout");
  if (/larger than/i.test(message)) return new NcError("too_large");
  if (/at most \d+ proxy requests/i.test(message)) return new NcError("rate_limited");
  if (/network/i.test(message)) return new NcError("unreachable");
  return new NcError("unknown", { detail: message.slice(0, 200) });
}
function needsSignIn(err) {
  return err instanceof NcError && (err.code === "auth" || err.code === "not_connected" || err.code === "wrong_server");
}
function errorText(t, err) {
  const e = err instanceof NcError ? err : errorFromException(err);
  const text = t(`error.${ERROR_CODES.includes(e.code) ? e.code : "unknown"}`);
  const withDetail = ["forbidden", "share_forbidden", "rejected", "unknown", "bad_answer"].includes(e.code) && e.detail;
  return withDetail ? `${text} (${e.detail})` : text;
}

// nextcloud/src/lib/paths.js
function originOf(value) {
  const raw = String(value ?? "").trim();
  if (!raw) return null;
  const withScheme = /^[a-z][a-z0-9+.-]*:\/\//i.test(raw) ? raw : `https://${raw}`;
  try {
    const url = new URL(withScheme);
    if (url.protocol !== "https:" && url.protocol !== "http:") return null;
    return url.origin;
  } catch {
    return null;
  }
}

// nextcloud/src/lib/webdav.js
var PROPS = `<d:prop>
  <d:displayname/><d:getcontentlength/><d:getcontenttype/><d:getlastmodified/><d:resourcetype/><d:getetag/>
  <oc:fileid/><oc:size/><oc:permissions/>
</d:prop>`;
var NS = 'xmlns:d="DAV:" xmlns:oc="http://owncloud.org/ns" xmlns:nc="http://nextcloud.org/ns"';
var PROPFIND_BODY = `<?xml version="1.0" encoding="UTF-8"?>
<d:propfind ${NS}>${PROPS}</d:propfind>`;

// nextcloud/src/lib/client.js
var CREDENTIAL = "nextcloud";
var BUFFERED_LIMIT = 24 * 1024 * 1024;
var OCS_HEADERS = { "OCS-APIRequest": "true", Accept: "application/json" };
async function ncRequest(api, url, init = {}, { kind, accept = [] } = {}) {
  let res;
  try {
    res = await api.proxy.fetch(CREDENTIAL, url, init);
  } catch (err2) {
    throw errorFromException(err2, init.signal);
  }
  if (init.signal?.aborted) throw new NcError("cancelled");
  if (res && accept.includes(res.status) && !res.proxyError) return res;
  const err = errorFromResponse(res, { kind });
  if (err) throw err;
  return res;
}
function parseJson(body) {
  if (body && typeof body === "object") return body;
  try {
    return JSON.parse(String(body ?? ""));
  } catch {
    throw new NcError("bad_answer");
  }
}
async function ocs(api, origin, path, init = {}, opts = {}) {
  const sep = path.includes("?") ? "&" : "?";
  const res = await ncRequest(api, `${origin}${path}${sep}format=json`, {
    ...init,
    headers: { ...OCS_HEADERS, ...init.headers ?? {} },
    responseType: "text"
  }, opts);
  return parseJson(res.body)?.ocs?.data;
}

// nextcloud/src/lib/connection.js
var POLL_INTERVAL_MS = 2e3;
var POLL_TIMEOUT_MS = 20 * 60 * 1e3;
async function adminServer(api) {
  try {
    const config = await api.admin.getAllConfig();
    return originOf(config?.serverUrl) ?? null;
  } catch {
    return null;
  }
}
async function storedAccount(api) {
  let list;
  try {
    list = await api.proxy.accounts();
  } catch {
    return null;
  }
  const account = Array.isArray(list) ? list.find((a) => a.credentialId === CREDENTIAL) : null;
  return account ?? null;
}
function userKey(origin, username) {
  return `user:${origin}:${username ?? ""}`;
}
async function getConnection(api, { fixedServer } = {}) {
  const account = await storedAccount(api);
  if (!account || !account.connected) return null;
  const fixed = fixedServer === void 0 ? await adminServer(api) : fixedServer;
  if (fixed && account.origin !== fixed) throw new NcError("wrong_server");
  const key = userKey(account.origin, account.username);
  const cached = await api.storage.get(key);
  if (cached && typeof cached.userId === "string" && cached.userId) {
    return { origin: account.origin, username: account.username ?? "", userId: cached.userId, displayName: cached.displayName ?? "" };
  }
  const data = await ocs(api, account.origin, "/ocs/v2.php/cloud/user");
  const userId = typeof data?.id === "string" && data.id ? data.id : account.username;
  if (!userId) throw new NcError("bad_answer");
  const displayName = typeof data?.displayname === "string" ? data.displayname : data?.["display-name"] ?? "";
  await api.storage.set(key, { userId, displayName });
  return { origin: account.origin, username: account.username ?? "", userId, displayName };
}
async function approveServer(api, { fixedServer, suggestedServer } = {}) {
  const server = fixedServer || suggestedServer || void 0;
  const result = await api.proxy.connect(CREDENTIAL, { mode: "signin", ...server ? { server } : {} });
  const origin = result?.origin ? originOf(result.origin) : null;
  if (!origin) return null;
  if (fixedServer && origin !== fixedServer) {
    await api.proxy.disconnect(CREDENTIAL).catch(() => {
    });
    throw new NcError("wrong_server");
  }
  return origin;
}
async function startLoginFlow(api, origin) {
  const res = await ncRequest(api, `${origin}/index.php/login/v2`, { method: "POST", responseType: "text" });
  let data;
  try {
    data = JSON.parse(String(res.body));
  } catch {
    throw new NcError("bad_answer", { detail: "login/v2" });
  }
  const loginUrl = data?.login;
  const endpoint = data?.poll?.endpoint;
  const token = data?.poll?.token;
  if (typeof loginUrl !== "string" || typeof endpoint !== "string" || typeof token !== "string" || !token) {
    throw new NcError("bad_answer", { detail: "login/v2" });
  }
  if (originOf(loginUrl) === null) throw new NcError("bad_answer", { detail: "login url" });
  if (originOf(endpoint) !== origin) throw new NcError("blocked", { detail: endpoint });
  return { loginUrl, endpoint, token };
}
var sleepFor = (ms, signal) => new Promise((resolve, reject) => {
  const timer = setTimeout(resolve, ms);
  signal?.addEventListener("abort", () => {
    clearTimeout(timer);
    reject(new NcError("cancelled"));
  }, { once: true });
});
async function pollLoginFlow(api, { endpoint, token }, { signal, intervalMs = POLL_INTERVAL_MS, timeoutMs = POLL_TIMEOUT_MS, sleep = sleepFor, now = Date.now } = {}) {
  const started = now();
  for (; ; ) {
    if (signal?.aborted) throw new NcError("cancelled");
    const res = await ncRequest(api, endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: `token=${encodeURIComponent(token)}`,
      responseType: "json",
      capture: { secret: "appPassword", username: "loginName" },
      signal
    }, { accept: [404] });
    if (res.status === 200) {
      if (res.body?.captured) return true;
      throw new NcError("bad_answer", { detail: "no app password" });
    }
    if (now() - started > timeoutMs) throw new NcError("login_expired");
    await sleep(intervalMs, signal);
  }
}
async function disconnect(api) {
  const account = await storedAccount(api);
  if (account?.connected) {
    await ocs(api, account.origin, "/ocs/v2.php/core/apppassword", { method: "DELETE" }).catch(() => {
    });
  }
  if (account) await api.storage.remove(userKey(account.origin, account.username)).catch(() => {
  });
  await api.proxy.disconnect(CREDENTIAL);
}

// nextcloud/src/ui/settings-section.js
var import_react2 = require("react");

// nextcloud/src/ui/styles.js
var CSS = `
.nc { font-size: 13px; color: var(--color-foreground); line-height: 1.4; }
.nc * { box-sizing: border-box; }
.nc-row { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
.nc-col { display: flex; flex-direction: column; gap: 8px; }
.nc-grow { flex: 1 1 auto; min-width: 0; }
.nc-muted { color: var(--color-muted-foreground); }
.nc-small { font-size: 12px; }
.nc-error { color: var(--color-destructive); }
.nc-ok { color: var(--color-success, var(--color-foreground)); }
.nc-btn { font: inherit; display: inline-flex; align-items: center; justify-content: center; gap: 6px; padding: 6px 12px; min-height: 32px;
  border-radius: 6px; border: 1px solid var(--color-border); background: var(--color-background); color: var(--color-foreground); cursor: pointer; white-space: nowrap; }
.nc-btn:hover:not(:disabled) { background: var(--color-accent); color: var(--color-accent-foreground); }
.nc-btn:disabled { opacity: .55; cursor: default; }
.nc-btn:focus-visible, .nc-input:focus-visible, .nc-item:focus-visible, .nc-tab:focus-visible, .nc-crumb:focus-visible, .nc-check:focus-visible { outline: 2px solid var(--color-ring); outline-offset: 1px; }
.nc-primary { background: var(--color-primary); color: var(--color-primary-foreground); border-color: var(--color-primary); }
.nc-primary:hover:not(:disabled) { background: var(--color-primary); color: var(--color-primary-foreground); filter: brightness(1.08); }
.nc-danger { color: var(--color-destructive); }
.nc-link { font: inherit; background: none; border: 0; padding: 0; color: var(--color-primary); cursor: pointer; text-decoration: underline; }
.nc-input { font: inherit; padding: 6px 8px; min-height: 32px; border-radius: 6px; border: 1px solid var(--color-input); background: var(--color-background); color: var(--color-foreground); }
.nc-label { display: flex; flex-direction: column; gap: 4px; font-size: 12px; }
.nc-check { width: 16px; height: 16px; accent-color: var(--color-primary); margin: 0; }
.nc-tabs { display: flex; gap: 4px; border-bottom: 1px solid var(--color-border); }
.nc-tab { font: inherit; background: none; border: 0; border-bottom: 2px solid transparent; padding: 6px 10px; color: var(--color-muted-foreground); cursor: pointer; }
.nc-tab[aria-selected="true"] { color: var(--color-foreground); border-bottom-color: var(--color-primary); }
.nc-crumbs { display: flex; flex-wrap: wrap; align-items: center; gap: 2px; font-size: 12px; }
.nc-crumb { font: inherit; background: none; border: 0; padding: 2px 4px; border-radius: 4px; color: var(--color-muted-foreground); cursor: pointer; }
.nc-crumb:hover { background: var(--color-muted); color: var(--color-foreground); }
.nc-crumb[aria-current="page"] { color: var(--color-foreground); font-weight: 600; }
.nc-list { border: 1px solid var(--color-border); border-radius: 8px; overflow: auto; background: var(--color-background); }
.nc-item { display: flex; align-items: center; gap: 10px; width: 100%; padding: 8px 10px; border: 0; border-bottom: 1px solid var(--color-border);
  background: none; color: inherit; font: inherit; text-align: start; cursor: pointer; min-height: 40px; }
.nc-item:last-child { border-bottom: 0; }
.nc-item:hover { background: var(--color-muted); }
.nc-item[aria-selected="true"], .nc-item[data-checked="true"] { background: var(--color-selection, var(--color-accent)); color: var(--color-selection-foreground, var(--color-accent-foreground)); }
.nc-icon { width: 18px; height: 18px; flex: 0 0 18px; color: var(--color-muted-foreground); }
.nc-name { flex: 1 1 auto; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.nc-meta { flex: 0 0 auto; font-size: 12px; color: var(--color-muted-foreground); white-space: nowrap; }
.nc-empty { padding: 24px 12px; text-align: center; color: var(--color-muted-foreground); }
.nc-bar { height: 6px; border-radius: 3px; background: var(--color-muted); overflow: hidden; }
.nc-bar > span { display: block; height: 100%; background: var(--color-primary); transition: width .2s; }
.nc-card { border: 1px solid var(--color-border); border-radius: 8px; padding: 12px; background: var(--color-card, var(--color-background)); color: var(--color-card-foreground, var(--color-foreground)); }
.nc-chip { display: inline-flex; align-items: center; gap: 4px; max-width: 100%; padding: 2px 4px 2px 8px; border-radius: 999px; background: var(--color-muted); font-size: 12px; }
.nc-chip button { font: inherit; border: 0; background: none; color: inherit; cursor: pointer; padding: 2px 6px; border-radius: 999px; }
.nc-chip button:hover { background: var(--color-accent); }
.nc-sr { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; }
@media (max-width: 520px) {
  .nc-meta.nc-hide-narrow { display: none; }
  .nc-footer { flex-direction: column; align-items: stretch; }
  .nc-footer .nc-btn { width: 100%; }
}
`;
function ensureStyles() {
  if (typeof document === "undefined" || document.getElementById("nc-styles")) return;
  const el = document.createElement("style");
  el.id = "nc-styles";
  el.textContent = CSS;
  document.head.appendChild(el);
}

// nextcloud/src/ui/connection-ui.js
var import_react = require("react");

// nextcloud/src/lib/format.js
function hostOf(origin) {
  try {
    return new URL(origin).host;
  } catch {
    return String(origin ?? "");
  }
}

// nextcloud/src/ui/connection-ui.js
function useConnection(api) {
  const [state, setState] = (0, import_react.useState)({ status: "loading" });
  const flowRef = (0, import_react.useRef)(null);
  const mounted = (0, import_react.useRef)(true);
  const set = (next) => {
    if (mounted.current) setState(next);
  };
  const refresh = (0, import_react.useCallback)(async () => {
    let fixed = null;
    try {
      fixed = await adminServer(api);
      const conn = await getConnection(api, { fixedServer: fixed });
      set(conn ? { status: "connected", conn, fixed } : { status: "disconnected", fixed });
      return conn;
    } catch (err) {
      if (err instanceof NcError && err.code === "wrong_server") set({ status: "disconnected", fixed, error: err });
      else if (needsSignIn(err)) set({ status: "expired", fixed, error: err });
      else set({ status: "error", fixed, error: err });
      return null;
    }
  }, [api]);
  (0, import_react.useEffect)(() => {
    mounted.current = true;
    void refresh();
    return () => {
      mounted.current = false;
      flowRef.current?.abort();
    };
  }, [refresh]);
  const connect = (0, import_react.useCallback)(async () => {
    const fixed = await adminServer(api);
    set({ status: "approving", fixed });
    const controller = new AbortController();
    flowRef.current?.abort();
    flowRef.current = controller;
    try {
      const origin = await approveServer(api, { fixedServer: fixed, suggestedServer: state.conn?.origin });
      if (!origin) {
        await refresh();
        return null;
      }
      const flow = await startLoginFlow(api, origin);
      set({ status: "waiting", fixed, origin, loginUrl: flow.loginUrl });
      await api.ui.openExternalUrl(flow.loginUrl).catch(() => {
      });
      await pollLoginFlow(api, flow, { signal: controller.signal });
      const conn = await refresh();
      if (conn) api.toast.success(api.i18n.t("connect.done", { host: hostOf(conn.origin) }));
      return conn;
    } catch (err) {
      if (err instanceof NcError && err.code === "cancelled") {
        await refresh();
        return null;
      }
      set({ status: "error", fixed, error: err });
      return null;
    } finally {
      if (flowRef.current === controller) flowRef.current = null;
    }
  }, [api, refresh, state.conn]);
  const cancel = (0, import_react.useCallback)(() => {
    flowRef.current?.abort();
  }, []);
  const signOut = (0, import_react.useCallback)(async () => {
    try {
      await disconnect(api);
    } catch (err) {
      api.toast.error(errorText(api.i18n.t, err));
    }
    await refresh();
  }, [api, refresh]);
  const report = (0, import_react.useCallback)((err) => {
    if (needsSignIn(err)) set({ status: "expired", fixed: state.fixed, error: err });
  }, [state.fixed]);
  return { ...state, refresh, connect, cancel, signOut, report };
}
function ConnectionPanel({ api, connection, compact = false, intro }) {
  const t = api.i18n.t;
  const c = connection;
  const fixedHost = c.fixed ? hostOf(c.fixed) : "";
  if (c.status === "loading") {
    return (0, import_react.createElement)("p", { className: "nc-muted", role: "status" }, t("connect.checking"));
  }
  if (c.status === "connected") {
    const who = c.conn.displayName || c.conn.userId;
    return (0, import_react.createElement)(
      "div",
      { className: "nc-row" },
      (0, import_react.createElement)("span", { className: "nc-grow", role: "status" }, t("connect.connected", { host: hostOf(c.conn.origin), user: who })),
      compact ? null : (0, import_react.createElement)("button", { type: "button", className: "nc-btn", onClick: () => void c.signOut() }, t("connect.disconnect"))
    );
  }
  if (c.status === "approving") {
    return (0, import_react.createElement)("p", { className: "nc-muted", role: "status" }, t("connect.approving"));
  }
  if (c.status === "waiting") {
    return (0, import_react.createElement)(
      "div",
      { className: "nc-col", role: "status" },
      (0, import_react.createElement)("p", { style: { margin: 0 } }, t("connect.waiting", { host: hostOf(c.origin) })),
      (0, import_react.createElement)(
        "div",
        { className: "nc-row" },
        (0, import_react.createElement)("button", { type: "button", className: "nc-btn", onClick: () => void api.ui.openExternalUrl(c.loginUrl) }, t("connect.reopen")),
        (0, import_react.createElement)("button", { type: "button", className: "nc-btn", onClick: c.cancel }, t("common.cancel"))
      )
    );
  }
  const message = c.status === "expired" ? t("connect.expired") : c.status === "error" ? errorText(t, c.error) : c.error?.code === "wrong_server" ? t("error.wrong_server_host", { host: fixedHost }) : intro ?? t("connect.intro");
  return (0, import_react.createElement)(
    "div",
    { className: "nc-col" },
    (0, import_react.createElement)("p", { style: { margin: 0 }, className: c.status === "error" ? "nc-error" : void 0, role: c.status === "error" ? "alert" : void 0 }, message),
    fixedHost && c.status === "disconnected" ? (0, import_react.createElement)("p", { className: "nc-muted nc-small", style: { margin: 0 } }, t("connect.server", { host: fixedHost })) : null,
    (0, import_react.createElement)(
      "div",
      { className: "nc-row" },
      (0, import_react.createElement)(
        "button",
        { type: "button", className: "nc-btn nc-primary", onClick: () => void c.connect() },
        c.status === "expired" ? t("connect.again") : t("connect.button")
      )
    )
  );
}

// nextcloud/src/ui/settings-section.js
function SettingsSection() {
  ensureStyles();
  const api = getApi();
  const t = api.i18n.t;
  const connection = useConnection(api);
  return (0, import_react2.createElement)(
    "section",
    { className: "nc nc-col", "aria-label": t("settings.title") },
    (0, import_react2.createElement)("h3", { style: { margin: 0, fontSize: "14px" } }, t("settings.title")),
    (0, import_react2.createElement)(ConnectionPanel, { api, connection }),
    (0, import_react2.createElement)("p", { className: "nc-muted nc-small", style: { margin: 0 } }, t("settings.privacy")),
    (0, import_react2.createElement)("p", { className: "nc-muted nc-small", style: { margin: 0 } }, t("settings.migration"))
  );
}

// nextcloud/src/index.js
var FIRST_RUN_KEY = "firstRunOffered";
async function offerFirstRun(api) {
  if (await api.storage.get(FIRST_RUN_KEY)) return false;
  const account = await storedAccount(api);
  await api.storage.set(FIRST_RUN_KEY, true);
  if (account?.connected) return false;
  api.toast.info(api.i18n.t("firstrun.offer"));
  return true;
}
async function activate(api) {
  setApi(api);
  await offerFirstRun(api).catch(() => {
  });
}
var hooks = {};
var slots = {
  "settings-section": { component: SettingsSection }
};
